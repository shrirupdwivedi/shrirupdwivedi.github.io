import { ModelCreator } from "./metadata/ModelCreator.js";
import { ModelCategory, ModelConfig } from "../legacy/ModelConfig.js";
import { ModelTag } from "./metadata/ModelTag.js";
import { GenerationProvider } from "@storyteller/api-enums";

export type ModelKind =
  | "model"
  | "image_model"
  | "video_model"
  | "gaussian_model"
  | "3d_object_model";

// NB: Do not create instances of this class directly, use subclasses.
export class Model {
  // Typescript type discriminator property
  // Since Vite minification and class name mangling can break instanceof checks,
  // we have a type discriminator property to check against.
  readonly kind: ModelKind = "model";

  // A unique frontend-only string for the model
  readonly id: string;

  // A unique identifier that Tauri uses for the model (this
  // might differ from our backend or other systems)
  readonly tauriId: string;

  // A long name for the model that might need to be abbreviated.
  readonly fullName: string;

  // The type of model (image, video, etc.)
  // TODO: Not sure that this is used for anything
  readonly category: ModelCategory;

  // What company made the model.
  readonly creator: ModelCreator;

  // Name for the selector
  readonly selectorName: string;

  // Description for the selector
  readonly selectorDescription: string;

  // Labels for the selector
  readonly selectorBadges: string[];

  // A list of filterable "capabilities" that can be used to filter models.
  readonly tags: ModelTag[];

  // Use `getProviders()` to read the list.
  protected readonly providers?: GenerationProvider[];

  // Optional provider preferences; two-to-many via page and providers.
  readonly preferredProvidersByPage?: Partial<Record<string, string[]>>;

  // Time in milliseconds for the fake progress bar to reach 100% (UI-only)
  readonly progressBarTime: number;

  // Maximum character length for the prompt text input
  readonly maxPromptLength: number;

  // Providers whose menus differ from this (base) config get a variant: a
  // model with the same id built from the provider's override config. See
  // `forProvider()`. Only set on base models.
  private providerVariants?: Map<GenerationProvider, Model>;

  // On a variant: the base model it was derived from.
  private baseModel?: Model;

  protected constructor(args: {
    id: string;
    tauriId: string;
    fullName: string;
    category: ModelCategory;
    creator: ModelCreator;
    selectorName: string;
    selectorDescription: string;
    selectorBadges: string[];
    tags?: ModelTag[];
    providers?: GenerationProvider[];
    preferredProvidersByPage?: Partial<Record<string, string[]>>;
    progressBarTime?: number;
    maxPromptLength?: number;
  }) {
    this.id = args.id;
    this.tauriId = args.tauriId;
    this.fullName = args.fullName;
    this.category = args.category;
    this.creator = args.creator;
    this.selectorName = args.selectorName;
    this.selectorDescription = args.selectorDescription;
    this.selectorBadges = args.selectorBadges;
    this.tags = args.tags ?? [];
    this.providers = args.providers;
    this.preferredProvidersByPage = args.preferredProvidersByPage;
    this.progressBarTime = args.progressBarTime ?? 20000;
    this.maxPromptLength = args.maxPromptLength ?? 3000;
  }

  getProviders(): GenerationProvider[] {
    return this.providers ?? [GenerationProvider.Artcraft];
  }

  // Register `variant` as what this model looks like on `provider`.
  attachProviderVariant(provider: GenerationProvider, variant: Model): void {
    variant.baseModel = this;
    (this.providerVariants ??= new Map()).set(provider, variant);
  }

  hasProviderVariants(): boolean {
    return (this.baseModel ?? this).providerVariants?.size ? true : false;
  }

  // The model as `provider` runs it: the provider's variant when its menus
  // differ, else the base model. Works from a base or from another variant;
  // no provider (or one without overrides) resolves to the base.
  forProvider(provider: GenerationProvider | undefined): Model {
    const root = this.baseModel ?? this;
    if (provider === undefined) return root;
    return root.providerVariants?.get(provider) ?? root;
  }

  toLegacyBadges(): { label: string }[] {
    return this.selectorBadges.map((b) => ({ label: b }));
  }

  // TODO: This is a method to support migration. Kill it after we no longer need it.
  toLegacyModelConfig(): ModelConfig {
    return {
      id: this.id,
      label: this.selectorName,
      description: this.selectorDescription,
      badges: this.toLegacyBadges(),
      category: this.category,
      info: {
        name: this.fullName,
        tauri_id: this.tauriId,
        creator: this.creator,
      },
      capabilities: {
        maxGenerationCount: 9, // NB: Sentinel value to detect continued use
        defaultGenerationCount: 9, // NB: Sentinel value to detect continued use
      },
      tags: [],
    };
  }
}
