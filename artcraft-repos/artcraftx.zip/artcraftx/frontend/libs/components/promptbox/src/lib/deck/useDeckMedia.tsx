import { useEffect, useRef, useState, type ReactNode } from "react";
import { GalleryItem, GalleryModal } from "@storyteller/ui-gallery-modal";
import { downloadFileFromUrl, type UploadMediaFn } from "@storyteller/api";
import { toast } from "@storyteller/ui-toaster";
import { UploaderStates } from "@storyteller/common";
import { IsDesktopApp } from "@storyteller/tauri-utils";
import {
  AUDIO_FILE_ACCEPT,
  AUDIO_FILE_TYPE_ERROR,
  isAudioFile,
} from "../common/audioFiles";
import type { DroppedMedia } from "./usePromptBoxDrop";

/** Minimal structural shapes so both apps' ref types fit. */
export interface DeckRefLike {
  id: string;
  url: string;
}
export interface DeckMediaRefLike extends DeckRefLike {
  duration: number;
}

/** An in-flight upload; `previewUrl` is a memoized object URL. */
export interface DeckUploadEntry {
  id: string;
  file: File;
  previewUrl: string;
}

export interface UseDeckMediaOptions<
  TImage extends DeckRefLike,
  TVideo extends DeckMediaRefLike,
  TAudio extends DeckMediaRefLike,
> {
  referenceImages: TImage[];
  setReferenceImages: (images: TImage[]) => void;
  maxImages: number;
  setEndFrameImage?: (image?: TImage) => void;
  referenceVideos?: TVideo[];
  setReferenceVideos?: (videos: TVideo[]) => void;
  maxVideos?: number;
  maxVideoTotalSec?: number;
  referenceAudios?: TAudio[];
  setReferenceAudios?: (audios: TAudio[]) => void;
  maxAudios?: number;
  maxAudioTotalSec?: number;
  uploadImage?: UploadMediaFn;
  uploadVideo?: UploadMediaFn;
  uploadAudio?: UploadMediaFn;
  /**
   * When true the hook owns a target-aware GalleryModal (desktop). When
   * false the caller keeps its own library pickers (webapp) and only the
   * upload paths are used.
   */
  ownGalleryModal?: boolean;
}

const randomId = () => Math.random().toString(36).substring(7);

// Extensions offered by the native file pickers; mirror the accept lists of
// the hidden <input> fallbacks.
const PICKER_IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "webp", "gif", "bmp", "avif"];
const PICKER_VIDEO_EXTENSIONS = ["mp4"];
const PICKER_AUDIO_EXTENSIONS = ["mp3", "wav", "ogg", "flac", "aac", "m4a", "opus"];

const PICKER_MIME_BY_EXTENSION: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
  bmp: "image/bmp",
  avif: "image/avif",
  mp4: "video/mp4",
  mp3: "audio/mpeg",
  wav: "audio/wav",
  ogg: "audio/ogg",
  flac: "audio/flac",
  aac: "audio/aac",
  m4a: "audio/mp4",
  opus: "audio/opus",
};

/**
 * Desktop-only native file picker: returns path-backed [`DroppedMedia`]
 * (asset-protocol previews, no bytes copied into JS), or `null` when the
 * user cancelled.
 */
const pickLocalMedia = async (
  extensions: string[],
  multiple: boolean,
): Promise<DroppedMedia[] | null> => {
  const { open } = await import("@tauri-apps/plugin-dialog");
  const { convertFileSrc } = await import("@tauri-apps/api/core");
  const picked = await open({
    multiple,
    directory: false,
    filters: [{ name: "Media", extensions }],
  });
  if (picked === null) return null;
  const paths = Array.isArray(picked) ? picked : [picked];
  return paths.map((path) => {
    const fileName = path.split(/[/\\]/).pop() ?? "file";
    const extension = fileName.split(".").pop()?.toLowerCase() ?? "";
    const type = PICKER_MIME_BY_EXTENSION[extension] ?? "";
    return {
      file: new File([], fileName, { type }),
      localPath: path,
      previewUrl: convertFileSrc(path),
    };
  });
};

// A non-finite duration cap means "no limit" — leave it out of the message.
const videoLimitMessage = (maxVideos: number, maxTotalSec: number) =>
  isFinite(maxTotalSec)
    ? `Max ${maxVideos} videos / ${maxTotalSec}s total`
    : `Max ${maxVideos} video${maxVideos === 1 ? "" : "s"}`;

const randomTitle = (prefix: string) =>
  `${prefix}-${Math.random().toString(36).substring(2, 15)}`;

const getVideoDurationFromSrc = (src: string): Promise<number> =>
  new Promise((resolve) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => resolve(Math.round(video.duration));
    video.onerror = () => resolve(0);
    video.src = src;
  });

const getVideoDuration = (file: File): Promise<number> => {
  const src = URL.createObjectURL(file);
  return getVideoDurationFromSrc(src).finally(() => URL.revokeObjectURL(src));
};

const getAudioDurationFromSrc = (src: string): Promise<number> =>
  new Promise((resolve) => {
    const audio = document.createElement("audio");
    audio.preload = "metadata";
    audio.onloadedmetadata = () => resolve(Math.round(audio.duration));
    audio.onerror = () => resolve(0);
    audio.src = src;
  });

const getAudioDuration = (file: File): Promise<number> =>
  new Promise((resolve) => {
    const audio = document.createElement("audio");
    audio.preload = "metadata";
    audio.onloadedmetadata = () => {
      URL.revokeObjectURL(audio.src);
      resolve(Math.round(audio.duration));
    };
    audio.onerror = () => {
      URL.revokeObjectURL(audio.src);
      resolve(0);
    };
    audio.src = URL.createObjectURL(file);
  });

/**
 * Headless upload/limits/library state machine for the reference deck.
 * Extracted from the legacy ImagePromptRow band so PromptBoxImage,
 * PromptBoxVideo, and the webapp PromptBox share one implementation.
 */
export function useDeckMedia<
  TImage extends DeckRefLike,
  TVideo extends DeckMediaRefLike,
  TAudio extends DeckMediaRefLike,
>({
  referenceImages,
  setReferenceImages,
  maxImages,
  setEndFrameImage,
  referenceVideos = [],
  setReferenceVideos,
  maxVideos = 3,
  maxVideoTotalSec = 15,
  referenceAudios = [],
  setReferenceAudios,
  maxAudios = 2,
  maxAudioTotalSec = 15,
  uploadImage,
  uploadVideo,
  uploadAudio,
  ownGalleryModal,
}: UseDeckMediaOptions<TImage, TVideo, TAudio>) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoFileInputRef = useRef<HTMLInputElement>(null);
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  const anyFileInputRef = useRef<HTMLInputElement>(null);
  const imageTargetRef = useRef<"start" | "end">("start");

  const [uploadingImages, setUploadingImages] = useState<DeckUploadEntry[]>([]);
  const [uploadingEnd, setUploadingEnd] = useState<DeckUploadEntry | null>(
    null,
  );
  const [uploadingVideo, setUploadingVideo] = useState<DeckUploadEntry | null>(
    null,
  );
  const [uploadingAudio, setUploadingAudio] = useState<DeckUploadEntry | null>(
    null,
  );

  const [isGalleryModalOpen, setIsGalleryModalOpen] = useState(false);
  const [galleryTarget, setGalleryTarget] = useState<
    "start" | "end" | "video" | "audio"
  >("start");
  const [selectedGalleryImages, setSelectedGalleryImages] = useState<string[]>(
    [],
  );
  const [isProcessingGallery, setIsProcessingGallery] = useState(false);

  // Async upload completions must append to the freshest committed arrays,
  // not the arrays captured when the upload started.
  const referenceImagesRef = useRef(referenceImages);
  useEffect(() => {
    referenceImagesRef.current = referenceImages;
  }, [referenceImages]);

  const referenceAudiosRef = useRef(referenceAudios);
  useEffect(() => {
    referenceAudiosRef.current = referenceAudios;
  }, [referenceAudios]);

  // The hook only ever commits `{ id, url, file, mediaToken, localPath?,
  // duration? }`, which is structurally assignable to both apps' ref types
  // (desktop promptStore refs match exactly; the webapp's extra fields are
  // optional).
  const asImage = (img: {
    id: string;
    url: string;
    file: File;
    mediaToken: string;
    localPath?: string;
  }) => img as unknown as TImage;
  const asVideo = (video: {
    id: string;
    url: string;
    file: File;
    mediaToken: string;
    localPath?: string;
    duration: number;
  }) => video as unknown as TVideo;
  const asAudio = (audio: {
    id: string;
    url: string;
    file: File;
    mediaToken: string;
    localPath?: string;
    duration: number;
  }) => audio as unknown as TAudio;

  const makeEntry = (file: File): DeckUploadEntry => ({
    id: randomId(),
    file,
    previewUrl: URL.createObjectURL(file),
  });

  // On desktop the pickers are native dialogs returning OS paths, so picked
  // files stay local (no upload, asset-protocol previews). The hidden
  // <input> elements remain the browser fallback.
  const openImageUpload = () => {
    imageTargetRef.current = "start";
    if (IsDesktopApp()) {
      void pickLocalMedia(PICKER_IMAGE_EXTENSIONS, maxImages > 1).then(
        (media) => media && processImageFiles(media, "start"),
      );
      return;
    }
    fileInputRef.current?.click();
  };

  const openEndUpload = () => {
    imageTargetRef.current = "end";
    if (IsDesktopApp()) {
      void pickLocalMedia(PICKER_IMAGE_EXTENSIONS, false).then(
        (media) => media && processImageFiles(media, "end"),
      );
      return;
    }
    fileInputRef.current?.click();
  };

  const openVideoUpload = () => {
    if (IsDesktopApp()) {
      void pickLocalMedia(PICKER_VIDEO_EXTENSIONS, maxVideos > 1).then(
        (media) => media && processVideoFiles(media),
      );
      return;
    }
    videoFileInputRef.current?.click();
  };

  const openAudioUpload = () => {
    if (IsDesktopApp()) {
      void pickLocalMedia(PICKER_AUDIO_EXTENSIONS, maxAudios > 1).then(
        (media) => media && processAudioFiles(media),
      );
      return;
    }
    audioFileInputRef.current?.click();
  };

  const openAnyUpload = () => {
    if (IsDesktopApp()) {
      const extensions = [
        ...(maxImages > 0 ? PICKER_IMAGE_EXTENSIONS : []),
        ...(setReferenceVideos ? PICKER_VIDEO_EXTENSIONS : []),
        ...(setReferenceAudios ? PICKER_AUDIO_EXTENSIONS : []),
      ];
      void pickLocalMedia(extensions, true).then((media) => {
        if (!media) return;
        const images = media.filter((m) => m.file.type.startsWith("image/"));
        const audios = media.filter((m) => isAudioFile(m.file));
        const videos = media.filter(
          (m) => m.file.type.startsWith("video/") && !isAudioFile(m.file),
        );
        if (images.length > 0) processImageFiles(images, "start");
        if (videos.length > 0 && setReferenceVideos) void processVideoFiles(videos);
        if (audios.length > 0 && setReferenceAudios) void processAudioFiles(audios);
      });
      return;
    }
    anyFileInputRef.current?.click();
  };

  const openGallery = (target: "start" | "end" | "video" | "audio") => {
    setGalleryTarget(target);
    setIsGalleryModalOpen(true);
  };

  const processImageFiles = (
    files: DroppedMedia[],
    uploadTarget: "start" | "end",
  ) => {
    const currentCount = referenceImages.length + uploadingImages.length;
    const availableSlots = Math.max(0, maxImages - currentCount);
    if (availableSlots <= 0 && uploadTarget !== "end") {
      return;
    }

    const filesToProcess =
      uploadTarget === "end"
        ? files.slice(0, 1)
        : files.slice(0, availableSlots);

    filesToProcess.forEach(({ file, localPath, previewUrl }) => {
      const commitRef = (url: string, mediaToken: string) => {
        const referenceImage = asImage({
          id: randomId(),
          url,
          file,
          mediaToken,
          localPath,
        });
        if (uploadTarget === "end") {
          setEndFrameImage?.(referenceImage);
        } else {
          setReferenceImages([...referenceImagesRef.current, referenceImage]);
        }
      };

      // A path-backed file previews straight off disk and commits
      // immediately — nothing to read or upload.
      if (localPath && previewUrl) {
        commitRef(previewUrl, "");
        return;
      }

      const entry = makeEntry(file);
      if (uploadTarget === "end") {
        setUploadingEnd(entry);
      } else {
        setUploadingImages((prev) => [...prev, entry]);
      }

      const finishEntry = () => {
        URL.revokeObjectURL(entry.previewUrl);
        if (uploadTarget === "end") {
          setUploadingEnd(null);
        } else {
          setUploadingImages((prev) => prev.filter((e) => e.id !== entry.id));
        }
      };

      const commit = (url: string, mediaToken: string) => {
        finishEntry();
        commitRef(url, mediaToken);
      };

      const reader = new FileReader();
      reader.onloadend = async () => {
        if (uploadImage) {
          await uploadImage({
            title: randomTitle("reference-image"),
            assetFile: file,
            progressCallback: (newState) => {
              if (newState.status === UploaderStates.success && newState.data) {
                commit(reader.result as string, newState.data);
              } else if (
                newState.status === UploaderStates.assetError ||
                newState.status === UploaderStates.imageCreateError
              ) {
                finishEntry();
              }
            },
          });
        } else {
          commit(reader.result as string, "");
        }

      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (files.length === 0) return;
    processImageFiles(files.map((file) => ({ file })), imageTargetRef.current);
  };

  const processVideoFiles = async (files: DroppedMedia[]) => {
    // Snapshot the committed state at call time so removes that happened
    // before this call are respected (don't re-read a stale ref).
    const baseVideos = [...referenceVideos];
    const availableSlots = Math.max(0, maxVideos - baseVideos.length);
    if (availableSlots <= 0) {
      toast.error(videoLimitMessage(maxVideos, maxVideoTotalSec), {
        id: "video-ref-limit",
      });
      return;
    }

    const filesToProcess = files.slice(0, availableSlots);
    let committed = baseVideos;

    for (const { file, localPath, previewUrl } of filesToProcess) {
      const duration =
        localPath && previewUrl
          ? await getVideoDurationFromSrc(previewUrl)
          : await getVideoDuration(file);
      const currentTotal = committed.reduce((sum, v) => sum + v.duration, 0);

      if (currentTotal + duration > maxVideoTotalSec) {
        toast.error(`Total video duration cannot exceed ${maxVideoTotalSec}s`, {
          id: "video-ref-limit",
        });
        break;
      }

      // A path-backed file previews straight off disk and commits
      // immediately — nothing to read or upload.
      if (localPath && previewUrl) {
        committed = [
          ...committed,
          asVideo({
            id: randomId(),
            url: previewUrl,
            file,
            mediaToken: "",
            localPath,
            duration,
          }),
        ];
        setReferenceVideos?.(committed);
        continue;
      }

      const entry = makeEntry(file);
      setUploadingVideo(entry);

      const commit = (mediaToken: string) => {
        // Reuse the entry's object URL as the committed thumbnail so it
        // stays alive exactly as long as the ref does.
        const refVideo = asVideo({
          id: randomId(),
          url: entry.previewUrl,
          file,
          mediaToken,
          duration,
        });
        setUploadingVideo(null);
        committed = [...committed, refVideo];
        setReferenceVideos?.(committed);
      };

      if (uploadVideo) {
        await uploadVideo({
          title: randomTitle("reference-video"),
          assetFile: file,
          progressCallback: (newState) => {
            if (newState.status === UploaderStates.success && newState.data) {
              commit(newState.data);
            } else if (
              newState.status === UploaderStates.assetError ||
              newState.status === UploaderStates.imageCreateError
            ) {
              URL.revokeObjectURL(entry.previewUrl);
              setUploadingVideo(null);
              toast.error("Failed to upload video. Please upload an MP4 file.");
            }
          },
        });
      } else {
        commit("");
      }
    }
  };

  const handleVideoFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const files = Array.from(event.target.files || []);
    if (videoFileInputRef.current) videoFileInputRef.current.value = "";
    if (files.length === 0) return;
    await processVideoFiles(files.map((file) => ({ file })));
  };

  const processAudioFiles = async (files: DroppedMedia[]) => {
    const audioFiles = files.filter((media) => isAudioFile(media.file));
    if (audioFiles.length < files.length) {
      toast.error(AUDIO_FILE_TYPE_ERROR, { id: "audio-ref-type" });
    }
    if (audioFiles.length === 0) return;

    const availableSlots = Math.max(0, maxAudios - referenceAudios.length);
    if (availableSlots <= 0) {
      return;
    }

    const filesToProcess = audioFiles.slice(0, availableSlots);

    for (const { file, localPath, previewUrl } of filesToProcess) {
      const duration =
        localPath && previewUrl
          ? await getAudioDurationFromSrc(previewUrl)
          : await getAudioDuration(file);
      const currentTotal = referenceAudiosRef.current.reduce(
        (sum, a) => sum + a.duration,
        0,
      );

      if (currentTotal + duration > maxAudioTotalSec) {
        toast.error(`Total audio duration cannot exceed ${maxAudioTotalSec}s`);
        break;
      }

      // A path-backed file previews straight off disk and commits
      // immediately — nothing to read or upload.
      if (localPath && previewUrl) {
        setReferenceAudios?.([
          ...referenceAudiosRef.current,
          asAudio({
            id: randomId(),
            url: previewUrl,
            file,
            mediaToken: "",
            localPath,
            duration,
          }),
        ]);
        continue;
      }

      const entry = makeEntry(file);
      setUploadingAudio(entry);

      const commit = (mediaToken: string) => {
        const refAudio = asAudio({
          id: randomId(),
          url: entry.previewUrl,
          file,
          mediaToken,
          duration,
        });
        setUploadingAudio(null);
        setReferenceAudios?.([...referenceAudiosRef.current, refAudio]);
      };

      if (uploadAudio) {
        await uploadAudio({
          title: randomTitle("reference-audio"),
          assetFile: file,
          progressCallback: (newState) => {
            if (newState.status === UploaderStates.success && newState.data) {
              commit(newState.data);
            } else if (
              newState.status === UploaderStates.assetError ||
              newState.status === UploaderStates.imageCreateError
            ) {
              URL.revokeObjectURL(entry.previewUrl);
              setUploadingAudio(null);
            }
          },
        });
      } else {
        commit("");
      }
    }
  };

  const handleAudioFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const files = Array.from(event.target.files || []);
    if (audioFileInputRef.current) audioFileInputRef.current.value = "";
    if (files.length === 0) return;
    await processAudioFiles(files.map((file) => ({ file })));
  };

  // Combined picker for direct clicks on the reference card / circular "+":
  // accepts every supported media kind and routes each file by MIME type.
  const handleAnyFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (anyFileInputRef.current) anyFileInputRef.current.value = "";
    if (files.length === 0) return;

    const media = files.map((file) => ({ file }));
    const images = media.filter((m) => m.file.type.startsWith("image/"));
    // isAudioFile also claims .m4a files that platforms report as video/mp4,
    // so exclude them from the video bucket.
    const audios = media.filter((m) => isAudioFile(m.file));
    const videos = media.filter(
      (m) => m.file.type.startsWith("video/") && !isAudioFile(m.file),
    );

    if (images.length > 0) processImageFiles(images, "start");
    if (videos.length > 0 && setReferenceVideos) processVideoFiles(videos);
    if (audios.length > 0 && setReferenceAudios) processAudioFiles(audios);
  };

  // maxImages of 0 means the page's model takes no image refs at all.
  const anyUploadAccept = [
    ...(maxImages > 0 ? ["image/*"] : []),
    ...(setReferenceVideos ? ["video/mp4", ".mp4"] : []),
    ...(setReferenceAudios ? [AUDIO_FILE_ACCEPT] : []),
  ].join(",");

  const handleGalleryClose = () => {
    setIsGalleryModalOpen(false);
    setSelectedGalleryImages([]);
  };

  const handleImageSelect = (id: string) => {
    setSelectedGalleryImages((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      const maxSelections =
        galleryTarget === "video"
          ? Math.max(1, maxVideos - referenceVideos.length)
          : galleryTarget === "audio"
            ? Math.max(1, maxAudios - referenceAudios.length)
            : galleryTarget === "end"
              ? 1
              : Math.max(1, maxImages);
      if (prev.length >= maxSelections) {
        return maxSelections === 1 ? [id] : prev;
      }
      return [...prev, id];
    });
  };

  const handleGalleryImages = async (selectedItems: GalleryItem[]) => {
    if (galleryTarget === "video") {
      // Snapshot committed state at call time to avoid re-reading a stale
      // ref after removes.
      const baseVideos = [...referenceVideos];
      const availableSlots = Math.max(0, maxVideos - baseVideos.length);
      if (availableSlots <= 0) {
        toast.error(videoLimitMessage(maxVideos, maxVideoTotalSec), {
          id: "video-ref-limit",
        });
        handleGalleryClose();
        return;
      }
      const itemsToProcess = selectedItems
        .slice(0, availableSlots)
        .filter((item): item is GalleryItem & { fullImage: string } =>
          Boolean(item.fullImage),
        );

      setIsProcessingGallery(true);
      try {
        // Parallelize duration probes — sequential metadata loads was the
        // source of the perceived lag on the "Use selected" click.
        const durations = await Promise.all(
          itemsToProcess.map((item) => getVideoDurationFromSrc(item.fullImage)),
        );

        const newVideos: TVideo[] = [];
        let currentTotal = baseVideos.reduce((sum, v) => sum + v.duration, 0);
        let exceeded = false;
        for (let i = 0; i < itemsToProcess.length; i++) {
          const item = itemsToProcess[i]!;
          const duration = durations[i]!;
          if (currentTotal + duration > maxVideoTotalSec) {
            exceeded = true;
            break;
          }
          currentTotal += duration;
          newVideos.push(
            asVideo({
              id: randomId(),
              url: item.fullImage,
              file: new File([], "library-video"),
              mediaToken: item.id,
              duration,
            }),
          );
        }
        if (exceeded) {
          toast.error(
            `Total video duration cannot exceed ${maxVideoTotalSec}s`,
            { id: "video-ref-limit" },
          );
        }
        if (newVideos.length > 0) {
          setReferenceVideos?.([...baseVideos, ...newVideos]);
        }
      } finally {
        setIsProcessingGallery(false);
      }
      handleGalleryClose();
      return;
    }
    if (galleryTarget === "audio") {
      const baseAudios = [...referenceAudios];
      const availableSlots = Math.max(0, maxAudios - baseAudios.length);
      if (availableSlots <= 0) {
        toast.error(`Max ${maxAudios} audio tracks / ${maxAudioTotalSec}s total`, {
          id: "audio-ref-limit",
        });
        handleGalleryClose();
        return;
      }
      const itemsToProcess = selectedItems
        .slice(0, availableSlots)
        .filter((item): item is GalleryItem & { fullImage: string } =>
          Boolean(item.fullImage),
        );

      setIsProcessingGallery(true);
      try {
        // Use the duration the list endpoint already knows; probe the file's
        // metadata only when it doesn't.
        const durations = await Promise.all(
          itemsToProcess.map((item) =>
            item.durationMillis != null
              ? Promise.resolve(Math.round(item.durationMillis / 1000))
              : getAudioDurationFromSrc(item.fullImage),
          ),
        );

        const newAudios: TAudio[] = [];
        let currentTotal = baseAudios.reduce((sum, a) => sum + a.duration, 0);
        let exceeded = false;
        for (let i = 0; i < itemsToProcess.length; i++) {
          const item = itemsToProcess[i]!;
          const duration = durations[i]!;
          if (currentTotal + duration > maxAudioTotalSec) {
            exceeded = true;
            break;
          }
          currentTotal += duration;
          newAudios.push(
            asAudio({
              id: randomId(),
              url: item.fullImage,
              file: new File([], "library-audio"),
              mediaToken: item.id,
              duration,
            }),
          );
        }
        if (exceeded) {
          toast.error(
            `Total audio duration cannot exceed ${maxAudioTotalSec}s`,
            { id: "audio-ref-limit" },
          );
        }
        if (newAudios.length > 0) {
          setReferenceAudios?.([...baseAudios, ...newAudios]);
        }
      } finally {
        setIsProcessingGallery(false);
      }
      handleGalleryClose();
      return;
    }
    if (galleryTarget === "end") {
      const item = selectedItems[0];
      if (item && item.fullImage) {
        setEndFrameImage?.(
          asImage({
            id: randomId(),
            url: item.fullImage,
            file: new File([], "library-image"),
            mediaToken: item.id,
          }),
        );
      }
      handleGalleryClose();
      return;
    }
    const availableSlots = Math.max(0, maxImages - referenceImages.length);
    if (availableSlots <= 0) {
      handleGalleryClose();
      return;
    }

    const newRefs = [...referenceImages];
    selectedItems.slice(0, availableSlots).forEach((item) => {
      if (!item.fullImage) return;
      newRefs.push(
        asImage({
          id: randomId(),
          url: item.fullImage,
          file: new File([], "library-image"),
          mediaToken: item.id,
        }),
      );
    });
    setReferenceImages(newRefs);
    handleGalleryClose();
  };

  const availableImageSlots = Math.max(
    0,
    maxImages - referenceImages.length - uploadingImages.length,
  );

  const fileInputs: ReactNode = (
    <>
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept="image/*"
        onChange={handleFileUpload}
        multiple={maxImages > 1}
      />
      <input
        type="file"
        ref={anyFileInputRef}
        className="hidden"
        accept={anyUploadAccept}
        onChange={handleAnyFileUpload}
        multiple
      />
      {(uploadVideo || setReferenceVideos) && (
        <input
          type="file"
          ref={videoFileInputRef}
          className="hidden"
          accept="video/mp4,.mp4"
          onChange={handleVideoFileUpload}
          multiple={maxVideos > 1}
        />
      )}
      {(uploadAudio || setReferenceAudios) && (
        <input
          type="file"
          ref={audioFileInputRef}
          className="hidden"
          accept={AUDIO_FILE_ACCEPT}
          onChange={handleAudioFileUpload}
          multiple={maxAudios > 1}
        />
      )}
    </>
  );

  const galleryModal: ReactNode = ownGalleryModal ? (
    <GalleryModal
      key={
        galleryTarget === "video"
          ? "video"
          : galleryTarget === "audio"
            ? "audio"
            : "image"
      }
      isOpen={!!isGalleryModalOpen}
      onClose={handleGalleryClose}
      mode="select"
      selectedItemIds={selectedGalleryImages}
      onSelectItem={handleImageSelect}
      maxSelections={
        galleryTarget === "end"
          ? 1
          : galleryTarget === "video"
            ? Math.max(1, maxVideos - referenceVideos.length)
            : galleryTarget === "audio"
              ? Math.max(1, maxAudios - referenceAudios.length)
              : Math.max(1, availableImageSlots)
      }
      onUseSelected={handleGalleryImages}
      onDownloadClicked={downloadFileFromUrl}
      useSelectedLoading={isProcessingGallery}
      forceFilter={
        galleryTarget === "video"
          ? "video"
          : galleryTarget === "audio"
            ? "audio"
            : "image"
      }
    />
  ) : null;

  return {
    uploadingImages,
    uploadingEnd,
    uploadingVideo,
    uploadingAudio,
    availableImageSlots,
    processImageFiles,
    processVideoFiles,
    processAudioFiles,
    openImageUpload,
    openEndUpload,
    openVideoUpload,
    openAudioUpload,
    openAnyUpload,
    openGallery,
    fileInputs,
    galleryModal,
  };
}
