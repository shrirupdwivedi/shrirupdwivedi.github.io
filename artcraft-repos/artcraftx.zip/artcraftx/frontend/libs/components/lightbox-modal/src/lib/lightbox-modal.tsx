import { Modal } from "@storyteller/ui-modal";
import { Tooltip } from "@storyteller/ui-tooltip";
import { Button } from "@storyteller/ui-button";
import dayjs from "dayjs";
import {
  ArrowDownToLine,
  Box,
  Check,
  ChevronLeft,
  ChevronRight,
  Copy,
  Globe,
  Link,
  LogOut,
  Music,
  Pause,
  Pencil,
  Play,
  RotateCw,
  Search,
  User,
  Video,
  WandSparkles,
} from "lucide-react";
import { LoadingSpinner } from "@storyteller/ui-loading-spinner";
import { Viewer3D } from "@storyteller/ui-viewer-3d";
import { WaveformAudioPlayer } from "@storyteller/ui-audio-player";
import {
  useEffect,
  useState,
  ReactNode,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { gtagEvent } from "@storyteller/google-analytics";
import { MediaFilesApi, PromptsApi } from "@storyteller/api";
import type { Prompts, UserInfo } from "@storyteller/api";
import { Gravatar } from "@storyteller/ui-gravatar";
import { toast } from "@storyteller/ui-toaster";
import { twMerge } from "tailwind-merge";
import {
} from "@storyteller/ui-action-reminder-modal";
import {
  getCreatorIconPathForModelId,
  getModelDisplayName,
  getProviderDisplayName,
  getProviderIconByName,
} from "@storyteller/model-list";
import useEmblaCarousel from "embla-carousel-react";
import type { EmblaOptionsType } from "embla-carousel";
import {
  addCorsParam,
  getContextImageThumbnail,
  THUMBNAIL_SIZES,
  PLACEHOLDER_IMAGES,
  formatAspectRatio,
  formatDuration,
  formatResolution,
} from "@storyteller/common";
import { TagsSection } from "./tags/TagsSection";

interface LightboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCloseGallery: () => void;
  imageUrl?: string | null;
  imageUrls?: string[];
  actionUrls?: string[];
  mediaTokens?: string[];
  imageAlt?: string;
  onImageError?: () => void;
  title?: string;
  createdAt?: string;
  additionalInfo?: ReactNode;
  downloadUrl?: string;
  mediaId?: string;
  onDownloadClicked?: (url: string, mediaClass?: string) => Promise<void>;
  onAddToSceneClicked?: (
    url: string,
    media_id: string | undefined,
  ) => Promise<void>;
  mediaClass?: string;
  onPromptCopy?: (prompt: string) => void;
  onEditClicked?: (url: string, media_id?: string) => Promise<void> | void;
  onTurnIntoVideoClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onRemoveBackgroundClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onMake3DObjectClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onMake3DWorldClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onRecreateClicked?: (data: {
    promptData: Prompts;
    mediaClass: string | undefined;
  }) => void;
  batchImageToken?: string;
  onNavigatePrev?: () => void;
  onNavigateNext?: () => void;
  onNavigateToMedia?: (mediaToken: string) => void;
  initialIndex?: number;
}

export function LightboxModal({
  isOpen,
  onClose,
  onCloseGallery,
  imageUrl,
  imageUrls,
  actionUrls,
  mediaTokens,
  imageAlt = "",
  onImageError,
  title,
  createdAt,
  additionalInfo,
  downloadUrl, // cdn url of the image
  mediaId, // media id of the image
  onDownloadClicked,
  onAddToSceneClicked,
  mediaClass,
  onEditClicked,
  onTurnIntoVideoClicked,
  onRemoveBackgroundClicked,
  onMake3DObjectClicked,
  onMake3DWorldClicked,
  onRecreateClicked,
  batchImageToken,
  onNavigatePrev,
  onNavigateNext,
  onNavigateToMedia,
  initialIndex,
}: LightboxModalProps) {
  // NB(bt,2025-06-14): We add ?cors=1 to the image url to prevent caching "sec-fetch-mode: no-cors" from
  // the <image> tag request from being cached. If we then drag it into the canvas after it's been cached,
  // it won't be able to load in cors mode and will show blank in the canvas and 3D engine. This is a really
  // stupid hack around this behavior.

  const [refPreviewUrl, setRefPreviewUrl] = useState<string | null>(null);
  const [mediaLoaded, setMediaLoaded] = useState<boolean>(false);
  const [promptData, setPromptData] = useState<Prompts | null>(null);
  const prompt = promptData?.maybe_positive_prompt ?? null;
  const generationProvider = promptData?.maybe_generation_provider ?? null;
  const modelType = promptData?.maybe_model_type ?? null;
  const contextImages = promptData?.maybe_context_images ?? null;
  const aspectRatio = promptData?.maybe_aspect_ratio ?? null;
  const resolution = promptData?.maybe_resolution ?? null;
  const durationSeconds = promptData?.maybe_duration_seconds ?? null;
  const generateAudio = promptData?.maybe_generate_audio ?? null;
  const [mediaWidth, setMediaWidth] = useState<number | null>(null);
  const [mediaHeight, setMediaHeight] = useState<number | null>(null);
  const [promptLoading, setPromptLoading] = useState<boolean>(false);
  const [hasPromptToken, setHasPromptToken] = useState<boolean>(false);
  const [isPromptExpanded, setIsPromptExpanded] = useState<boolean>(false);
  const promptRef = useRef<HTMLDivElement>(null);
  const [isPromptClamped, setIsPromptClamped] = useState<boolean>(false);
  const [promptCopied, setPromptCopied] = useState<boolean>(false);
  const promptCopiedTimeoutRef = useRef<number | null>(null);
  const [batchImages, setBatchImages] = useState<string[] | null>(null);
  const [batchTokens, setBatchTokens] = useState<string[] | null>(null);
  const [creator, setCreator] = useState<UserInfo | null>(null);
  const [shareCopied, setShareCopied] = useState<boolean>(false);
  const shareCopiedTimeoutRef = useRef<number | null>(null);
  const [playingAudioToken, setPlayingAudioToken] = useState<string | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  const stopAudio = useCallback(() => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current = null;
    }
    setPlayingAudioToken(null);
  }, []);

  const handleAudioToggle = useCallback(
    (token: string, url: string) => {
      if (playingAudioToken === token) {
        stopAudio();
      } else {
        stopAudio();
        const audio = new Audio(url);
        audio.volume = 0.7;
        audio.onended = () => {
          setPlayingAudioToken(null);
          audioPlayerRef.current = null;
        };
        audioPlayerRef.current = audio;
        audio.play();
        setPlayingAudioToken(token);
      }
    },
    [playingAudioToken, stopAudio],
  );

  // Stable API instances
  const mediaFilesApi = useMemo(() => new MediaFilesApi(), []);
  const promptsApi = useMemo(() => new PromptsApi(), []);

  useEffect(() => {
    if (isOpen) {
      setRefPreviewUrl(null);
      setSelectedIndex(0);
      setMediaLoaded(false);
      setMediaWidth(null);
      setMediaHeight(null);
      setShareCopied(false);
      setIsPromptExpanded(false);
      stopAudio();
      if (shareCopiedTimeoutRef.current) {
        window.clearTimeout(shareCopiedTimeoutRef.current);
        shareCopiedTimeoutRef.current = null;
      }
    }
  }, [isOpen]);

  useEffect(() => {
    return () => {
      if (shareCopiedTimeoutRef.current) {
        window.clearTimeout(shareCopiedTimeoutRef.current);
        shareCopiedTimeoutRef.current = null;
      }
    };
  }, []);

  // Fetch prompt when mediaId changes — debounced to avoid API spam during
  // rapid next/prev navigation, with cancellation for stale responses.
  useEffect(() => {
    if (!mediaId) {
      setPromptData(null);
      setHasPromptToken(false);
      setPromptLoading(false);
      setCreator(null);
      return;
    }

    // Immediately show skeletons & clear stale data
    setPromptLoading(true);
    setPromptData(null);
    setCreator(null);

    let cancelled = false;

    const timer = setTimeout(async () => {
      try {
        const mediaResponse = await mediaFilesApi.GetMediaFileByToken({
          mediaFileToken: mediaId,
        });
        if (cancelled) return;

        if (mediaResponse.success && mediaResponse.data) {
          setCreator(mediaResponse.data.maybe_creator_user || null);
        }

        if (mediaResponse.success && mediaResponse.data?.maybe_prompt_token) {
          setHasPromptToken(true);
          const promptResponse = await promptsApi.GetPromptsByToken({
            token: mediaResponse.data.maybe_prompt_token,
          });
          if (cancelled) return;

          if (promptResponse.success && promptResponse.data) {
            setPromptData(promptResponse.data);
          } else {
            setPromptData(null);
          }
        } else {
          setHasPromptToken(false);
          setPromptData(null);
        }
      } catch (error) {
        if (cancelled) return;
        console.error("Error fetching prompt:", error);
        setHasPromptToken(false);
        setPromptData(null);
      } finally {
        if (!cancelled) setPromptLoading(false);
      }
    }, 180);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [mediaId, mediaFilesApi, promptsApi]);

  // Detect if prompt text is clamped (overflows the 4-line clamp)
  useEffect(() => {
    if (!promptRef.current || !prompt || promptLoading) {
      setIsPromptClamped(false);
      return;
    }
    // Use requestAnimationFrame to ensure DOM has painted
    const raf = requestAnimationFrame(() => {
      if (promptRef.current) {
        setIsPromptClamped(
          promptRef.current.scrollHeight > promptRef.current.clientHeight,
        );
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [prompt, promptLoading, isPromptExpanded]);

  // Fetch batch images — debounced + cancellable like fetchPrompt above.
  useEffect(() => {
    if (!batchImageToken) {
      setBatchImages(null);
      setBatchTokens(null);
      return;
    }

    // Clear stale batch data immediately
    setBatchImages(null);
    setBatchTokens(null);

    let cancelled = false;

    const timer = setTimeout(async () => {
      try {
        const response = await mediaFilesApi.GetMediaFilesByBatchToken({
          batchToken: batchImageToken,
        });
        if (cancelled) return;

        if (response.success && response.data?.length) {
          const items = response.data
            .map((file: any) => ({
              url: file.media_links?.cdn_url,
              token: file.token,
            }))
            .filter(
              (item): item is { url: string; token: string } =>
                Boolean(item.url) && Boolean(item.token),
            );

          if (items.length > 0) {
            const primaryToken = mediaId;
            const primaryUrl = imageUrl;

            const sortedItems = [...items].sort((a, b) => {
              if (primaryToken === a.token) return -1;
              if (primaryToken === b.token) return 1;
              if (primaryUrl === a.url) return -1;
              if (primaryUrl === b.url) return 1;
              return 0;
            });

            setBatchImages(sortedItems.map((item) => item.url));
            setBatchTokens(sortedItems.map((item) => item.token));
          } else {
            setBatchImages(null);
            setBatchTokens(null);
          }
        } else {
          setBatchImages(null);
          setBatchTokens(null);
        }
      } catch (error: unknown) {
        if (cancelled) return;
        setBatchImages(null);
        setBatchTokens(null);
      }
    }, 200);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [batchImageToken, mediaId, imageUrl, mediaFilesApi]);

  const effectiveImageUrls = useMemo(() => {
    if (batchImages && batchImages.length > 0) {
      return batchImages;
    }
    if (imageUrls && imageUrls.length > 0) {
      return imageUrls;
    }
    return imageUrl ? [imageUrl] : [];
  }, [batchImages, imageUrls, imageUrl]);

  const [selectedIndex, setSelectedIndex] = useState(0);
  const carouselOptions: EmblaOptionsType = useMemo(
    () => ({ loop: false }),
    [],
  );
  const [emblaMainRef, emblaMainApi] = useEmblaCarousel(carouselOptions);
  const [emblaThumbsRef, emblaThumbsApi] = useEmblaCarousel({
    containScroll: "keepSnaps",
    dragFree: true,
  });

  const onThumbClick = useCallback(
    (index: number) => {
      if (!emblaMainApi || !emblaThumbsApi) return;
      emblaMainApi.scrollTo(index);
    },
    [emblaMainApi, emblaThumbsApi],
  );

  const onSelect = useCallback(() => {
    if (!emblaMainApi || !emblaThumbsApi) return;
    const index = emblaMainApi.selectedScrollSnap();
    setSelectedIndex(index);
    emblaThumbsApi.scrollTo(index);
  }, [emblaMainApi, emblaThumbsApi]);

  useEffect(() => {
    if (!emblaMainApi) return;
    onSelect();
    emblaMainApi.on("select", onSelect).on("reInit", onSelect);
  }, [emblaMainApi, onSelect]);

  // Re-initialize Embla when slides change so it picks up the new DOM children
  useEffect(() => {
    emblaMainApi?.reInit();
    emblaThumbsApi?.reInit();
  }, [effectiveImageUrls, emblaMainApi, emblaThumbsApi]);

  useEffect(() => {
    const idx = initialIndex ?? 0;
    setSelectedIndex(idx);
    emblaMainApi?.scrollTo(idx, true);
    emblaThumbsApi?.scrollTo(idx, true);
  }, [batchImageToken, imageUrl, emblaMainApi, emblaThumbsApi]);

  const selectedImageUrl = effectiveImageUrls[selectedIndex] ?? null;
  const actionUrl =
    actionUrls?.[selectedIndex] ?? selectedImageUrl ?? downloadUrl ?? undefined;

  const selectedMediaToken = useMemo(() => {
    const tokenFromBatch = batchTokens?.[selectedIndex];
    const tokenFromProps = mediaTokens?.[selectedIndex];
    return tokenFromBatch ?? tokenFromProps ?? mediaId;
  }, [batchTokens, mediaTokens, selectedIndex, mediaId]);

  useEffect(() => {
    if (!selectedImageUrl) {
      setMediaLoaded(false);
      setMediaWidth(null);
      setMediaHeight(null);
      return;
    }

    setMediaLoaded(false);
    setMediaWidth(null);
    setMediaHeight(null);
    const img = new Image();
    img.src = addCorsParam(selectedImageUrl) || selectedImageUrl;

    const handleLoad = () => setMediaLoaded(true);
    const handleError = () => setMediaLoaded(true);

    if (img.complete) {
      setMediaLoaded(true);
    } else {
      img.addEventListener("load", handleLoad);
      img.addEventListener("error", handleError);
    }

    return () => {
      img.removeEventListener("load", handleLoad);
      img.removeEventListener("error", handleError);
    };
  }, [selectedImageUrl]);

  const derivedMediaClass = useMemo(
    () =>
      mediaClass ??
      (batchImages && batchImages.length > 0 ? "image" : mediaClass),
    [mediaClass, batchImages],
  );

  // Keyboard navigation:
  //   Left / Right  →  carousel slide; at boundary, moves to prev/next bundle
  //   Up / Down     →  previous / next bundle
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

      if (e.key === "ArrowLeft") {
        e.preventDefault();
        if (
          emblaMainApi &&
          effectiveImageUrls.length > 1 &&
          emblaMainApi.canScrollPrev()
        ) {
          emblaMainApi.scrollPrev(true);
        } else {
          onNavigatePrev?.();
        }
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        if (
          emblaMainApi &&
          effectiveImageUrls.length > 1 &&
          emblaMainApi.canScrollNext()
        ) {
          emblaMainApi.scrollNext(true);
        } else {
          onNavigateNext?.();
        }
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        onNavigatePrev?.();
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        onNavigateNext?.();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    isOpen,
    emblaMainApi,
    effectiveImageUrls.length,
    onNavigatePrev,
    onNavigateNext,
  ]);

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        className="rounded-xl bg-ui-modal h-[760px] w-[1200px] max-w-screen min-w-[1000px] min-h-[600px] p-4"
        draggable
        allowBackgroundInteraction={true}
        showClose={true}
        closeOnOutsideClick={false}
        resizable={true}
        backdropClassName="pointer-events-none hidden"
        expandable={true}
      >
        {/* Invisible drag handle strip at the very top for moving */}
        <Modal.DragHandle>
          <div className="absolute left-0 top-0 z-20 h-12 w-full cursor-move rounded-t-xl" />
        </Modal.DragHandle>

        {/* content grid */}
        <div className="flex h-full gap-4">
          {/* image panel - flexible width */}
          <div className="group/nav relative flex h-full flex-1 items-center justify-center overflow-hidden rounded-l-xl bg-black/30">
            {!selectedImageUrl ? (
              <div className="flex h-full w-full items-center justify-center bg-black/30">
                <span className="text-base-fg/60">Image not available</span>
              </div>
            ) : mediaClass === "dimensional" ||
              mediaClass === "mesh" ||
              mediaClass === "splat" ? (
              <div className="h-full w-full">
                <Viewer3D
                  key={selectedImageUrl}
                  modelUrl={selectedImageUrl}
                  isActive={true}
                  showGrid={true}
                  className="h-full w-full"
                />
              </div>
            ) : mediaClass === "video" ? (
              <video
                key={selectedImageUrl}
                controls
                loop={true}
                autoPlay={true}
                className="h-full w-full object-contain"
                onLoadedData={(e) => {
                  setMediaLoaded(true);
                  const el = e.currentTarget;
                  setMediaWidth(el.videoWidth);
                  setMediaHeight(el.videoHeight);
                }}
              >
                <source src={selectedImageUrl as string} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : mediaClass === "audio" ? (
              <div className="flex h-full w-full items-center justify-center px-4 sm:px-8">
                <div className="w-full max-w-xl rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.08] via-white/[0.04] to-white/[0.02] px-4 py-10 sm:px-6">
                  <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-white/10 ring-1 ring-white/15">
                    <Music size="1em" className="text-2xl text-white/70" />
                  </div>
                  <WaveformAudioPlayer
                    key={selectedImageUrl as string}
                    src={selectedImageUrl as string}
                  />
                </div>
              </div>
            ) : (
              <div className="flex h-full w-full flex-col justify-center">
                <div
                  className="embla relative w-full flex-1 overflow-hidden"
                  ref={emblaMainRef}
                >
                  <div className="embla__container flex h-full">
                    {effectiveImageUrls.map((url, idx) => (
                      <div
                        className="embla__slide flex-[0_0_100%]"
                        key={`${url}-${idx}`}
                      >
                        <div className="relative flex h-full items-center justify-center overflow-hidden rounded-lg bg-black/20">
                          <img
                            data-lightbox-modal="true"
                            src={addCorsParam(url) || url}
                            alt={`${imageAlt || "Generated image"} ${idx + 1}`}
                            className="h-full w-full object-contain"
                            onError={(e) => {
                              onImageError?.();
                              if (idx === selectedIndex) {
                                setMediaLoaded(true);
                                e.currentTarget.src =
                                  PLACEHOLDER_IMAGES.DEFAULT;
                                e.currentTarget.style.opacity = "0.3";
                                // Set the `data-brokenurl` property for debugging the broken images:
                                (
                                  e.currentTarget as HTMLImageElement
                                ).dataset.brokenurl = url || "";
                              }
                            }}
                            onLoad={(e) => {
                              if (idx === selectedIndex) {
                                setMediaLoaded(true);
                                const img = e.currentTarget;
                                setMediaWidth(img.naturalWidth);
                                setMediaHeight(img.naturalHeight);
                              }
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {effectiveImageUrls.length > 1 && (
                  <div className="mt-3 px-2">
                    <div
                      className="embla-thumbs overflow-hidden"
                      ref={emblaThumbsRef}
                    >
                      <div className="embla-thumbs__container flex gap-2">
                        {effectiveImageUrls.map((url, idx) => {
                          const isSelected = idx === selectedIndex;
                          return (
                            <button
                              key={`${url}-thumb-${idx}`}
                              type="button"
                              onClick={() => onThumbClick(idx)}
                              className={twMerge(
                                "embla-thumbs__slide relative h-20 w-20 flex-[0_0_5rem] overflow-hidden rounded-md border-2 transition-all",
                                isSelected
                                  ? "border-brand-primary-400 opacity-100"
                                  : "border-transparent opacity-60 hover:border-white/40 hover:opacity-100",
                              )}
                            >
                              <img
                                src={addCorsParam(url) || url}
                                alt={`Thumbnail ${idx + 1}`}
                                className="h-full w-full object-cover bg-black/20"
                              />
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {!mediaLoaded &&
              selectedImageUrl &&
              mediaClass !== "dimensional" &&
              mediaClass !== "mesh" &&
              mediaClass !== "splat" &&
              mediaClass !== "audio" && (
                <div className="absolute inset-0 bg-ui-panel flex items-center justify-center">
                  <LoadingSpinner className="h-12 w-12 text-base-fg" />
                </div>
              )}

            {/* Gallery navigation arrows – only visible on hover */}
            {onNavigatePrev && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onNavigatePrev();
                }}
                className="absolute left-3 top-1/2 -translate-y-1/2 z-30 flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white/70 opacity-0 transition-opacity duration-200 hover:bg-black/70 hover:text-white group-hover/nav:opacity-100 focus:outline-none"
                aria-label="Previous item"
              >
                <ChevronLeft size="1em" className="text-lg" />
              </button>
            )}
            {onNavigateNext && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onNavigateNext();
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 z-30 flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white/70 opacity-0 transition-opacity duration-200 hover:bg-black/70 hover:text-white group-hover/nav:opacity-100 focus:outline-none"
                aria-label="Next item"
              >
                <ChevronRight size="1em" className="text-lg" />
              </button>
            )}
          </div>

          {/* info + actions - fixed width */}
          <div className="flex h-full w-[280px] shrink-0 flex-col">
            <div className="flex-1 overflow-y-auto space-y-5 text-base-fg min-h-0 pb-2">
              {creator ? (
                <div className="sticky top-0 z-10 flex items-center gap-2.5 bg-ui-modal pb-3 pr-10 border-b border-white/5">
                  {creator.core_info ? (
                    <Gravatar
                      size={36}
                      username={creator.username}
                      email_hash={creator.email_gravatar_hash}
                      avatarIndex={creator.core_info.default_avatar.image_index}
                      backgroundIndex={
                        creator.core_info.default_avatar.color_index
                      }
                      className="rounded-xl border-white/10"
                    />
                  ) : (
                    <div className="h-9 w-9 shrink-0 flex items-center justify-center rounded-xl bg-white/10 text-white/50 border border-white/5">
                      <User size="1em" />
                    </div>
                  )}
                  <div className="flex flex-col gap-1 min-w-0">
                    <span className="text-base-fg text-sm font-semibold leading-none truncate">
                      {creator.display_name}
                    </span>
                    <span className="text-base-fg/60 text-xs font-medium">
                      Author
                    </span>
                  </div>
                </div>
              ) : promptLoading ? (
                <div className="sticky top-0 z-10 flex items-center gap-3 bg-ui-modal pb-3 pr-10 border-b border-white/5 animate-pulse">
                  <div className="h-9 w-9 shrink-0 rounded-xl bg-white/10" />
                  <div className="flex flex-col gap-1.5 min-w-0 flex-1">
                    <div className="h-3.5 w-24 rounded bg-white/10" />
                    <div className="h-3 w-12 rounded bg-white/10" />
                  </div>
                </div>
              ) : null}
              {(hasPromptToken || promptLoading) && (
                <>
                  {/* Prompt */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium text-base-fg/90">
                        Prompt
                      </div>
                      {!promptLoading && prompt && (
                        <button
                          className="flex items-center gap-1.5 text-xs text-base-fg/60 hover:text-base-fg transition-colors"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!prompt) return;
                            navigator.clipboard
                              .writeText(prompt)
                              .catch(() => {});
                            toast.success("Prompt copied");
                            setPromptCopied(true);
                            if (promptCopiedTimeoutRef.current) {
                              window.clearTimeout(
                                promptCopiedTimeoutRef.current,
                              );
                            }
                            promptCopiedTimeoutRef.current = window.setTimeout(
                              () => {
                                setPromptCopied(false);
                                promptCopiedTimeoutRef.current = null;
                              },
                              1500,
                            );
                          }}
                        >
                          {promptCopied ? (
                            <Check className="h-3 w-3" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                          <span>{promptCopied ? "Copied!" : "Copy"}</span>
                        </button>
                      )}
                    </div>
                    <div
                      className="text-sm text-base-fg break-words p-3 rounded-lg leading-relaxed"
                      style={{
                        background: "rgb(var(--st-controls-rgb) / 0.20)",
                      }}
                    >
                      {promptLoading ? (
                        <div className="animate-pulse space-y-2">
                          <div className="h-3 w-full rounded bg-white/10" />
                          <div className="h-3 w-4/5 rounded bg-white/10" />
                          <div className="h-3 w-3/5 rounded bg-white/10" />
                        </div>
                      ) : (
                        <div
                          ref={promptRef}
                          className={twMerge(
                            !isPromptExpanded && "line-clamp-4",
                          )}
                        >
                          {prompt || (
                            <span className="text-sm text-base-fg">
                              No prompt
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {!promptLoading &&
                      prompt &&
                      (isPromptClamped || isPromptExpanded) && (
                        <button
                          className="flex w-full items-center justify-center gap-1 text-xs text-base-fg/70 hover:text-base-fg transition-colors py-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsPromptExpanded((prev) => !prev);
                          }}
                        >
                          <span>{isPromptExpanded ? "Hide" : "See all"}</span>
                          <svg
                            className={twMerge(
                              "h-3 w-3 transition-transform duration-200",
                              isPromptExpanded && "rotate-180",
                            )}
                            viewBox="0 0 12 12"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              d="M2.5 4.5L6 8L9.5 4.5"
                              stroke="currentColor"
                              strokeWidth="1.5"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        </button>
                      )}
                  </div>

                  {promptLoading ? (
                    /* Skeleton placeholders while fetching metadata */
                    <>
                      {/* Reference Images skeleton */}
                      <div className="space-y-1.5 animate-pulse">
                        <div className="h-3.5 w-28 rounded bg-white/10" />
                        <div className="flex gap-1.5">
                          <div className="h-12 w-12 rounded-lg bg-white/10" />
                          <div className="h-12 w-12 rounded-lg bg-white/10" />
                          <div className="h-12 w-12 rounded-lg bg-white/10" />
                        </div>
                      </div>
                      {/* Information skeleton */}
                      <div className="space-y-1.5 animate-pulse">
                        <div className="h-3.5 w-24 rounded bg-white/10" />
                        <div
                          className="flex flex-col rounded-lg border border-ui-panel-border overflow-hidden"
                          style={{
                            background: "rgb(var(--st-controls-rgb) / 0.20)",
                          }}
                        >
                          {Array.from({ length: 5 }).map((_, i) => (
                            <div
                              key={i}
                              className="flex items-center justify-between py-2.5 px-3 border-b border-white/5 last:border-0"
                            >
                              <div className="h-3.5 w-16 rounded bg-white/10" />
                              <div className="h-3.5 w-24 rounded bg-white/10" />
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {contextImages && contextImages.length > 0 && (
                        <div className="space-y-1.5">
                          <div className="text-sm font-medium text-base-fg/90">
                            Reference Media
                          </div>
                          <div className="grid grid-cols-5 gap-1.5 w-fit">
                            {contextImages.map((contextImage, index) => {
                              const isAudio = contextImage.semantic === "audioref";
                              const isVideoRef = contextImage.semantic === "vid_ref";
                              const { thumbnail, fullSize } =
                                getContextImageThumbnail(contextImage, {
                                  size: THUMBNAIL_SIZES.SMALL,
                                });
                              const isPlayingThis = playingAudioToken === contextImage.media_token;

                              return (
                                <Tooltip
                                  key={contextImage.media_token}
                                  position="top"
                                  interactive
                                  strategy="fixed"
                                  delay={150}
                                  zIndex={50}
                                  className="p-1"
                                  content={
                                    <div className="flex flex-col gap-1.5 min-w-[100px]">
                                      {!isAudio && !isVideoRef && (
                                        <button
                                          className="text-xs text-left text-base-fg/80 hover:text-base-fg transition-colors py-1 px-1 rounded hover:bg-white/5"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setRefPreviewUrl(fullSize);
                                          }}
                                        >
                                          <Search
                                            size="1em"
                                            className="mr-1.5"
                                          />
                                          Preview image
                                        </button>
                                      )}
                                      {onNavigateToMedia && (
                                        <button
                                          className="text-xs text-left text-base-fg/80 hover:text-base-fg transition-colors py-1 px-1 rounded hover:bg-white/5"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            onNavigateToMedia(
                                              contextImage.media_token,
                                            );
                                          }}
                                        >
                                          <LogOut
                                            size="1em"
                                            className="mr-1.5"
                                          />
                                          View as media
                                        </button>
                                      )}
                                    </div>
                                  }
                                >
                                  <div
                                    className="glass relative aspect-square overflow-hidden rounded-lg w-12 border-2 border-white/30 hover:border-white/80 transition-all group cursor-pointer"
                                    onClick={() => {
                                      if (isAudio) {
                                        handleAudioToggle(contextImage.media_token, contextImage.media_links.cdn_url);
                                      } else if (!isVideoRef) {
                                        setRefPreviewUrl(fullSize);
                                      }
                                    }}
                                  >
                                    {isAudio ? (
                                      <div className="h-full w-full flex items-center justify-center bg-white/5">
                                        {isPlayingThis ? (
                                          <Pause
                                            size="1em"
                                            className="text-base-fg/70 text-lg"
                                          />
                                        ) : (
                                          <Play
                                            size="1em"
                                            className="text-base-fg/70 text-lg"
                                          />
                                        )}
                                      </div>
                                    ) : (
                                      <>
                                        <img
                                          src={thumbnail}
                                          alt={`Reference ${index + 1}`}
                                          className="h-full w-full object-cover"
                                        />
                                        {isVideoRef && (
                                          <div className="absolute inset-0 flex items-center justify-center">
                                            <Video
                                              size="1em"
                                              className="text-white/80 text-sm drop-shadow-lg"
                                            />
                                          </div>
                                        )}
                                      </>
                                    )}
                                  </div>
                                </Tooltip>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      <InfoSection
                        modelType={modelType}
                        generationProvider={generationProvider}
                        aspectRatio={aspectRatio}
                        resolution={resolution}
                        durationSeconds={durationSeconds}
                        generateAudio={generateAudio}
                        mediaWidth={mediaWidth}
                        mediaHeight={mediaHeight}
                        createdAt={createdAt}
                      />
                    </>
                  )}
                </>
              )}

              {!hasPromptToken && !promptLoading && (
                <InfoSection
                  modelType={null}
                  generationProvider={null}
                  aspectRatio={null}
                  resolution={null}
                  durationSeconds={null}
                  generateAudio={null}
                  mediaWidth={mediaWidth}
                  mediaHeight={mediaHeight}
                  createdAt={createdAt}
                />
              )}

              <TagsSection mediaToken={mediaId} creator={creator} />

              {additionalInfo}
            </div>

            {/* buttons with spacing */}
            {actionUrl && (
              <div className="mt-4 grid grid-cols-2 gap-1.5">
                {onRecreateClicked &&
                  hasPromptToken &&
                  promptData &&
                  (derivedMediaClass === "image" ||
                    derivedMediaClass === "video") && (
                    <Button
                      className="w-full col-span-2 py-1.5 text-[13px]"
                      variant="primary"
                      icon={RotateCw}
                      onClick={(e) => {
                        e.stopPropagation();
                        gtagEvent("recreate_clicked");
                        onRecreateClicked({
                          promptData,
                          mediaClass: derivedMediaClass,
                        });
                      }}
                    >
                      Recreate
                    </Button>
                  )}

                {onEditClicked &&
                  actionUrl &&
                  derivedMediaClass === "image" && (
                    <Button
                      className="w-full py-1.5 text-[13px]"
                      variant="primary"
                      icon={Pencil}
                      onClick={async (e) => {
                        e.stopPropagation();
                        gtagEvent("edit_image_clicked");
                        await onEditClicked(actionUrl, selectedMediaToken);
                      }}
                    >
                      Edit Image
                    </Button>
                  )}

                {onTurnIntoVideoClicked &&
                  actionUrl &&
                  derivedMediaClass === "image" && (
                    <Button
                      className="w-full py-1.5 text-[13px]"
                      variant="primary"
                      icon={Video}
                      onClick={async (e) => {
                        e.stopPropagation();
                        gtagEvent("turn_into_video_clicked");
                        await onTurnIntoVideoClicked(
                          actionUrl,
                          selectedMediaToken,
                        );
                      }}
                    >
                      Make Video
                    </Button>
                  )}

                {onRemoveBackgroundClicked &&
                  actionUrl &&
                  derivedMediaClass === "image" && (
                    <Button
                      className="w-full py-1.5 text-[13px]"
                      variant="secondary"
                      icon={WandSparkles}
                      onClick={async (e) => {
                        e.stopPropagation();
                        gtagEvent("remove_background_clicked");
                        await onRemoveBackgroundClicked(
                          actionUrl,
                          selectedMediaToken,
                        );
                        onClose();
                        onCloseGallery();
                      }}
                    >
                      Remove BG
                    </Button>
                  )}

                {onMake3DObjectClicked &&
                  actionUrl &&
                  derivedMediaClass === "image" && (
                    <Button
                      className="w-full py-1.5 text-[13px]"
                      variant="secondary"
                      icon={Box}
                      onClick={async (e) => {
                        e.stopPropagation();
                        gtagEvent("image_to_3d_clicked");
                        await onMake3DObjectClicked(
                          actionUrl,
                          selectedMediaToken,
                        );
                        onClose();
                        onCloseGallery();
                      }}
                    >
                      Make 3D
                    </Button>
                  )}

                {onMake3DWorldClicked &&
                  actionUrl &&
                  derivedMediaClass === "image" && (
                    <Button
                      className="w-full py-1.5 text-[13px]"
                      variant="secondary"
                      icon={Globe}
                      onClick={async (e) => {
                        e.stopPropagation();
                        gtagEvent("image_to_3d_world_clicked");
                        await onMake3DWorldClicked(
                          actionUrl,
                          selectedMediaToken,
                        );
                        onClose();
                        onCloseGallery();
                      }}
                    >
                      Make 3D World
                    </Button>
                  )}

                {onDownloadClicked && actionUrl && (
                  <Button
                    className={
                      derivedMediaClass === "image"
                        ? "w-full py-1.5 text-[13px]"
                        : "w-full col-span-2 py-1.5 text-[13px]"
                    }
                    variant="secondary"
                    icon={ArrowDownToLine}
                    onClick={async (e) => {
                      e.stopPropagation();
                      gtagEvent("download_clicked");
                      await onDownloadClicked(actionUrl, mediaClass);
                    }}
                  >
                    Download
                  </Button>
                )}

                {onAddToSceneClicked && actionUrl && (
                  <Button
                    className="w-full py-1.5 text-[13px]"
                    variant="secondary"
                    onClick={async (e) => {
                      e.stopPropagation();
                      gtagEvent("add_to_scene_clicked");
                      await onAddToSceneClicked(actionUrl, selectedMediaToken);
                      onClose();
                      onCloseGallery();
                    }}
                  >
                    Add to Scene
                  </Button>
                )}

                {selectedMediaToken && (
                  <Button
                    className="w-full py-1.5 text-[13px]"
                    variant="secondary"
                    icon={shareCopied ? Check : Link}
                    onClick={async (e) => {
                      e.stopPropagation();
                      gtagEvent("share_link_copied");
                      const shareUrl = `https://getartcraft.com/media/${selectedMediaToken}`;
                      try {
                        await navigator.clipboard.writeText(shareUrl);
                        toast.success("Share link copied");
                        setShareCopied(true);
                        if (shareCopiedTimeoutRef.current) {
                          window.clearTimeout(shareCopiedTimeoutRef.current);
                        }
                        shareCopiedTimeoutRef.current = window.setTimeout(
                          () => {
                            setShareCopied(false);
                            shareCopiedTimeoutRef.current = null;
                          },
                          1500,
                        );
                      } catch (err) {
                        toast.error("Unable to copy link");
                      }
                    }}
                  >
                    {shareCopied ? "Link Copied!" : "Share"}
                  </Button>
                )}

              </div>
            )}
          </div>
        </div>
      </Modal>

      {refPreviewUrl && (
        <Modal
          isOpen={true}
          onClose={() => setRefPreviewUrl(null)}
          className="rounded-xl bg-ui-modal w-auto h-auto max-w-[75vw] max-h-[75vh] p-4"
          draggable
          allowBackgroundInteraction={true}
          showClose={true}
          closeOnOutsideClick={true}
          resizable={false}
          backdropClassName=""
          expandable={false}
        >
          <Modal.DragHandle>
            <div className="absolute left-0 top-0 z-20 h-12 w-full cursor-move rounded-t-xl" />
          </Modal.DragHandle>
          <div className="relative flex items-center justify-center overflow-hidden rounded-xl bg-black/30">
            <img
              src={addCorsParam(refPreviewUrl) || refPreviewUrl}
              alt="Reference preview"
              className="max-w-[72vw] max-h-[70vh] object-contain"
            />
          </div>
        </Modal>
      )}
    </>
  );
}

interface InfoSectionProps {
  modelType: string | null;
  generationProvider: string | null;
  aspectRatio: string | null;
  resolution: string | null;
  durationSeconds: number | null;
  generateAudio: boolean | null;
  mediaWidth: number | null;
  mediaHeight: number | null;
  createdAt?: string;
}

function InfoSection({
  modelType,
  generationProvider,
  aspectRatio,
  resolution,
  durationSeconds,
  generateAudio,
  mediaWidth,
  mediaHeight,
  createdAt,
}: InfoSectionProps) {
  const hasAnyInfo =
    !!modelType ||
    !!generationProvider ||
    !!aspectRatio ||
    !!resolution ||
    durationSeconds != null ||
    generateAudio != null ||
    (!!mediaWidth && !!mediaHeight) ||
    !!createdAt;

  if (!hasAnyInfo) return null;

  return (
    <div className="space-y-1.5">
      <div className="text-sm font-medium text-base-fg/90">Information</div>
      <div
        className="flex flex-col rounded-lg border border-ui-panel-border overflow-hidden"
        style={{ background: "rgb(var(--st-controls-rgb) / 0.20)" }}
      >
        {modelType && (
          <InfoRow
            label="Model"
            value={
              <>
                <img
                  src={getCreatorIconPathForModelId(modelType)}
                  alt="Model creator logo"
                  className="h-4 w-4 invert"
                />
                <span>{getModelDisplayName(modelType)}</span>
              </>
            }
          />
        )}
        {generationProvider && (
          <InfoRow
            label="Provider"
            value={
              <>
                {getProviderIconByName(generationProvider, "h-4 w-4 invert")}
                <span>{getProviderDisplayName(generationProvider)}</span>
              </>
            }
          />
        )}
        {aspectRatio && (
          <InfoRow
            label="Aspect Ratio"
            value={formatAspectRatio(aspectRatio)}
          />
        )}
        {resolution && (
          <InfoRow label="Resolution" value={formatResolution(resolution)} />
        )}
        {durationSeconds != null && (
          <InfoRow label="Duration" value={formatDuration(durationSeconds)} />
        )}
        {generateAudio != null && (
          <InfoRow label="Audio" value={generateAudio ? "On" : "Off"} />
        )}
        {mediaWidth && mediaHeight && (
          <InfoRow label="Size" value={`${mediaWidth} × ${mediaHeight}`} />
        )}
        {createdAt && (
          <InfoRow
            label="Created"
            value={dayjs(createdAt).format("MMM D, YYYY h:mm:ss A")}
          />
        )}
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-center justify-between py-2 px-3 border-b border-white/5 last:border-0">
      <span className="text-sm text-base-fg/70 font-medium">{label}</span>
      <span className="text-sm text-base-fg flex items-center gap-2">
        {value}
      </span>
    </div>
  );
}

export default LightboxModal;
