import { Modal } from "@storyteller/ui-modal";
import { LightboxModal } from "@storyteller/ui-lightbox-modal";
import { Button } from "@storyteller/ui-button";
import { CloseButton } from "@storyteller/ui-close-button";
import { LoadingSpinner } from "@storyteller/ui-loading-spinner";
import type { Prompts } from "@storyteller/api";
import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from "react";
import { createPortal } from "react-dom";
import {
  FilterMediaClasses,
  FilterMediaType,
  FoldersApi,
  GalleryModalApi,
  MediaFilesApi,
  TagsApi,
  UsersApi,
} from "@storyteller/api";
import type {
  FolderInfo,
  FolderMediaFileListItem,
  TagDetails,
  TagMediaFileListItem,
} from "@storyteller/api";
import type { GalleryFolder } from "./GalleryDraggableItem";
import { compareFolders } from "./folderUtils";
import {
  mapFolderInfo,
  galleryItemToCollageUrl,
  mergeCollageUrls,
} from "./folderMapping";
import { promptFolderDrop } from "./promptFolderDrop";
import { FolderColorRow } from "./FolderColorRow";
import { FolderNameDialog } from "./FolderNameDialog";
import { toast } from "@storyteller/ui-toaster";
import { twMerge } from "tailwind-merge";
import { GalleryDraggableItem } from "./GalleryDraggableItem";
import { GalleryFolderChip } from "./GalleryFolderChip";
import { useSignals } from "@preact/signals-react/runtime";
import {
  getThumbnailUrl,
  getMediaThumbnail,
  THUMBNAIL_SIZES,
  PLACEHOLDER_IMAGES,
  is3DModelUrl,
} from "@storyteller/common";
import {
  galleryModalDraggingUnder,
  galleryReopenAfterDragSignal,
  galleryModalVisibleViewMode,
  galleryModalLightboxMediaId,
  galleryModalLightboxImage,
  galleryModalLightboxVisible,
  galleryModalLightboxNavPrev,
  galleryModalLightboxNavNext,
} from "./galleryModalSignals";
import galleryDnd, { FOLDER_DROP_EVENT } from "./galleryDnd";
import {
  Box,
  Ellipsis,
  Expand,
  Folder,
  FolderPlus,
  Globe,
  Grid2x2,
  Image,
  type LucideIcon,
  Music,
  Pencil,
  Plus,
  RefreshCw,
  Shrink,
  Star,
  Tag,
  Trash2,
  Upload,
  Video,
  X,
} from "lucide-react";
import {
  useMediaPromptTokens,
  usePrompts,
} from "@storyteller/ui-generation-list";
import { SliderV2 } from "@storyteller/ui-sliderv2";
import { Tooltip } from "@storyteller/ui-tooltip";
import {
  showActionReminder,
  isActionReminderOpen,
} from "@storyteller/ui-action-reminder-modal";
import { Checkbox } from "@storyteller/ui-checkbox";

// ─── Module-level gallery cache ───────────────────────────────────────────────
// Persists gallery items across modal open/close so users see content instantly.
interface GalleryCacheEntry {
  items: GalleryItem[];
  pageIndex: number;
  hasMore: boolean;
  timestamp: number;
  /** Keyset cursor for the mesh/splat tabs (their endpoints paginate by cursor). */
  cursor?: string;
}

const galleryCacheMap = new Map<string, GalleryCacheEntry>();
const usersApiSingleton = new UsersApi();

/** Clear the module-level gallery item cache. Call on logout so the next user doesn't see stale items. */
export const clearGalleryCache = () => {
  galleryCacheMap.clear();
};

/** Fetch the current session's username fresh every time — the session may have changed (logout/login). */
async function fetchCurrentUsername(): Promise<string | null> {
  try {
    const session = await usersApiSingleton.GetSession();
    if (session.success && session.data?.user) {
      return session.data.user.username;
    }
  } catch {
    // ignore
  }
  return null;
}

// ─── Skeleton loader component ────────────────────────────────────────────────
const SKELETON_COUNT = 15;

const SkeletonGrid = ({ columns }: { columns: number }) => {
  const gapClass = columns <= 4 ? "gap-2" : columns <= 7 ? "gap-2" : "gap-0.5";
  return (
    <div className="space-y-6 p-4 animate-in fade-in duration-200">
      {/* Fake date heading */}
      <div>
        <div className="h-4 w-24 rounded bg-white/[0.06] mb-3" />
        <div
          className={twMerge("grid", gapClass)}
          style={{
            gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
          }}
        >
          {Array.from({ length: SKELETON_COUNT }).map((_, i) => (
            <div key={i} className="aspect-square rounded-md overflow-hidden">
              <div
                className="h-full w-full bg-white/[0.06]"
                style={{
                  animation: `pulse 1.8s ease-in-out ${i * 0.07}s infinite`,
                }}
              />
            </div>
          ))}
        </div>
      </div>
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 0.8; }
        }
      `}</style>
    </div>
  );
};

// ─── Lazy date-group virtualization ───────────────────────────────────────────
// Bidirectional: mounts groups when they scroll within 800px of the viewport,
// and unmounts them when they scroll beyond that range. Measured heights are
// used for placeholders so scroll position stays rock-solid.

export interface LazyDateGroupProps {
  /** If true the group renders on mount (use for first N visible groups). */
  eager: boolean;
  /** Estimated item count for placeholder height calculation. */
  itemCount: number;
  /** Current grid column count, used to estimate placeholder height. */
  gridColumns: number;
  /** The scroll container used as IntersectionObserver root. */
  scrollRoot: HTMLDivElement | null;
  children: React.ReactNode;
}

export const LazyDateGroup = React.memo(
  ({
    eager,
    itemCount,
    gridColumns,
    scrollRoot,
    children,
  }: LazyDateGroupProps) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [isNearViewport, setIsNearViewport] = useState(eager);
    // Store the last measured height so placeholders match exactly
    const measuredHeightRef = useRef<number | null>(null);

    // Measure rendered height on every commit while visible
    useEffect(() => {
      if (isNearViewport && containerRef.current) {
        measuredHeightRef.current = containerRef.current.offsetHeight;
      }
    });

    useEffect(() => {
      const el = containerRef.current;
      if (!el) return;

      const observer = new IntersectionObserver(
        ([entry]) => {
          setIsNearViewport(entry.isIntersecting);
        },
        {
          root: scrollRoot,
          rootMargin: "800px 0px", // mount/unmount buffer
        },
      );
      observer.observe(el);
      return () => observer.disconnect();
    }, [scrollRoot]);

    if (!isNearViewport) {
      // Use measured height if available, otherwise estimate
      const height =
        measuredHeightRef.current ??
        Math.ceil(itemCount / gridColumns) * 120 + 36;
      return (
        <div
          ref={containerRef}
          style={{ height, minHeight: height }}
          aria-hidden
        />
      );
    }

    return <div ref={containerRef}>{children}</div>;
  },
);
LazyDateGroup.displayName = "LazyDateGroup";

export interface GalleryItem {
  id: string;
  label: string;
  thumbnail: string | null;
  // Thumbnail template is not a usable URL yet. It has some variables
  // like `{WIDTH}` which must be replaced downstream.
  thumbnailUrlTemplate?: string;
  fullImage?: string | null;
  createdAt: string;
  mediaClass?: string;
  assetType?: string;
  isUpload?: boolean;
  batchImageToken?: string;
  mediaTokens?: string[];
  imageUrls?: string[];
  /** Prompt token, when the list endpoint returns one (used by audio tiles). */
  promptToken?: string;
  /** Duration for audio/video items, when known. */
  durationMillis?: number;
}

interface GroupedItems {
  [date: string]: GalleryItem[];
}

type ModalMode = "select" | "view";

interface GalleryModalProps {
  onClose?: () => void;
  mode: ModalMode;
  selectedItemIds?: string[];
  onSelectItem?: (id: string) => void;
  maxSelections?: number;
  onUseSelected?: (selectedItems: GalleryItem[]) => void;
  useSelectedLoading?: boolean;
  /** When set, the "not logged in" state shows a Login button that calls this
   *  (e.g. open the login modal on desktop, navigate to /login on web) instead
   *  of a Retry link. */
  onLoginClick?: () => void;
  onDownloadClicked?: (url: string, mediaClass?: string) => Promise<void>;
  onAddToSceneClicked?: (
    url: string,
    media_id: string | undefined,
  ) => Promise<void>;
  isOpen?: boolean;
  forceFilter?: string;
  onEditClicked?: (url: string, media_id?: string) => Promise<void> | void;
  onTurnIntoVideoClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onRemoveBackgroundClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onMake3DObjectClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onMake3DWorldClicked?: (
    url: string,
    media_id?: string,
  ) => Promise<void> | void;
  onRecreateClicked?: (data: {
    promptData: Prompts;
    mediaClass: string | undefined;
  }) => void;
  /** Hide the filter popover entirely. When unset, the filter button shows (optionally locked via forceFilter). */
  hideFilter?: boolean;
  /** Delete a media file by id. Required in view mode to show any delete UI. */
  onDeleteMedia?: (id: string) => Promise<unknown>;
  /** Wire external event sources (generation-complete, media-deleted). Returns an unsubscribe fn. */
  subscribeToMediaEvents?: (handlers: {
    onGenerationComplete: () => void;
    onMediaDeleted: (mediaId: string) => void;
  }) => () => void;
}

// --- Constants (never re-created) ---

const EMPTY_SELECTED_IDS: string[] = [];

const SIDEBAR_FILTERS = [
  { id: "all", label: "All Assets", icon: Grid2x2 },
  { id: "image", label: "Image", icon: Image },
  { id: "video", label: "Video", icon: Video },
  { id: "audio", label: "Audio", icon: Music },
  { id: "mesh", label: "Mesh", icon: Box },
  { id: "splat", label: "Splat", icon: Globe },
  { id: "uploaded", label: "Uploaded", icon: Upload },
];

// Media classes for the user-list endpoint. The Mesh and Splat tabs don't use
// it — they call the session mesh/splat list endpoints instead.
const getFilterMediaClass = (filter: string) => {
  switch (filter) {
    case "image":
      return [FilterMediaClasses.IMAGE];
    case "video":
      return [FilterMediaClasses.VIDEO];
    case "audio":
      return [FilterMediaClasses.AUDIO];
    case "uploaded":
      return [
        FilterMediaClasses.IMAGE,
        FilterMediaClasses.VIDEO,
        FilterMediaClasses.DIMENSIONAL,
        FilterMediaClasses.MESH,
        FilterMediaClasses.SPLAT,
      ];
    default:
      return undefined;
  }
};

// The backend used to file all 3D media under the (now deprecated) coarse
// "dimensional" class; new records are "mesh" or "splat". Treat all three as 3D.
const is3DClass = (mediaClass: string | undefined | null): boolean =>
  mediaClass === "dimensional" || mediaClass === "mesh" || mediaClass === "splat";

const getLabel = (item: any) => {
  if (!!item.maybe_title) {
    return item.maybe_title;
  }
  switch (item.media_class) {
    case "image":
      return "Image Generation";
    case "video":
      return "Video Generation";
    case "audio":
      return "Audio Generation";
    case "dimensional":
    case "mesh":
      return "3D Object Generation";
    case "splat":
      return "3D World Generation";
    default:
      return "Generation";
  }
};

const formatDate = (date: string) => {
  const d = new Date(date);
  return d.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
};

const PAGE_SIZE = 100;

// Folder media is paginated via cursor; one scroll page at a time.
const FOLDER_PAGE_SIZE = 60;

// The sidebar shows the five most-used tags; "All tags" opens the word cloud.
const SIDEBAR_TAG_LIMIT = 5;

const hashString = (s: string): number => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
};

/**
 * The all-tags browser view: a word cloud where font size and emphasis encode
 * use count, and a deterministic hash shuffle spreads big words among small
 * ones (stable order — no reflow between renders). Mirrors the webapp's
 * library Tags tab.
 */
function TagCloudView({
  tags,
  onOpen,
}: {
  tags: TagDetails[];
  onOpen: (tagToken: string) => void;
}) {
  const words = useMemo(() => {
    const counts = tags.map((t) => t.use_count);
    const min = Math.min(...counts);
    const span = Math.max(1, Math.max(...counts) - min);
    return [...tags]
      .sort((a, b) => hashString(a.tag_token) - hashString(b.tag_token))
      .map((tag) => ({
        tag,
        // sqrt compresses the top end so one mega-tag doesn't dwarf the rest.
        weight: Math.sqrt((tag.use_count - min) / span),
      }));
  }, [tags]);

  return (
    <div className="flex min-h-full items-center justify-center p-8">
      <div className="flex max-w-3xl flex-wrap items-baseline justify-center gap-x-5 gap-y-3 select-none">
        {words.map(({ tag, weight }) => (
          <button
            key={tag.tag_token}
            type="button"
            onClick={() => onOpen(tag.tag_token)}
            title={`${tag.use_count} file${tag.use_count === 1 ? "" : "s"}`}
            style={{ fontSize: `${Math.round(15 + weight * 33)}px` }}
            className={twMerge(
              "max-w-full truncate leading-none transition-all duration-200 hover:scale-110 hover:text-violet-400",
              hashString(tag.tag_token) % 2 === 0
                ? "hover:rotate-2"
                : "hover:-rotate-2",
              weight > 0.66
                ? "font-bold text-base-fg"
                : weight > 0.33
                  ? "font-semibold text-base-fg/70"
                  : "font-medium text-base-fg/40",
            )}
          >
            {tag.tag_value}
          </button>
        ))}
      </div>
    </div>
  );
}

const SHOW_UPLOADS_STORAGE_KEY = "gallery-modal-show-uploads";

/** Small thumbnail used in the bulk-selection footer bar. */
const BulkThumb = ({
  thumbnail,
  placeholderIcon: PlaceholderIcon,
}: {
  thumbnail: string | null;
  placeholderIcon: LucideIcon;
}) => {
  const [failed, setFailed] = useState(false);
  const showImage = !!thumbnail && !failed;

  return (
    <div className="h-8 w-8 rounded overflow-hidden border-2 border-ui-panel bg-black/30 flex-shrink-0">
      {showImage ? (
        <img
          src={thumbnail}
          alt=""
          className="h-full w-full object-cover"
          onError={() => setFailed(true)}
        />
      ) : (
        <div className="h-full w-full flex items-center justify-center bg-black/50">
          <PlaceholderIcon size="1em" className="text-xs text-white/50" />
        </div>
      )}
    </div>
  );
};

/** Reusable folder context menu (star + color + new subfolder + rename + delete). */
const FolderContextMenuItems = ({
  folderId,
  hasStar,
  colorCode,
  onRename,
  onDelete,
  onNewSubfolder,
  onToggleStar,
  onSetColor,
  className,
  style,
}: {
  folderId: string;
  hasStar?: boolean;
  colorCode?: string | null;
  onRename: (id: string) => void;
  onDelete: (id: string) => void;
  onNewSubfolder: (parentId: string) => void;
  onToggleStar: (id: string, hasStar: boolean) => void;
  onSetColor: (id: string, color: string | null) => void;
  className?: string;
  style?: React.CSSProperties;
}) => (
  <div
    className={twMerge(
      "min-w-44 rounded-lg border border-ui-panel-border bg-ui-panel p-1 shadow-xl z-[59]",
      className,
    )}
    style={style}
  >
    <button
      type="button"
      className="flex w-full items-center gap-2 px-2 py-2 rounded-md hover:bg-ui-controls/60 text-sm text-base-fg"
      onClick={() => onToggleStar(folderId, !hasStar)}
    >
      <Star
        size="1em"
        className={twMerge(
          "w-4",
          hasStar ? "text-amber-400" : "text-base-fg/40",
        )}
      />
      <span>{hasStar ? "Unstar" : "Star"}</span>
    </button>
    <FolderColorRow
      colorCode={colorCode}
      onSetColor={(c) => onSetColor(folderId, c)}
    />
    <div className="mx-1.5 my-1 border-t border-ui-panel-border" />
    <button
      type="button"
      className="flex w-full items-center gap-2 px-2 py-2 rounded-md hover:bg-ui-controls/60 text-sm text-base-fg"
      onClick={() => onNewSubfolder(folderId)}
    >
      <FolderPlus size="1em" className="w-4" />
      <span>New subfolder</span>
    </button>
    <button
      type="button"
      className="flex w-full items-center gap-2 px-2 py-2 rounded-md hover:bg-ui-controls/60 text-sm text-base-fg"
      onClick={() => onRename(folderId)}
    >
      <Pencil size="1em" className="w-4" />
      <span>Rename</span>
    </button>
    <button
      type="button"
      className="flex w-full items-center gap-2 px-2 py-2 rounded-md hover:bg-ui-controls/60 text-sm text-red"
      onClick={() => onDelete(folderId)}
    >
      <Trash2 size="1em" className="w-4" />
      <span>Delete folder</span>
    </button>
  </div>
);

export const GalleryModal = React.memo(
  ({
    onClose,
    mode = "view",
    selectedItemIds = EMPTY_SELECTED_IDS,
    onSelectItem,
    maxSelections = 4,
    onUseSelected,
    useSelectedLoading,
    onLoginClick,
    onDownloadClicked,
    onAddToSceneClicked,
    isOpen,
    forceFilter,
    onEditClicked,
    onTurnIntoVideoClicked,
    onRemoveBackgroundClicked,
    onMake3DObjectClicked,
    onMake3DWorldClicked,
    onRecreateClicked,
    hideFilter,
    onDeleteMedia,
    subscribeToMediaEvents,
  }: GalleryModalProps) => {
    const [loading, setLoading] = useState(false);
    // Separate state for pagination spinner (bottom of list) — not shared with background refresh
    const [paginationLoading, setPaginationLoading] = useState(false);
    // Ref-based lock to prevent re-entrant loadItems calls
    const isLoadingRef = useRef(false);
    // Lightbox state is now handled via signals
    const lightboxImageSignal = galleryModalLightboxImage;
    const lightboxVisibleSignal = galleryModalLightboxVisible;
    const failedImageUrls = useRef<Set<string>>(new Set());
    const scrollContainerRef = useRef<HTMLDivElement>(null);
    // Marquee (drag-rectangle) selection — view mode only. The rectangle is
    // positioned imperatively (no React state per frame) and tile rects are
    // cached at drag start; see handleMarqueePointerDown below.
    const marqueeRef = useRef<HTMLDivElement>(null);
    const marqueeRaf = useRef(0);
    const [username, setUsername] = useState<string>("");
    const [usernameError, setUsernameError] = useState(false);
    const [usernameRetryCount, setUsernameRetryCount] = useState(0);
    const [activeFilter, setActiveFilter] = useState(forceFilter || "all");
    const minColumns = 3;
    const maxColumns = 12;
    // Default gridColumns to 5 on desktop; narrow screens are locked to 2 columns
    const defaultGridColumns = 5;
    const [isNarrow, setIsNarrow] = useState(
      () => typeof window !== "undefined" && window.innerWidth < 640,
    );
    useEffect(() => {
      const handler = () => setIsNarrow(window.innerWidth < 640);
      window.addEventListener("resize", handler);
      return () => window.removeEventListener("resize", handler);
    }, []);
    const [sliderValue, setSliderValue] = useState(
      maxColumns - (defaultGridColumns - minColumns),
    );
    const gridColumns = isNarrow ? 2 : maxColumns - (sliderValue - minColumns);
    const [imageFit, setImageFit] = useState<"cover" | "contain">("contain");
    const [showUploads, setShowUploads] = useState<boolean>(() => {
      try {
        const stored = localStorage.getItem(SHOW_UPLOADS_STORAGE_KEY);
        return stored === null ? false : stored === "true";
      } catch {
        return false;
      }
    });
    useEffect(() => {
      try {
        localStorage.setItem(SHOW_UPLOADS_STORAGE_KEY, String(showUploads));
      } catch {
        // ignore
      }
    }, [showUploads]);
    const [allItems, setAllItems] = useState<GalleryItem[]>([]);
    const [pageIndex, setPageIndex] = useState(0);
    const [hasMore, setHasMore] = useState(true);

    // Track whether this is the very first load (no cache, no items yet)
    const [initialLoading, setInitialLoading] = useState(false);

    // Error message from failed listUserMediaFiles call (null = no error)
    const [itemsLoadError, setItemsLoadError] = useState<string | null>(null);

    // Bulk selection state (view mode only)
    const [bulkSelectedIds, setBulkSelectedIds] = useState<Set<string>>(
      new Set(),
    );
    const bulkSelectionMode = bulkSelectedIds.size > 0;

    // Folders state. Folders nest via `parentId` (null = root) so the gallery
    // supports folders-inside-folders (Google-Drive style).
    const [folders, setFolders] = useState<GalleryFolder[]>([]);
    // Top-level view tab (view mode only): the flat library vs the folder browser.
    const [galleryTab, setGalleryTab] = useState<"unsorted" | "folders">(
      "unsorted",
    );
    const galleryTabRef = useRef(galleryTab);
    galleryTabRef.current = galleryTab;
    const [newFolderModalOpen, setNewFolderModalOpen] = useState(false);
    // Parent the next-created folder will be nested under (null = root).
    const [newFolderParentId, setNewFolderParentId] = useState<string | null>(
      null,
    );
    // Items to drop into the folder once it's created (set when the new-folder
    // modal is opened from the bulk "Add to folder" flow; empty otherwise).
    const [newFolderItemIds, setNewFolderItemIds] = useState<string[]>([]);

    // Active folder view. Resolved media items are cached per folder so
    // reopening a folder shows instantly while a fresh fetch runs in the background.
    const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
    const [folderMediaItems, setFolderMediaItems] = useState<
      Record<string, GalleryItem[]>
    >({});
    const [folderContentLoading, setFolderContentLoading] = useState(false);
    // Bottom spinner while paginating the open folder's media.
    const [folderLoadingMore, setFolderLoadingMore] = useState(false);
    // Per-folder cursor / has-more / in-flight guard for infinite scroll.
    const folderCursorRef = useRef<Record<string, string | undefined>>({});
    const folderHasMoreRef = useRef<Record<string, boolean>>({});
    const folderLoadingRef = useRef<Record<string, boolean>>({});

    // Tags state — sidebar tag browsing (mirrors the folder plumbing). Both
    // tag views live on the assets tab: `activeTagToken` swaps the grid to
    // that tag's media, `tagBrowserOpen` shows the all-tags word cloud.
    const [userTags, setUserTags] = useState<TagDetails[]>([]);
    const [tagBrowserOpen, setTagBrowserOpen] = useState(false);
    const [activeTagToken, setActiveTagToken] = useState<string | null>(null);
    const [tagMediaItems, setTagMediaItems] = useState<
      Record<string, GalleryItem[]>
    >({});
    const [tagContentLoading, setTagContentLoading] = useState(false);
    const [tagLoadingMore, setTagLoadingMore] = useState(false);
    const tagCursorRef = useRef<Record<string, string | undefined>>({});
    const tagHasMoreRef = useRef<Record<string, boolean>>({});
    const tagLoadingRef = useRef<Record<string, boolean>>({});
    // Rename state — shared by inline (header) and modal (sidebar) flows
    const [renamingFolderId, setRenamingFolderId] = useState<string | null>(
      null,
    );
    const [renameValue, setRenameValue] = useState("");
    const renameInputRef = useRef<HTMLInputElement>(null);
    // Whether rename was triggered from sidebar (show modal) vs header (inline)
    const [renameViaModal, setRenameViaModal] = useState(false);
    const [folderMenuOpen, setFolderMenuOpen] = useState(false);
    // Context menu for sidebar folder right-click
    const [contextMenu, setContextMenu] = useState<{
      folderId: string;
      x: number;
      y: number;
    } | null>(null);

    const activeFolder = activeFolderId
      ? (folders.find((f) => f.id === activeFolderId) ?? null)
      : null;

    // Subfolders of the current location (root when no folder is open).
    const currentSubfolders = useMemo(
      () =>
        folders
          .filter((f) => (f.parentId ?? null) === activeFolderId)
          .sort(compareFolders),
      [folders, activeFolderId],
    );

    // Root-level folders for the filter sidebar — always roots, regardless of
    // which folder is open in the browser tab (mirrors the webapp sidebar).
    const rootFolders = useMemo(
      () => folders.filter((f) => !f.parentId).sort(compareFolders),
      [folders],
    );

    // Root ancestor of the open folder — drives the sidebar highlight (the
    // sidebar lists only root folders), guarded against parent-chain cycles.
    const activeRootFolderId = useMemo(() => {
      if (galleryTab !== "folders" || !activeFolderId) return null;
      const byId = new Map(folders.map((f) => [f.id, f]));
      const seen = new Set<string>();
      let cursor = byId.get(activeFolderId);
      while (cursor && cursor.parentId && !seen.has(cursor.id)) {
        seen.add(cursor.id);
        cursor = byId.get(cursor.parentId);
      }
      return cursor?.id ?? null;
    }, [galleryTab, folders, activeFolderId]);

    // Breadcrumb trail from root → active folder (inclusive), guarded against
    // cycles so a corrupted parent chain can never loop forever.
    const folderPath = useMemo(() => {
      const path: { id: string; name: string }[] = [];
      if (!activeFolderId) return path;
      const byId = new Map(folders.map((f) => [f.id, f]));
      const seen = new Set<string>();
      let cursor = byId.get(activeFolderId);
      while (cursor && !seen.has(cursor.id)) {
        seen.add(cursor.id);
        path.unshift({ id: cursor.id, name: cursor.name });
        cursor = cursor.parentId ? byId.get(cursor.parentId) : undefined;
      }
      return path;
    }, [folders, activeFolderId]);

    // Direct subfolder count, shown as the chip subtitle. (The lean folder-media
    // list doesn't carry a total media count, so we only surface subfolders.)
    const folderChildCount = useCallback(
      (folderId: string) =>
        folders.filter((f) => f.parentId === folderId).length,
      [folders],
    );

    // Clear bulk selection when filter changes
    useEffect(() => {
      setBulkSelectedIds(new Set());
    }, [activeFilter]);

    // Use refs for values that loadItems needs but shouldn't trigger re-creation
    const pageIndexRef = useRef(pageIndex);
    pageIndexRef.current = pageIndex;
    const activeFilterRef = useRef(activeFilter);
    activeFilterRef.current = activeFilter;
    const usernameRef = useRef(username);
    usernameRef.current = username;

    const imageUrl = lightboxImageSignal.value?.fullImage || "";
    const imageUrls: string[] | undefined = (lightboxImageSignal.value as any)
      ?.imageUrls;
    const actionUrls: string[] | undefined = (lightboxImageSignal.value as any)
      ?.actionUrls;

    const api = useMemo(() => new GalleryModalApi(), []);
    const mediaFilesApi = useMemo(() => new MediaFilesApi(), []);
    const foldersApi = useMemo(() => new FoldersApi(), []);
    const tagsApi = useMemo(() => new TagsApi(), []);

    // Shared API-folder → UI-folder mapper (see folderMapping.ts).
    const mapFolder = mapFolderInfo;

    const groupItemsByDate = useCallback((items: GalleryItem[]) => {
      const grouped = items.reduce((acc: GroupedItems, item) => {
        const dateKey = formatDate(item.createdAt);
        if (!acc[dateKey]) {
          acc[dateKey] = [];
        }
        acc[dateKey].push(item);
        return acc;
      }, {});

      // Sort dates in descending order
      return Object.fromEntries(
        Object.entries(grouped).sort(
          (a, b) =>
            new Date(b[1][0].createdAt).getTime() -
            new Date(a[1][0].createdAt).getTime(),
        ),
      );
    }, []);

    // Memoize the grouped result so we don't recompute on every render
    const groupedItems = useMemo(
      () => groupItemsByDate(allItems),
      [allItems, groupItemsByDate],
    );

    // Folder view memos — backed by the per-folder media cache.
    const activeFolderItems = useMemo(
      () => (activeFolderId ? (folderMediaItems[activeFolderId] ?? []) : []),
      [activeFolderId, folderMediaItems],
    );

    const folderGroupedItems = useMemo(
      () => groupItemsByDate(activeFolderItems),
      [activeFolderItems, groupItemsByDate],
    );

    // Tag view memos — backed by the per-tag media cache.
    const activeTagItems = useMemo(
      () => (activeTagToken ? (tagMediaItems[activeTagToken] ?? []) : []),
      [activeTagToken, tagMediaItems],
    );
    const tagGroupedItems = useMemo(
      () => groupItemsByDate(activeTagItems),
      [activeTagItems, groupItemsByDate],
    );
    const activeTag = activeTagToken
      ? (userTags.find((t) => t.tag_token === activeTagToken) ?? null)
      : null;
    // Most-used-first ordering for the sidebar tag list.
    const sortedTags = useMemo(
      () =>
        [...userTags].sort(
          (a, b) =>
            b.use_count - a.use_count ||
            a.tag_value_lowercase.localeCompare(b.tag_value_lowercase),
        ),
      [userTags],
    );
    const sidebarTags = sortedTags.slice(0, SIDEBAR_TAG_LIMIT);

    // Audio tiles have no thumbnail, so they show their prompt text instead.
    // Resolve it via the shared batched caches (media token → prompt token →
    // prompt text) for audio items only; image/video walls skip the lookups.
    const audioMediaTokensNeedingPrompt = useMemo(() => {
      const tokens: string[] = [];
      const collect = (item: GalleryItem) => {
        if (item.mediaClass === "audio" && !item.promptToken) {
          tokens.push(item.id);
        }
      };
      allItems.forEach(collect);
      activeFolderItems.forEach(collect);
      return tokens;
    }, [allItems, activeFolderItems]);
    const resolvedAudioPromptTokens = useMediaPromptTokens(
      audioMediaTokensNeedingPrompt,
    );

    const audioPromptTokens = useMemo(() => {
      const tokens: string[] = [];
      const collect = (item: GalleryItem) => {
        if (item.mediaClass !== "audio") return;
        const token =
          item.promptToken || resolvedAudioPromptTokens.get(item.id);
        if (token) tokens.push(token);
      };
      allItems.forEach(collect);
      activeFolderItems.forEach(collect);
      return tokens;
    }, [allItems, activeFolderItems, resolvedAudioPromptTokens]);
    const audioPromptsMap = usePrompts(audioPromptTokens);

    const audioPromptTextFor = useCallback(
      (item: GalleryItem): string | undefined => {
        if (item.mediaClass !== "audio") return undefined;
        const token =
          item.promptToken || resolvedAudioPromptTokens.get(item.id);
        return (
          (token
            ? audioPromptsMap.get(token)?.maybe_positive_prompt
            : undefined) || undefined
        );
      },
      [resolvedAudioPromptTokens, audioPromptsMap],
    );

    const handleImageError = useCallback((url: string) => {
      console.error(`Failed to load gallery modal image: ${url}`);
      failedImageUrls.current.add(url);
    }, []);

    // Ref to the latest refreshGallery so the async session-fetch effect can
    // call it without taking a dependency on it. refreshGallery itself is
    // defined lower in the file (it needs loadItems); we wire the ref via a
    // layout-time assignment below.
    const refreshGalleryRef = useRef<() => void>(() => {});

    // Fetch the current session's username every time the modal opens.
    // The modal is permanently mounted in TopBar, so this component survives
    // logout → login. We re-verify who the backend considers the current user
    // on every open and, if it's a different user, wipe all stale state before
    // letting refreshGallery fire. This effect is the SOLE driver for refresh
    // on modal-open — the separate filter/username effect below intentionally
    // does NOT depend on modal-open signals, so it can't race this one.
    useEffect(() => {
      const modalIsOpen =
        isOpen || (mode === "view" && galleryModalVisibleViewMode.value);
      if (!modalIsOpen) return;
      // Clear any stale drag-under state from a previous session. A canvas-drop
      // close (reopen-off) intentionally leaves this true so the panel stays
      // faded through the close animation; if we didn't reset it on reopen, the
      // freshly-opened modal would render hidden (contentHidden) and the user
      // couldn't see it — making the library button appear broken.
      galleryModalDraggingUnder.value = false;
      let cancelled = false;
      (async () => {
        setUsernameError(false);
        const name = await fetchCurrentUsername();
        if (cancelled) return;
        if (!name) {
          setUsernameError(true);
          setInitialLoading(false);
          return;
        }
        if (name !== usernameRef.current) {
          // Different user than before — wipe everything from the previous
          // session. setUsername will trigger the filter/username effect
          // below, which calls refreshGallery with the new identity.
          galleryCacheMap.clear();
          setAllItems([]);
          setPageIndex(0);
          setHasMore(true);
          setInitialLoading(true);
          setUsername(name);
        } else {
          // Same user reopening — just refresh (shows cache + background refetch).
          refreshGalleryRef.current();
        }
      })();
      return () => {
        cancelled = true;
      };
    }, [mode, galleryModalVisibleViewMode.value, isOpen, usernameRetryCount]);

    // Helper to build the cache key for the current filter
    const getCacheKey = useCallback(
      () => `gallery_${activeFilterRef.current}`,
      [],
    );

    // Keyset cursors for the mesh/splat tabs (their endpoints paginate by
    // cursor rather than page index), keyed by filter id.
    const byClassCursorRef = useRef<Record<string, string | undefined>>({});

    // Map raw API item to GalleryItem
    const mapApiItem = useCallback(
      (item: any): GalleryItem => ({
        id: item.token,
        label: getLabel(item),
        thumbnail:
          item.media_class === "audio"
            ? null
            : item.media_class === "video"
            ? item.media_links.maybe_video_previews?.animated
            : is3DClass(item.media_class)
              ? // Prefer the modern CDN link; fall back to the deprecated
                // bucket URL for older responses.
                (item.cover_image?.maybe_links?.cdn_url ??
                item.cover_image?.maybe_cover_image_public_bucket_url)
              : getThumbnailUrl(item.media_links.maybe_thumbnail_template, {
                  width: THUMBNAIL_SIZES.MEDIUM,
                }),
        thumbnailUrlTemplate: item.media_links.maybe_thumbnail_template,
        fullImage: item.media_links.cdn_url,
        createdAt: item.created_at,
        mediaClass:
          item.media_class ||
          (item.filter_media_classes ? item.filter_media_classes[0] : "image"),
        isUpload: item.origin_category === "upload",
        assetType:
          item.media_class === "dimensional" || item.media_class === "mesh"
            ? item.maybe_animation_type ||
              item.origin_product_category === "character" ||
              (item.origin && item.origin.product_category === "character")
              ? "character"
              : "object"
            : item.media_class === "splat"
              ? "splat"
              : undefined,
        promptToken: item.maybe_prompt_token ?? undefined,
        durationMillis: item.maybe_duration_millis ?? undefined,
      }),
      [],
    );

    // Map a folder/tag media-file list item → GalleryItem (same lean wire
    // shape). The list item already carries media_links/cover, so no batch-get
    // is needed (unlike `mapApiItem`, which reads the raw user-media list
    // shape: origin_category / no batch token).
    const mapFolderListItem = useCallback(
      (item: FolderMediaFileListItem | TagMediaFileListItem): GalleryItem => ({
        id: item.token,
        label: getLabel(item),
        thumbnail:
          item.media_class === "audio"
            ? null
            : is3DClass(item.media_class)
              ? (item.cover_image?.maybe_links?.cdn_url ??
                item.cover_image?.maybe_cover_image_public_bucket_url ??
                null)
              : getMediaThumbnail(item.media_links, item.media_class, {
                  size: THUMBNAIL_SIZES.MEDIUM,
                }),
        thumbnailUrlTemplate:
          item.media_links?.maybe_thumbnail_template ?? undefined,
        fullImage: item.media_links?.cdn_url ?? null,
        createdAt: item.created_at,
        mediaClass: item.media_class || "image",
        isUpload: !!item.is_user_upload,
        batchImageToken: item.maybe_batch_token ?? undefined,
        promptToken: item.maybe_prompt_token ?? undefined,
        durationMillis: item.maybe_duration_millis ?? undefined,
      }),
      [],
    );

    // Stable loadItems that reads from refs — never causes cascading re-renders
    const loadItems = useCallback(
      async (reset = false) => {
        const currentUsername = usernameRef.current;
        const currentFilter = activeFilterRef.current;
        if (!currentUsername) return;
        // Ref-based lock prevents concurrent/re-entrant calls
        if (isLoadingRef.current) return;
        isLoadingRef.current = true;
        setLoading(true);
        if (!reset) setPaginationLoading(true);
        try {
          if (currentFilter === "mesh" || currentFilter === "splat") {
            // The Mesh / Splat tabs use the session by-class list endpoints
            // (server-scoped, cursor-paginated) instead of the user list.
            const cursor = reset
              ? undefined
              : byClassCursorRef.current[currentFilter];
            const response =
              currentFilter === "splat"
                ? await mediaFilesApi.ListSessionSplatMediaFiles({
                    cursor,
                    page_size: PAGE_SIZE,
                  })
                : await mediaFilesApi.ListSessionMeshMediaFiles({
                    cursor,
                    page_size: PAGE_SIZE,
                  });

            if (response.success && response.data) {
              setItemsLoadError(null);
              const newItems = response.data.map(mapApiItem);

              if (reset) {
                setAllItems(newItems);
              } else {
                setAllItems((prev) => [...prev, ...newItems]);
              }

              const nextCursor = response.pagination?.maybe_next ?? undefined;
              byClassCursorRef.current[currentFilter] = nextCursor;
              const more = newItems.length >= PAGE_SIZE && !!nextCursor;
              setPageIndex(0);
              setHasMore(more);

              const cacheKey = getCacheKey();
              setAllItems((latest) => {
                galleryCacheMap.set(cacheKey, {
                  items: latest,
                  pageIndex: 0,
                  hasMore: more,
                  timestamp: Date.now(),
                  cursor: nextCursor,
                });
                return latest;
              });
            } else {
              setItemsLoadError(
                response.errorMessage || "Request failed (unknown error)",
              );
            }

            setLoading(false);
            setPaginationLoading(false);
            setInitialLoading(false);
            isLoadingRef.current = false;
            return;
          }

          const filterMediaClasses = getFilterMediaClass(currentFilter);
          const query = {
            filter_media_classes: filterMediaClasses,
            username: currentUsername,
            include_user_uploads:
              currentFilter === "uploaded" ||
              currentFilter === "all" ||
              currentFilter === "image" ||
              currentFilter === "video" ||
              currentFilter === "audio",
            user_uploads_only: currentFilter === "uploaded",
            page_index: reset ? 0 : pageIndexRef.current,
            page_size: PAGE_SIZE,
          };
          const response = await api.listUserMediaFiles(query);

          if (response.success && response.data) {
            setItemsLoadError(null);
            const newItems = response.data
              .filter(
                (item: any) =>
                  item.media_type !== FilterMediaType.SCENE_JSON &&
                  // Drop 3D-model cover screenshots the backend surfaces as
                  // 3D-classed items (mesh/splat, or legacy pre-split
                  // "dimensional") whose asset is actually a .png.
                  !(
                    (item.media_class === "dimensional" ||
                      item.media_class === "mesh" ||
                      item.media_class === "splat") &&
                    !is3DModelUrl(item.media_links?.cdn_url)
                  ),
              )
              .map(mapApiItem);

            if (reset) {
              // Smart merge: refresh existing items in place, prepend brand
              // new ones, and keep any items older than the fresh page
              // window (those live on later pages and aren't in this fetch).
              // NB: we can't blindly drop items missing from `newItems` —
              // that would evict everything loaded by infinite scroll.
              // Deletions are handled live via `media_file_deleted_event`.
              setAllItems((prev) => {
                if (prev.length === 0) return newItems;
                if (newItems.length === 0) return prev;
                const existingIds = new Set(prev.map((it) => it.id));
                const brandNew = newItems.filter(
                  (it: GalleryItem) => !existingIds.has(it.id),
                );
                const freshMap = new Map(
                  newItems.map((it: GalleryItem) => [it.id, it] as const),
                );
                // The server returns newest-first, so anything older than
                // the oldest item in this fresh page is on a later page.
                const oldestFreshTs = Math.min(
                  ...newItems.map((it: GalleryItem) =>
                    new Date(it.createdAt).getTime(),
                  ),
                );
                const updated = prev
                  .map((it) => {
                    const fresh = freshMap.get(it.id);
                    if (fresh) return fresh;
                    // Not in fresh window but older — came from a later
                    // page via infinite scroll; keep it.
                    if (new Date(it.createdAt).getTime() < oldestFreshTs) {
                      return it;
                    }
                    // In the fresh window and missing → server dropped it.
                    return undefined;
                  })
                  .filter((it): it is GalleryItem => it !== undefined);
                return [...brandNew, ...updated];
              });
            } else {
              setAllItems((prev) => [...prev, ...newItems]);
            }

            // Pagination logic
            const current = response.pagination?.current ?? 0;
            const total = response.pagination?.total_page_count ?? 1;
            setPageIndex(current + 1);
            setHasMore(current + 1 < total);

            // Update cache
            const cacheKey = getCacheKey();
            setAllItems((latest) => {
              galleryCacheMap.set(cacheKey, {
                items: latest,
                pageIndex: current + 1,
                hasMore: current + 1 < total,
                timestamp: Date.now(),
              });
              return latest;
            });
          } else {
            setItemsLoadError(
              response.errorMessage || "Request failed (unknown error)",
            );
          }
        } catch (error) {
          const msg = error instanceof Error ? error.message : String(error);
          console.error("Failed to fetch library items:", msg);
          setItemsLoadError(msg);
        }
        setLoading(false);
        setPaginationLoading(false);
        setInitialLoading(false);
        isLoadingRef.current = false;
      },
      [api, mediaFilesApi, mapApiItem, getCacheKey],
    );

    // refresh logic — shows cached items immediately, then background-refreshes
    // eslint-disable-next-line react-hooks/exhaustive-deps
    const refreshGallery = useCallback(() => {
      setItemsLoadError(null);
      const cacheKey = `gallery_${activeFilterRef.current}`;
      const cached = galleryCacheMap.get(cacheKey);

      if (cached && cached.items.length > 0) {
        // Instantly show cached items — no loading indicator
        setAllItems(cached.items);
        setPageIndex(cached.pageIndex);
        setHasMore(cached.hasMore);
        byClassCursorRef.current[activeFilterRef.current] = cached.cursor;
        setInitialLoading(false);
        // Background refresh — silently fetch page 0 and merge new items
        loadItems(true);
      } else {
        // No cache — show skeleton, then load
        setAllItems([]);
        setPageIndex(0);
        setHasMore(true);
        setInitialLoading(true);
        loadItems(true);
      }
    }, [loadItems]);

    // Keep the ref pointed at the latest refreshGallery so the session-fetch
    // effect can call it without taking it as a dep (avoids tearing).
    refreshGalleryRef.current = refreshGallery;

    // Refresh on username change (new user logged in via the session-fetch
    // effect) or on activeFilter change. This effect deliberately does NOT
    // depend on modal-open signals — the session-fetch effect above is the
    // sole driver for modal-open refreshes, which prevents a race where this
    // effect would otherwise fire synchronously with a stale `username` and
    // take the loading lock before the new session resolves.
    useEffect(() => {
      const modalIsOpen =
        mode === "view"
          ? galleryModalVisibleViewMode.value
          : typeof isOpen === "boolean"
            ? isOpen
            : true;
      if (modalIsOpen && username) {
        refreshGallery();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [username, activeFilter]);

    // Auto-refresh when a generation completes while the gallery is open
    const modalIsOpenRef = useRef(false);
    useEffect(() => {
      modalIsOpenRef.current =
        mode === "view"
          ? !!galleryModalVisibleViewMode.value
          : typeof isOpen === "boolean"
            ? isOpen
            : true;
    }, [mode, isOpen, galleryModalVisibleViewMode.value]);

    // External media-event subscription. Caller (typically the desktop app's
    // Tauri bindings) wires `subscribeToMediaEvents` to fire `onGenerationComplete`
    // when a generation finishes and `onMediaDeleted(id)` when any client deletes
    // an item, so the gallery refreshes and drops items live. When the prop is
    // absent (e.g. on the web), these behaviors just don't run.
    useEffect(() => {
      if (!subscribeToMediaEvents) return;
      const unsubscribe = subscribeToMediaEvents({
        onGenerationComplete: () => {
          if (modalIsOpenRef.current && username) {
            refreshGallery();
          }
        },
        onMediaDeleted: (token) => {
          if (!token) return;
          setAllItems((prev) => prev.filter((it) => it.id !== token));
          setBulkSelectedIds((prev) => {
            if (!prev.has(token)) return prev;
            const next = new Set(prev);
            next.delete(token);
            return next;
          });
          for (const [key, entry] of galleryCacheMap.entries()) {
            galleryCacheMap.set(key, {
              ...entry,
              items: entry.items.filter((it) => it.id !== token),
            });
          }
        },
      });
      return unsubscribe;
    }, [subscribeToMediaEvents, refreshGallery, username]);

    const toggleBulkSelect = useCallback((id: string) => {
      setBulkSelectedIds((prev) => {
        const next = new Set(prev);
        if (next.has(id)) {
          next.delete(id);
        } else {
          next.add(id);
        }
        return next;
      });
    }, []);

    // ── Marquee (drag) selection ──────────────────────────────────────────
    // Dragging from blank background draws a selection rectangle; tiles it
    // covers are added to the bulk selection (additive to whatever was
    // selected on start). Ported from the webapp library page, scoped to the
    // modal's scroll container. Perf-sensitive: the rectangle is positioned
    // imperatively, tile rects are cached at drag start, and selection commits
    // only when the covered set actually changes.
    const handleMarqueePointerDown = useCallback(
      (e: React.PointerEvent<HTMLDivElement>) => {
        if (e.button !== 0 || lightboxVisibleSignal.value) return;
        // A per-tile drag (to a folder / the canvas) is already underway —
        // never start a marquee on top of it.
        if (galleryDnd.getDragState().isDragging) return;

        const target = e.target as HTMLElement;
        // Start only on blank background — never from tiles, folder cards,
        // controls, or opted-out chrome.
        if (
          target.closest(
            "[data-media-id], [data-folder-id], button, a, input, [data-no-marquee]",
          )
        ) {
          return;
        }
        const scroller = scrollContainerRef.current;
        if (!scroller) return;

        // Blank-background press: suppress the browser's native text-selection
        // default so it can't hijack the marquee drag.
        e.preventDefault();

        const startX = e.clientX;
        const startY = e.clientY;
        // No marquee on touch — a finger drag should scroll. A still tap on
        // blank space still clears the selection below.
        const isTouch = e.pointerType !== "mouse";
        const base = new Set(bulkSelectedIds);
        let applied = base;
        let active = false;

        const readScrollTop = () => scroller.scrollTop;
        const readScrollLeft = () => scroller.scrollLeft;
        const startScrollTop = readScrollTop();
        const startScrollLeft = readScrollLeft();
        let lastCx = startX;
        let lastCy = startY;
        let edgeRaf = 0;

        let tiles: {
          id: string;
          left: number;
          top: number;
          right: number;
          bottom: number;
        }[] = [];
        const cacheTiles = () => {
          tiles = [];
          scroller
            .querySelectorAll<HTMLElement>("[data-media-id]")
            .forEach((el) => {
              const id = el.dataset.mediaId;
              if (!id) return;
              const r = el.getBoundingClientRect();
              tiles.push({
                id,
                left: r.left,
                top: r.top,
                right: r.right,
                bottom: r.bottom,
              });
            });
        };
        if (!isTouch) cacheTiles();

        const applyMarquee = (cx: number, cy: number) => {
          // Compensate the anchor for scrolling since drag start so the
          // rectangle keeps growing in content space, not viewport space.
          const ax = startX - (readScrollLeft() - startScrollLeft);
          const ay = startY - (readScrollTop() - startScrollTop);
          const left = Math.min(ax, cx);
          const top = Math.min(ay, cy);
          const width = Math.abs(cx - ax);
          const height = Math.abs(cy - ay);
          const right = left + width;
          const bottom = top + height;
          const box = marqueeRef.current;
          if (box) {
            // Clamp the *visible* rectangle to the scroll viewport so it never
            // paints over the modal header / sidebar. Selection math below
            // uses the unclamped rect, so tiles scrolled out of view stay
            // selected.
            const vr = scroller.getBoundingClientRect();
            const dispLeft = Math.max(left, vr.left);
            const dispRight = Math.min(right, vr.right);
            const dispTop = Math.max(top, vr.top);
            const dispBottom = Math.min(bottom, vr.bottom);
            box.style.display = "block";
            box.style.left = `${dispLeft}px`;
            box.style.top = `${dispTop}px`;
            box.style.width = `${Math.max(0, dispRight - dispLeft)}px`;
            box.style.height = `${Math.max(0, dispBottom - dispTop)}px`;
          }
          const mounted = new Set(tiles.map((t) => t.id));
          const next = new Set(base);
          // Tiles swept over earlier may have unmounted (virtualized list)
          // once scrolled far away — keep them selected.
          for (const id of applied) {
            if (!base.has(id) && !mounted.has(id)) next.add(id);
          }
          for (const t of tiles) {
            if (
              t.left < right &&
              t.right > left &&
              t.top < bottom &&
              t.bottom > top
            ) {
              next.add(t.id);
            }
          }
          // Commit only when coverage changed — most frames it hasn't.
          let changed = next.size !== applied.size;
          if (!changed) {
            for (const id of next) {
              if (!applied.has(id)) {
                changed = true;
                break;
              }
            }
          }
          if (changed) {
            applied = next;
            setBulkSelectedIds(next);
          }
        };

        // Auto-scroll while the cursor sits within EDGE px of the scroller's
        // top or bottom; speed ramps up nearer the edge. Self-perpetuating
        // via rAF until the cursor leaves the zone or the drag ends.
        const EDGE = 64;
        const MAX_SPEED = 24;
        const autoScrollTick = () => {
          edgeRaf = 0;
          if (!active || isTouch) return;
          const r = scroller.getBoundingClientRect();
          let dy = 0;
          if (lastCy < r.top + EDGE) {
            dy = -Math.min(MAX_SPEED, Math.ceil((r.top + EDGE - lastCy) / 3));
          } else if (lastCy > r.bottom - EDGE) {
            dy = Math.min(MAX_SPEED, Math.ceil((lastCy - (r.bottom - EDGE)) / 3));
          }
          if (dy === 0) return;
          scroller.scrollTop += dy;
          cacheTiles();
          applyMarquee(lastCx, lastCy);
          edgeRaf = requestAnimationFrame(autoScrollTick);
        };
        const ensureAutoScroll = () => {
          if (!edgeRaf) edgeRaf = requestAnimationFrame(autoScrollTick);
        };

        const handleMove = (ev: PointerEvent) => {
          if (isTouch) return;
          if (!active) {
            // Small threshold so plain background clicks don't flash a marquee.
            if (
              Math.abs(ev.clientX - startX) < 5 &&
              Math.abs(ev.clientY - startY) < 5
            ) {
              return;
            }
            active = true;
            document.body.style.userSelect = "none";
          }
          lastCx = ev.clientX;
          lastCy = ev.clientY;
          ensureAutoScroll();
          cancelAnimationFrame(marqueeRaf.current);
          marqueeRaf.current = requestAnimationFrame(() =>
            applyMarquee(ev.clientX, ev.clientY),
          );
        };
        const handleScroll = () => {
          if (active && !isTouch) {
            cacheTiles();
            applyMarquee(lastCx, lastCy);
          }
        };
        const handleUp = () => {
          window.removeEventListener("pointermove", handleMove);
          window.removeEventListener("pointerup", handleUp);
          window.removeEventListener("scroll", handleScroll, true);
          cancelAnimationFrame(marqueeRaf.current);
          cancelAnimationFrame(edgeRaf);
          document.body.style.userSelect = "";
          if (marqueeRef.current) marqueeRef.current.style.display = "none";
          // Plain click on blank background (no marquee drawn) clears the
          // selection, like clicking the desktop on an OS.
          if (!active) {
            setBulkSelectedIds(new Set());
          }
        };
        window.addEventListener("pointermove", handleMove);
        window.addEventListener("pointerup", handleUp);
        window.addEventListener("scroll", handleScroll, true);
      },
      [bulkSelectedIds, lightboxVisibleSignal],
    );

    const handleItemClick = useCallback(
      (item: GalleryItem) => {
        if (mode === "select" && onSelectItem) {
          onSelectItem(item.id);
        } else if (bulkSelectionMode) {
          toggleBulkSelect(item.id);
        } else {
          lightboxImageSignal.value = item;
          lightboxVisibleSignal.value = true;
          galleryModalLightboxMediaId.value = item.id;
        }
      },
      [mode, onSelectItem, bulkSelectionMode, toggleBulkSelect],
    );

    const handleCloseLightbox = useCallback(() => {
      lightboxVisibleSignal.value = false;
      lightboxImageSignal.value = null;
      galleryModalLightboxMediaId.value = null;
      galleryModalLightboxNavPrev.value = null;
      galleryModalLightboxNavNext.value = null;
    }, []);

    const handleCloseGallery = useCallback(() => {
      galleryModalVisibleViewMode.value = false;
    }, []);

    const handleDeselectAll = useCallback(() => {
      selectedItemIds.forEach((id: any) => onSelectItem?.(id));
    }, [selectedItemIds, onSelectItem]);

    const handleUseSelected = useCallback(() => {
      // Selected items can live in the root library (groupedItems) or inside
      // the active folder (folderGroupedItems). Search both, deduping by id,
      // so picks made while browsing a folder still resolve to real items.
      const itemsById = new Map<string, GalleryItem>();
      for (const item of [
        ...Object.values(groupedItems).flat(),
        ...Object.values(folderGroupedItems).flat(),
      ]) {
        itemsById.set(item.id, item);
      }
      const selectedItems = selectedItemIds
        .map((id: string) => itemsById.get(id))
        .filter((item): item is GalleryItem => item !== undefined);
      onUseSelected?.(selectedItems);
    }, [groupedItems, folderGroupedItems, selectedItemIds, onUseSelected]);

    const handleItemDeleted = useCallback((id: string) => {
      // Drop from local state (functional setter — must stay pure).
      setAllItems((prev) => prev.filter((it) => it.id !== id));
      setBulkSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      // Drop from the module-level cache for every filter so reopening
      // the modal under any filter doesn't resurrect the item.
      for (const [key, entry] of galleryCacheMap.entries()) {
        galleryCacheMap.set(key, {
          ...entry,
          items: entry.items.filter((it) => it.id !== id),
        });
      }
    }, []);

    const clearBulkSelection = useCallback(() => {
      setBulkSelectedIds(new Set());
      setBulkFolderPopoverOpen(false);
    }, []);

    const bulkSelectedItems = useMemo(
      () => allItems.filter((item) => bulkSelectedIds.has(item.id)),
      [allItems, bulkSelectedIds],
    );

    const handleBulkDelete = useCallback(() => {
      if (!onDeleteMedia) return;
      const count = bulkSelectedIds.size;
      showActionReminder({
        reminderType: "default",
        title: `Delete ${count} item${count > 1 ? "s" : ""}?`,
        message: (
          <p className="text-sm text-white/70">
            This will permanently remove {count} item{count > 1 ? "s" : ""} from
            your library. This action cannot be undone.
          </p>
        ),
        primaryActionText: "Delete",
        secondaryActionText: "Cancel",
        primaryActionBtnClassName: "bg-red text-white hover:bg-red/90",
        onPrimaryAction: async () => {
          try {
            const ids = Array.from(bulkSelectedIds);
            await Promise.allSettled(ids.map((id) => onDeleteMedia(id)));
            const idSet = new Set(ids);
            setAllItems((prev) => prev.filter((it) => !idSet.has(it.id)));
            for (const [key, entry] of galleryCacheMap.entries()) {
              galleryCacheMap.set(key, {
                ...entry,
                items: entry.items.filter((it) => !idSet.has(it.id)),
              });
            }
            clearBulkSelection();
          } finally {
            isActionReminderOpen.value = false;
          }
        },
      });
    }, [bulkSelectedIds, clearBulkSelection, onDeleteMedia]);

    // Load the full folder tree (paginated, newest first).
    const loadFolders = useCallback(async () => {
      try {
        const all: FolderInfo[] = [];
        let cursor: string | undefined = undefined;
        // Safety cap so a misbehaving cursor can't loop forever.
        for (let page = 0; page < 50; page++) {
          const res = await foldersApi.ListAllFolders({ cursor });
          if (!res.success || !res.data) break;
          all.push(...res.data);
          const next = res.pagination?.maybe_cursor;
          if (!next) break;
          cursor = next;
        }
        setFolders(all.map(mapFolder));
      } catch (err) {
        console.error("Failed to load folders:", err);
      }
    }, [foldersApi, mapFolder]);

    // Resolve a folder's media one page at a time: list its (lean) members via
    // the cursor, then batch-fetch the full media files so we can reuse the
    // existing GalleryItem mapping. `reset` starts over from the first page.
    const loadFolderMedia = useCallback(
      async (folderId: string, reset = false) => {
        if (folderLoadingRef.current[folderId]) return;
        if (!reset && folderHasMoreRef.current[folderId] === false) return;
        folderLoadingRef.current[folderId] = true;
        if (reset) {
          folderCursorRef.current[folderId] = undefined;
          folderHasMoreRef.current[folderId] = true;
          setFolderContentLoading(true);
        } else {
          setFolderLoadingMore(true);
        }
        try {
          const listRes = await foldersApi.ListFolderMediaFiles({
            folderToken: folderId,
            query: {
              cursor: reset ? undefined : folderCursorRef.current[folderId],
              limit: FOLDER_PAGE_SIZE,
            },
          });
          if (!listRes.success || !listRes.data) return;
          const nextCursor = listRes.pagination?.maybe_cursor ?? undefined;
          folderCursorRef.current[folderId] = nextCursor;
          folderHasMoreRef.current[folderId] = !!nextCursor;
          // The list item already carries media_links/cover, so map directly —
          // no second batch-get. Server order is newest-added first.
          const ordered = listRes.data.map(mapFolderListItem);
          setFolderMediaItems((prev) => {
            const existing = reset ? [] : (prev[folderId] ?? []);
            const seen = new Set(existing.map((i) => i.id));
            const merged = [
              ...existing,
              ...ordered.filter((i) => !seen.has(i.id)),
            ];
            return { ...prev, [folderId]: merged };
          });
        } catch (err) {
          console.error("Failed to load folder media:", err);
        } finally {
          folderLoadingRef.current[folderId] = false;
          setFolderContentLoading(false);
          setFolderLoadingMore(false);
        }
      },
      [foldersApi],
    );

    // Load the user's tag list for the sidebar (same paging cap as folders).
    const loadTags = useCallback(async () => {
      try {
        const all: TagDetails[] = [];
        let cursor: string | undefined = undefined;
        for (let page = 0; page < 50; page++) {
          const res = await tagsApi.ListTags({ cursor });
          if (!res.success || !res.data) break;
          all.push(...res.data);
          const next = res.pagination?.maybe_cursor;
          if (!next) break;
          cursor = next;
        }
        setUserTags(all);
      } catch (err) {
        console.error("Failed to load tags:", err);
      }
    }, [tagsApi]);

    // Resolve a tag's media one page at a time — mirrors `loadFolderMedia`.
    const loadTagMedia = useCallback(
      async (tagToken: string, reset = false) => {
        if (tagLoadingRef.current[tagToken]) return;
        if (!reset && tagHasMoreRef.current[tagToken] === false) return;
        tagLoadingRef.current[tagToken] = true;
        if (reset) {
          tagCursorRef.current[tagToken] = undefined;
          tagHasMoreRef.current[tagToken] = true;
          setTagContentLoading(true);
        } else {
          setTagLoadingMore(true);
        }
        try {
          const listRes = await tagsApi.ListMediaFilesWithTag({
            tagToken,
            cursor: reset ? undefined : tagCursorRef.current[tagToken],
            limit: FOLDER_PAGE_SIZE,
          });
          if (!listRes.success || !listRes.data) return;
          const nextCursor = listRes.pagination?.maybe_cursor ?? undefined;
          tagCursorRef.current[tagToken] = nextCursor;
          tagHasMoreRef.current[tagToken] = !!nextCursor;
          const ordered = listRes.data.map(mapFolderListItem);
          setTagMediaItems((prev) => {
            const existing = reset ? [] : (prev[tagToken] ?? []);
            const seen = new Set(existing.map((i) => i.id));
            const merged = [
              ...existing,
              ...ordered.filter((i) => !seen.has(i.id)),
            ];
            return { ...prev, [tagToken]: merged };
          });
        } catch (err) {
          console.error("Failed to load tag media:", err);
        } finally {
          tagLoadingRef.current[tagToken] = false;
          setTagContentLoading(false);
          setTagLoadingMore(false);
        }
      },
      [tagsApi, mapFolderListItem],
    );

    // `handleAddToFolder` is defined further down; reach it through a ref so the
    // earlier `handleCreateFolder` can add the just-created folder's seed items.
    const addToFolderRef = useRef<
      ((itemIds: string[], folderId: string) => Promise<void>) | null
    >(null);

    // Folder creation — nests under `newFolderParentId` (null = root). When opened
    // from the bulk "Add to folder" flow, `newFolderItemIds` holds the selected
    // items, which are dropped into the new folder right after it's created.
    const handleCreateFolder = useCallback(
      async (rawName: string) => {
        const name = rawName.trim();
        if (!name) return;
        const parentId = newFolderParentId;
        const seedItemIds = newFolderItemIds;
        setNewFolderModalOpen(false);
        setNewFolderItemIds([]);
        try {
          const res = await foldersApi.CreateFolder({
            name,
            maybe_parent_folder_token: parentId,
          });
          if (res.success && res.data) {
            const created = mapFolder(res.data);
            setFolders((prev) => [...prev, created]);
            if (seedItemIds.length > 0) {
              await addToFolderRef.current?.(seedItemIds, created.id);
              setBulkSelectedIds(new Set());
            }
          } else {
            toast.error(res.errorMessage || "Failed to create folder.");
          }
        } catch (err) {
          toast.error(
            `Failed to create folder: ${err instanceof Error ? err.message : String(err)}`,
          );
        }
      },
      [newFolderParentId, newFolderItemIds, foldersApi, mapFolder],
    );

    // Open the new-folder modal. `parentId` undefined → create in the folder
    // currently being viewed; pass `null` to force a root folder.
    const handleOpenNewFolderModal = useCallback(
      (parentId?: string | null, seedItemIds?: string[]) => {
        setNewFolderParentId(
          parentId !== undefined ? parentId : activeFolderId,
        );
        setNewFolderItemIds(seedItemIds ?? []);
        setNewFolderModalOpen(true);
      },
      [activeFolderId],
    );

    // Navigate into a folder (null = back to the root library). Fetches the
    // folder's media; cached items (if any) stay visible until the fetch lands.
    const handleOpenFolder = useCallback(
      (folderId: string | null) => {
        setActiveFolderId(folderId);
        setActiveTagToken(null);
        setTagBrowserOpen(false);
        setRenamingFolderId(null);
        setBulkSelectedIds(new Set());
        setFolderMenuOpen(false);
        setContextMenu(null);
        if (folderId) loadFolderMedia(folderId, true);
      },
      [loadFolderMedia],
    );

    // Navigate back to main library
    const handleBackToLibrary = useCallback(() => {
      handleOpenFolder(null);
    }, [handleOpenFolder]);

    // Switch top-level tab; leaving the folder browser exits any open folder
    // (and any open tag view).
    const switchGalleryTab = useCallback((tab: "unsorted" | "folders") => {
      setGalleryTab(tab);
      setActiveFolderId(null);
      setActiveTagToken(null);
      setTagBrowserOpen(false);
      setBulkSelectedIds(new Set());
      setFolderMenuOpen(false);
      setContextMenu(null);
    }, []);

    // Open a folder from the filter sidebar: jump to the folder browser tab
    // with that folder active.
    const handleOpenFolderFromSidebar = useCallback(
      (folderId: string) => {
        setGalleryTab("folders");
        handleOpenFolder(folderId);
      },
      [handleOpenFolder],
    );

    // Open a tag view from the sidebar or the tag browser: the tag's media
    // takes over the grid on the assets tab until dismissed.
    const handleOpenTagFromSidebar = useCallback(
      (tagToken: string) => {
        setGalleryTab("unsorted");
        setActiveFolderId(null);
        setActiveTagToken(tagToken);
        setBulkSelectedIds(new Set());
        setFolderMenuOpen(false);
        setContextMenu(null);
        loadTagMedia(tagToken, true);
      },
      [loadTagMedia],
    );

    // Open the all-tags word cloud (the "Tags" browser view).
    const handleOpenTagBrowser = useCallback(() => {
      setGalleryTab("unsorted");
      setActiveFolderId(null);
      setActiveTagToken(null);
      setTagBrowserOpen(true);
      setBulkSelectedIds(new Set());
      setFolderMenuOpen(false);
      setContextMenu(null);
    }, []);

    const handleCloseTagView = useCallback(() => {
      setActiveTagToken(null);
      setTagBrowserOpen(false);
    }, []);

    // Close any open folder menus
    const closeFolderMenus = useCallback(() => {
      setFolderMenuOpen(false);
      setContextMenu(null);
    }, []);

    // Rename folder — modal=true for sidebar, false for header inline
    const handleStartRename = useCallback(
      (folderId: string, modal = false) => {
        const folder = folders.find((f) => f.id === folderId);
        if (!folder) return;
        setRenameValue(folder.name);
        setRenamingFolderId(folderId);
        setRenameViaModal(modal);
        closeFolderMenus();
        setTimeout(() => renameInputRef.current?.select(), 50);
      },
      [folders, closeFolderMenus],
    );

    const handleConfirmRename = useCallback(
      async (nameArg?: unknown) => {
        if (!renamingFolderId) return;
        // `nameArg` is a string from the rename dialog; the inline header rename's
        // onBlur passes a focus event, so fall back to `renameValue` for non-strings.
        const trimmed = (
          typeof nameArg === "string" ? nameArg : renameValue
        ).trim();
        if (!trimmed) return;
        const folderId = renamingFolderId;
        // Optimistic — the rename feels instant; reconcile on error.
        setFolders((prev) =>
          prev.map((f) => (f.id === folderId ? { ...f, name: trimmed } : f)),
        );
        setRenamingFolderId(null);
        setRenameViaModal(false);
        try {
          const res = await foldersApi.RenameFolder({
            folderToken: folderId,
            newName: trimmed,
          });
          if (!res.success) {
            toast.error(res.errorMessage || "Failed to rename folder.");
            loadFolders();
          }
        } catch (err) {
          toast.error(
            `Failed to rename folder: ${err instanceof Error ? err.message : String(err)}`,
          );
          loadFolders();
        }
      },
      [renameValue, renamingFolderId, foldersApi, loadFolders],
    );

    // Star / unstar a folder (optimistic + reconcile).
    const handleSetFolderStar = useCallback(
      async (folderId: string, hasStar: boolean) => {
        setFolders((prev) =>
          prev.map((f) => (f.id === folderId ? { ...f, hasStar } : f)),
        );
        closeFolderMenus();
        try {
          const res = await foldersApi.SetStar({
            folderToken: folderId,
            hasStar,
          });
          if (!res.success) {
            toast.error(res.errorMessage || "Failed to update folder.");
            loadFolders();
          }
        } catch (err) {
          toast.error(
            `Failed to update folder: ${err instanceof Error ? err.message : String(err)}`,
          );
          loadFolders();
        }
      },
      [foldersApi, loadFolders, closeFolderMenus],
    );

    // Set / clear a folder color (optimistic + reconcile).
    const handleSetFolderColor = useCallback(
      async (folderId: string, colorCode: string | null) => {
        setFolders((prev) =>
          prev.map((f) => (f.id === folderId ? { ...f, colorCode } : f)),
        );
        try {
          const res = await foldersApi.SetColorCode({
            folderToken: folderId,
            colorCode,
          });
          if (!res.success) {
            toast.error(res.errorMessage || "Failed to update folder color.");
            loadFolders();
          }
        } catch (err) {
          toast.error(
            `Failed to update folder color: ${err instanceof Error ? err.message : String(err)}`,
          );
          loadFolders();
        }
      },
      [foldersApi, loadFolders],
    );

    // Delete folder (works for any folder). The server soft-deletes only this
    // folder; its subfolders keep their parent pointer and become "orphaned"
    // (we surface them at the top level). Media files stay in the library.
    const handleDeleteFolder = useCallback(
      (folderId: string) => {
        const folder = folders.find((f) => f.id === folderId);
        if (!folder) return;
        closeFolderMenus();
        const hasSubfolders = folders.some((f) => f.parentId === folderId);
        showActionReminder({
          reminderType: "default",
          title: `Delete "${folder.name}"?`,
          message: (
            <p className="text-sm text-white/70">
              {hasSubfolders
                ? "This folder will be deleted and its subfolders moved to the top level. "
                : "This folder will be deleted. "}
              Items inside stay in your library.
            </p>
          ),
          primaryActionText: "Delete",
          secondaryActionText: "Cancel",
          primaryActionBtnClassName: "bg-red text-white hover:bg-red/90",
          onPrimaryAction: async () => {
            // Optimistic: drop this folder and reparent its direct children to
            // root (mirrors the server orphaning them), and forget its media cache.
            setFolders((prev) =>
              prev
                .filter((f) => f.id !== folderId)
                .map((f) =>
                  f.parentId === folderId ? { ...f, parentId: null } : f,
                ),
            );
            setFolderMediaItems((prev) => {
              const next = { ...prev };
              delete next[folderId];
              return next;
            });
            if (activeFolderId === folderId) {
              setActiveFolderId(folder.parentId ?? null);
            }
            isActionReminderOpen.value = false;
            try {
              const res = await foldersApi.DeleteFolder({
                folderToken: folderId,
              });
              if (!res.success) {
                toast.error(res.errorMessage || "Failed to delete folder.");
              }
            } catch (err) {
              toast.error(
                `Failed to delete folder: ${err instanceof Error ? err.message : String(err)}`,
              );
            }
            // Reconcile authoritative orphan flags / parent pointers.
            loadFolders();
          },
        });
      },
      [folders, activeFolderId, closeFolderMenus, foldersApi, loadFolders],
    );

    // Refs so the folder-drop listener stays stable while reading live state.
    const folderMediaItemsRef = useRef(folderMediaItems);
    folderMediaItemsRef.current = folderMediaItems;
    const activeFolderIdRef = useRef(activeFolderId);
    activeFolderIdRef.current = activeFolderId;

    // Resolve item ids → GalleryItems from anything we've loaded (root + any folder).
    const resolveItems = useCallback(
      (itemIds: string[]): GalleryItem[] => {
        const byId = new Map<string, GalleryItem>();
        for (const it of allItems) byId.set(it.id, it);
        for (const arr of Object.values(folderMediaItemsRef.current)) {
          for (const it of arr) if (!byId.has(it.id)) byId.set(it.id, it);
        }
        return itemIds
          .map((id) => byId.get(id))
          .filter((it): it is GalleryItem => !!it);
      },
      [allItems],
    );

    // Prepend added items' still-thumbnails to a folder's auto collage (optimistic).
    // Only `collageUrls` — `coverUrl` is the user's custom cover and must not be
    // derived from the collage (else the chip shows one image, not the 2×2 grid).
    const bumpFolderCollage = useCallback(
      (folderId: string, addItems: GalleryItem[]) =>
        setFolders((prev) =>
          prev.map((f) =>
            f.id === folderId
              ? {
                  ...f,
                  collageUrls: mergeCollageUrls(
                    f.collageUrls,
                    addItems.map(galleryItemToCollageUrl),
                  ),
                }
              : f,
          ),
        ),
      [],
    );

    // Add media files to a folder. Optimistic cache + cover, then persist.
    const handleAddToFolder = useCallback(
      async (itemIds: string[], folderId: string) => {
        if (itemIds.length === 0) return;
        const addedItems = resolveItems(itemIds);
        setFolderMediaItems((prev) => {
          const existing = prev[folderId];
          if (!existing) return prev; // fetched fresh when the folder opens
          const seen = new Set(existing.map((i) => i.id));
          const fresh = addedItems.filter((i) => !seen.has(i.id));
          if (fresh.length === 0) return prev;
          return { ...prev, [folderId]: [...fresh, ...existing] };
        });
        bumpFolderCollage(folderId, addedItems);
        try {
          const res = await foldersApi.AddMediaFiles({
            folderToken: folderId,
            mediaFileTokens: itemIds,
          });
          if (res.success) {
            const name =
              folders.find((f) => f.id === folderId)?.name ?? "folder";
            toast.success(
              `Added ${itemIds.length} item${itemIds.length === 1 ? "" : "s"} to ${name}`,
            );
          } else {
            toast.error(res.errorMessage || "Failed to add to folder.");
          }
        } catch (err) {
          toast.error(
            `Failed to add to folder: ${err instanceof Error ? err.message : String(err)}`,
          );
        }
      },
      [resolveItems, bumpFolderCollage, folders, foldersApi],
    );
    // Expose to `handleCreateFolder` (defined above) for the new-folder-with-items flow.
    addToFolderRef.current = handleAddToFolder;

    // Move media from one folder to another (atomic). Drops from source, adds to target.
    const handleMoveMedia = useCallback(
      async (itemIds: string[], source: string, target: string) => {
        if (itemIds.length === 0) return;
        const movedItems = resolveItems(itemIds);
        const idSet = new Set(itemIds);
        setFolderMediaItems((prev) => {
          const next = { ...prev };
          if (next[source])
            next[source] = next[source].filter((it) => !idSet.has(it.id));
          if (next[target]) {
            const seen = new Set(next[target].map((i) => i.id));
            next[target] = [
              ...movedItems.filter((i) => !seen.has(i.id)),
              ...next[target],
            ];
          }
          return next;
        });
        bumpFolderCollage(target, movedItems);
        // Drop the moved stills from the source folder's collage.
        const movedUrls = new Set(
          movedItems
            .map(galleryItemToCollageUrl)
            .filter((u): u is string => !!u),
        );
        setFolders((prev) =>
          prev.map((f) =>
            f.id === source
              ? {
                  ...f,
                  collageUrls: (f.collageUrls ?? []).filter(
                    (u) => !movedUrls.has(u),
                  ),
                }
              : f,
          ),
        );
        try {
          const res = await foldersApi.MoveMediaFiles({
            folderToken: target,
            sourceFolderToken: source,
            mediaFileTokens: itemIds,
          });
          if (res.success) {
            const name = folders.find((f) => f.id === target)?.name ?? "folder";
            toast.success(
              `Moved ${itemIds.length} item${itemIds.length === 1 ? "" : "s"} to ${name}`,
            );
          } else {
            toast.error(res.errorMessage || "Failed to move items.");
            loadFolders();
          }
        } catch (err) {
          toast.error(
            `Failed to move items: ${err instanceof Error ? err.message : String(err)}`,
          );
          loadFolders();
        }
      },
      [resolveItems, bumpFolderCollage, folders, foldersApi, loadFolders],
    );

    // Remove media from the folder currently being viewed.
    const handleRemoveFromFolder = useCallback(
      async (itemIds: string[]) => {
        const folderId = activeFolderIdRef.current;
        if (!folderId || itemIds.length === 0) return;
        const idSet = new Set(itemIds);
        const removedItems = resolveItems(itemIds);
        const removedUrls = new Set(
          removedItems
            .map(galleryItemToCollageUrl)
            .filter((u): u is string => !!u),
        );
        setFolderMediaItems((prev) =>
          prev[folderId]
            ? {
                ...prev,
                [folderId]: prev[folderId].filter((it) => !idSet.has(it.id)),
              }
            : prev,
        );
        setFolders((prev) =>
          prev.map((f) =>
            f.id === folderId
              ? {
                  ...f,
                  collageUrls: (f.collageUrls ?? []).filter(
                    (u) => !removedUrls.has(u),
                  ),
                }
              : f,
          ),
        );
        try {
          const res = await foldersApi.RemoveMediaFiles({
            folderToken: folderId,
            mediaFileTokens: itemIds,
          });
          if (!res.success) {
            toast.error(res.errorMessage || "Failed to remove from folder.");
            loadFolders();
          }
        } catch (err) {
          toast.error(
            `Failed to remove from folder: ${err instanceof Error ? err.message : String(err)}`,
          );
          loadFolders();
        }
      },
      [resolveItems, foldersApi, loadFolders],
    );

    // Single entry point for drops + add-to-folder: prompt Move/Add when the
    // source is another folder, otherwise add directly (root → always add).
    const requestFolderDrop = useCallback(
      (itemIds: string[], targetFolderId: string) => {
        if (itemIds.length === 0) return;
        const source = activeFolderIdRef.current;
        if (source && source !== targetFolderId) {
          promptFolderDrop({
            count: itemIds.length,
            targetFolderName: folders.find((f) => f.id === targetFolderId)
              ?.name,
            onMove: () => handleMoveMedia(itemIds, source, targetFolderId),
            onAdd: () => handleAddToFolder(itemIds, targetFolderId),
          });
        } else {
          handleAddToFolder(itemIds, targetFolderId);
        }
      },
      [folders, handleMoveMedia, handleAddToFolder],
    );

    // Bulk "Add to folder" popover
    const [bulkFolderPopoverOpen, setBulkFolderPopoverOpen] = useState(false);

    // Folder drop listener
    useEffect(() => {
      const handler = (e: Event) => {
        const { items, folderId } = (e as CustomEvent).detail;
        requestFolderDrop(
          items.map((i: GalleryItem) => i.id),
          folderId,
        );
      };
      window.addEventListener(FOLDER_DROP_EVENT, handler);
      return () => window.removeEventListener(FOLDER_DROP_EVENT, handler);
    }, [requestFolderDrop]);

    // Load the folder tree when the modal opens (both view and the select
    // picker show the Folders tab). Re-runs per user so a new session is fresh.
    useEffect(() => {
      const modalIsOpen =
        mode === "view"
          ? galleryModalVisibleViewMode.value
          : typeof isOpen === "boolean"
            ? isOpen
            : true;
      if (modalIsOpen && username) {
        loadFolders();
        loadTags();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [mode, isOpen, galleryModalVisibleViewMode.value, username]);

    // Provide bulk-selected items for drag
    const getBulkDragItems = useCallback(
      () => allItems.filter((item) => bulkSelectedIds.has(item.id)),
      [allItems, bulkSelectedIds],
    );

    useSignals();

    // Synchronize lightbox image when external media id signal is set.
    // Skip if the signal already carries carousel data (imageUrls / batchImageToken)
    // set by the caller (e.g. TextToImage batch, TaskQueue) — overwriting it with
    // the plain gallery item would strip those fields and break the carousel.
    useEffect(() => {
      if (galleryModalLightboxMediaId.value && allItems.length > 0) {
        const current = lightboxImageSignal.value as any;
        if (current?.imageUrls?.length > 0 || current?.batchImageToken) return;
        const target = allItems.find(
          (it) => it.id === galleryModalLightboxMediaId.value,
        );
        if (target) {
          lightboxImageSignal.value = target;
        }
      }
    }, [galleryModalLightboxMediaId.value, allItems]);

    // Build a flat, ordered list of all visible items (matching the grid render order) for lightbox navigation
    const filterItem = useCallback(
      (item: GalleryItem) => {
        if ((item as any).mediaType === "scene_json") return false;
        if (!showUploads && activeFilter !== "uploaded" && item.isUpload)
          return false;
        if (activeFilter === "mesh") return item.mediaClass === "mesh";
        if (activeFilter === "splat") return item.mediaClass === "splat";
        if (activeFilter === "image") return item.mediaClass === "image";
        if (activeFilter === "video") return item.mediaClass === "video";
        if (activeFilter === "audio") return item.mediaClass === "audio";
        if (activeFilter === "all") {
          return (item as any).mediaType !== "scene_json";
        }
        return true;
      },
      [activeFilter, showUploads],
    );

    const flatFilteredItems = useMemo(() => {
      const result: GalleryItem[] = [];
      for (const [, dateItems] of Object.entries(groupedItems)) {
        for (const item of dateItems) {
          if (filterItem(item)) result.push(item);
        }
      }
      return result;
    }, [groupedItems, filterItem]);

    const currentLightboxIndex = useMemo(() => {
      const currentId = lightboxImageSignal.value?.id;
      if (!currentId) return -1;
      return flatFilteredItems.findIndex((item) => item.id === currentId);
    }, [flatFilteredItems, lightboxImageSignal.value]);

    const handleNavigatePrev = useMemo(() => {
      if (currentLightboxIndex <= 0) return undefined;
      return () => {
        const prevItem = flatFilteredItems[currentLightboxIndex - 1];
        if (prevItem) {
          lightboxImageSignal.value = prevItem;
          lightboxVisibleSignal.value = true;
          galleryModalLightboxMediaId.value = prevItem.id;
        }
      };
    }, [currentLightboxIndex, flatFilteredItems]);

    const handleNavigateNext = useMemo(() => {
      if (
        currentLightboxIndex < 0 ||
        currentLightboxIndex >= flatFilteredItems.length - 1
      )
        return undefined;
      return () => {
        const nextItem = flatFilteredItems[currentLightboxIndex + 1];
        if (nextItem) {
          lightboxImageSignal.value = nextItem;
          lightboxVisibleSignal.value = true;
          galleryModalLightboxMediaId.value = nextItem.id;
        }
      };
    }, [currentLightboxIndex, flatFilteredItems]);

    const handleNavigateToMedia = useCallback(
      async (mediaToken: string) => {
        try {
          const response = await mediaFilesApi.GetMediaFileByToken({
            mediaFileToken: mediaToken,
          });
          if (response.success && response.data) {
            const file = response.data;
            const url = file.media_links?.cdn_url || null;
            const item: GalleryItem = {
              id: file.token || mediaToken,
              label: "",
              thumbnail:
                getThumbnailUrl(file.media_links?.thumbnail_template, {
                  width: THUMBNAIL_SIZES.MEDIUM,
                }) || url,
              thumbnailUrlTemplate:
                file.media_links?.thumbnail_template || undefined,
              fullImage: url,
              createdAt: file.created_at || new Date().toISOString(),
              mediaClass: file.media_class || "image",
            };
            lightboxImageSignal.value = item;
            galleryModalLightboxMediaId.value = item.id;
          }
        } catch (error) {
          console.error("Failed to navigate to reference media:", error);
        }
      },
      [mediaFilesApi],
    );

    // Compute gap class based on gridColumns
    const gapClass =
      gridColumns <= 4 ? "gap-1.5" : gridColumns <= 7 ? "gap-1" : "gap-0.5";

    const handleScroll = useCallback(
      (e: React.UIEvent<HTMLDivElement>) => {
        const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
        if (scrollHeight - scrollTop - clientHeight >= 100) return;
        if (activeTagToken) {
          // Infinite-scroll the open tag's media.
          if (
            tagHasMoreRef.current[activeTagToken] !== false &&
            !tagLoadingRef.current[activeTagToken]
          ) {
            loadTagMedia(activeTagToken, false);
          }
        } else if (activeFolderId) {
          // Infinite-scroll the open folder's media.
          if (
            folderHasMoreRef.current[activeFolderId] !== false &&
            !folderLoadingRef.current[activeFolderId]
          ) {
            loadFolderMedia(activeFolderId, false);
          }
        } else if (
          galleryTabRef.current !== "folders" &&
          hasMore &&
          !isLoadingRef.current
        ) {
          loadItems();
        }
      },
      [activeTagToken, activeFolderId, hasMore, loadItems, loadFolderMedia, loadTagMedia],
    );

    // Folder tiles for the current location, rendered on the same grid as media
    // items. View mode only — the picker (select mode) never shows folders.
    const folderChipsSection =
      galleryTab === "folders" && currentSubfolders.length > 0 ? (
        <div className="px-4 pt-4">
          {activeFolderId && (
            <h3 className="text-md mb-2 font-medium text-base-fg/60">
              Folders
            </h3>
          )}
          <div
            className={twMerge("grid", gapClass)}
            style={{
              gridTemplateColumns: `repeat(${gridColumns}, minmax(0, 1fr))`,
            }}
          >
            {currentSubfolders.map((folder) => (
              <GalleryFolderChip
                key={folder.id}
                folder={folder}
                childCount={folderChildCount(folder.id)}
                onOpen={handleOpenFolder}
                // Folder management is view-mode only; the select picker just browses.
                onContextMenu={
                  mode === "view"
                    ? (folderId, x, y) => setContextMenu({ folderId, x, y })
                    : undefined
                }
              />
            ))}
          </div>
        </div>
      ) : null;

    return (
      <>
        <Modal
          resizable={mode === "view"}
          // While dragging an item out, the panel becomes pointer-transparent so
          // the drag passes under it onto the canvas. With "Reopen after adding"
          // ON it steps back to translucent (stays to keep adding); with it OFF
          // it eases all the way out (it's closing after the drop anyway). Both
          // go through the same spring, so neither is abrupt.
          contentInteractive={!galleryModalDraggingUnder.value}
          contentDimmed={
            galleryModalDraggingUnder.value &&
            galleryReopenAfterDragSignal.value
          }
          contentHidden={
            galleryModalDraggingUnder.value &&
            !galleryReopenAfterDragSignal.value
          }
          isOpen={
            mode === "view"
              ? galleryModalVisibleViewMode.value
              : typeof isOpen === "boolean"
                ? isOpen
                : true
          }
          onClose={() => {
            if (mode === "view") {
              clearBulkSelection();
              onClose?.() || (galleryModalVisibleViewMode.value = false);
            } else {
              onClose?.();
            }
          }}
          className={twMerge(
            "h-[780px] max-h-[90vh] w-full max-w-5xl rounded-2xl",
            mode === "view" &&
              "h-[780px] min-h-[640px] min-w-[66rem] w-[66rem] max-w-none",
          )}
          childPadding={false}
          showClose={false}
          draggable={mode === "view"}
          allowBackgroundInteraction={mode === "view" ? true : false}
          closeOnOutsideClick={mode === "view" ? false : true}
        >
          {mode === "view" && (
            <Modal.DragHandle>
              <div className="absolute left-0 top-0 z-[50] h-[60px] w-full cursor-move" />
            </Modal.DragHandle>
          )}
          <div className="relative flex h-full flex-col">
            <div className="border-b border-ui-panel-border p-4 py-3 bg-ui-panel rounded-t-xl">
              <div className="flex flex-wrap justify-between items-center gap-y-2">
                <div className="flex items-center gap-3 flex-wrap gap-y-1">
                  {(mode === "view" || mode === "select") && (
                    <div className="flex items-center gap-0.5 rounded-lg bg-ui-controls/40 p-0.5 relative z-[51]">
                      {(["unsorted", "folders"] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => switchGalleryTab(t)}
                          className={twMerge(
                            "rounded-md px-3 py-1 text-sm font-medium transition-colors",
                            galleryTab === t
                              ? "bg-ui-controls text-base-fg"
                              : "text-base-fg/60 hover:text-base-fg",
                          )}
                        >
                          {t === "unsorted" ? "All Assets" : "Folders"}
                        </button>
                      ))}
                    </div>
                  )}
                  {mode === "view" &&
                    galleryTab === "folders" &&
                    !activeFolder && (
                      <button
                        type="button"
                        onClick={() => handleOpenNewFolderModal(null)}
                        className="flex items-center gap-2 rounded-lg bg-ui-controls/60 px-3 py-1.5 text-sm font-medium text-base-fg hover:bg-ui-controls/90 transition-colors relative z-[51]"
                      >
                        <FolderPlus size="1em" className="text-xs" />
                        New folder
                      </button>
                    )}
                  {activeTag ? (
                    /* ── Tag view header (Tags / name) ── */
                    <div className="flex items-center gap-1.5 relative z-[51]">
                      <button
                        type="button"
                        onClick={handleOpenTagBrowser}
                        className="text-base-fg/50 hover:text-base-fg text-sm transition-colors"
                      >
                        Tags
                      </button>
                      <span className="text-base-fg/30">/</span>
                      <Tag size="1em" className="text-sm text-violet-400" />
                      <h2 className="text-lg font-semibold truncate max-w-[16rem]">
                        {activeTag.tag_value}
                      </h2>
                      <span className="text-base-fg/40 text-sm">
                        {activeTag.use_count} file
                        {activeTag.use_count === 1 ? "" : "s"}
                      </span>
                      <button
                        type="button"
                        onClick={handleCloseTagView}
                        aria-label="Close tag view"
                        className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-ui-controls/60 text-base-fg/60 hover:text-base-fg transition-colors"
                      >
                        <X size="1em" className="text-sm" />
                      </button>
                    </div>
                  ) : tagBrowserOpen ? (
                    /* ── All-tags browser header ── */
                    <div className="flex items-center gap-2 relative z-[51]">
                      <Tag size="1em" className="text-sm text-violet-400" />
                      <h2 className="text-lg font-semibold">Tags</h2>
                      <button
                        type="button"
                        onClick={handleCloseTagView}
                        aria-label="Close tags"
                        className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-ui-controls/60 text-base-fg/60 hover:text-base-fg transition-colors"
                      >
                        <X size="1em" className="text-sm" />
                      </button>
                    </div>
                  ) : galleryTab === "folders" && activeFolder ? (
                    /* ── Folder header (breadcrumb trail) ── */
                    <div className="flex items-center gap-1.5 relative z-[51] flex-wrap">
                      <button
                        type="button"
                        onClick={handleBackToLibrary}
                        className="text-base-fg/50 hover:text-base-fg text-sm transition-colors"
                      >
                        Folders
                      </button>
                      {/* Ancestor crumbs (everything above the active folder) */}
                      {folderPath.slice(0, -1).map((crumb) => (
                        <React.Fragment key={crumb.id}>
                          <span className="text-base-fg/30">/</span>
                          <button
                            type="button"
                            onClick={() => handleOpenFolder(crumb.id)}
                            className="text-base-fg/50 hover:text-base-fg text-sm transition-colors truncate max-w-[10rem]"
                          >
                            {crumb.name}
                          </button>
                        </React.Fragment>
                      ))}
                      <span className="text-base-fg/30">/</span>
                      {renamingFolderId === activeFolderId &&
                      !renameViaModal ? (
                        <input
                          ref={renameInputRef}
                          type="text"
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") handleConfirmRename();
                            if (e.key === "Escape") setRenamingFolderId(null);
                          }}
                          onBlur={handleConfirmRename}
                          className="text-lg font-semibold bg-transparent rounded px-1.5 py-0 text-base-fg outline-none min-w-[6rem] caret-primary"
                          autoFocus
                        />
                      ) : (
                        <h2
                          className="text-lg font-semibold cursor-pointer hover:bg-ui-controls/30 rounded px-1.5 py-0 transition-colors truncate max-w-[20rem]"
                          onClick={() => handleStartRename(activeFolderId!)}
                        >
                          {activeFolder.name}
                        </h2>
                      )}
                      {/* Folder ... menu */}
                      <div
                        className={twMerge(
                          "relative",
                          renamingFolderId === activeFolderId &&
                            !renameViaModal &&
                            "hidden",
                        )}
                      >
                        <button
                          type="button"
                          onClick={() => setFolderMenuOpen((v) => !v)}
                          className="flex h-7 w-7 items-center justify-center rounded-full hover:bg-ui-controls/60 text-base-fg/60 hover:text-base-fg transition-colors"
                        >
                          <Ellipsis size="1em" className="text-sm" />
                        </button>
                        {folderMenuOpen && (
                          <>
                            <div
                              className="fixed inset-0 z-[58]"
                              onClick={() => setFolderMenuOpen(false)}
                            />
                            <FolderContextMenuItems
                              className="absolute left-0 top-full mt-1"
                              folderId={activeFolderId!}
                              hasStar={activeFolder?.hasStar}
                              colorCode={activeFolder?.colorCode}
                              onRename={(id) => handleStartRename(id, false)}
                              onDelete={handleDeleteFolder}
                              onNewSubfolder={(id) => {
                                setFolderMenuOpen(false);
                                handleOpenNewFolderModal(id);
                              }}
                              onToggleStar={handleSetFolderStar}
                              onSetColor={handleSetFolderColor}
                            />
                          </>
                        )}
                      </div>
                    </div>
                  ) : (
                    /* ── Normal header ── */
                    <>
                      {mode === "select" && galleryTab === "unsorted" && (
                        <h2 className="text-xl font-semibold">
                          {activeFilter === "video"
                            ? maxSelections === 1
                              ? "Select Video"
                              : "Select Videos"
                            : activeFilter === "audio"
                              ? "Select Audio"
                            : activeFilter === "mesh"
                              ? maxSelections === 1
                                ? "Select 3D Object"
                                : "Select 3D Objects"
                              : activeFilter === "splat"
                                ? maxSelections === 1
                                  ? "Select 3D World"
                                  : "Select 3D Worlds"
                              : activeFilter === "uploaded"
                                ? maxSelections === 1
                                  ? "Select Upload"
                                  : "Select Uploads"
                                : activeFilter === "all"
                                  ? "Select Media"
                                  : maxSelections === 1
                                    ? "Select Image"
                                    : "Select Images"}
                        </h2>
                      )}
                      {mode === "view" && galleryTab === "unsorted" && (
                        <div className="relative z-[51] flex items-center">
                          <Checkbox
                            id="gallery-reopen-after-drag"
                            checked={galleryReopenAfterDragSignal.value}
                            onChange={(e) =>
                              (galleryReopenAfterDragSignal.value =
                                e.target.checked)
                            }
                            label="Reopen after adding"
                          />
                        </div>
                      )}
                    </>
                  )}
                  {galleryTab === "unsorted" &&
                    !activeTagToken &&
                    !tagBrowserOpen &&
                    activeFilter !== "uploaded" && (
                    <div className="relative z-[51] flex items-center">
                      <Checkbox
                        id="gallery-show-uploads"
                        checked={showUploads}
                        onChange={(e) => setShowUploads(e.target.checked)}
                        label="Show uploads"
                      />
                    </div>
                  )}
                </div>
                <div className="flex justify-end gap-2 items-center flex-wrap ml-auto">
                  {/* Refresh button */}
                  <Tooltip
                    position="top"
                    content="Refresh list"
                    closeOnClick={true}
                  >
                    <Button
                      variant="action"
                      onClick={refreshGallery}
                      className="relative z-[51] h-9 w-9"
                      disabled={loading}
                      aria-label="Refresh list"
                    >
                      <RefreshCw
                        size="1em"
                        className={`text-lg text-base-fg ${loading ? "animate-spin" : ""}`}
                      />
                    </Button>
                  </Tooltip>
                  {/* Image fit toggle button */}
                  <Tooltip
                    position="top"
                    content="Toggle image fit"
                    closeOnClick={true}
                  >
                    <Button
                      variant="action"
                      onClick={() =>
                        setImageFit((fit) =>
                          fit === "cover" ? "contain" : "cover",
                        )
                      }
                      className="relative z-[51] h-9 w-9"
                    >
                      {imageFit === "cover" ? (
                        <Expand size="1em" className="text-lg text-base-fg" />
                      ) : (
                        <Shrink size="1em" className="text-lg text-base-fg" />
                      )}
                    </Button>
                  </Tooltip>

                  {/* Slider (hidden on narrow screens — grid is locked to 2 cols there) */}
                  <div className="hidden sm:flex w-32 mx-3 relative z-[51] items-center gap-2">
                    <SliderV2
                      min={minColumns}
                      max={maxColumns}
                      value={sliderValue}
                      onChange={setSliderValue}
                      step={1}
                      variant="classic"
                      showTooltip={false}
                      className="w-full"
                      showProgressBar={false}
                      tooltipContent={`${
                        maxColumns - (sliderValue - minColumns)
                      } columns`}
                    />
                  </div>
                  {mode === "view" && <Modal.ExpandButton />}
                  <CloseButton
                    onClick={() => {
                      if (mode === "view") {
                        clearBulkSelection();
                        galleryModalVisibleViewMode.value = false;
                      } else {
                        onClose?.();
                      }
                    }}
                    className="relative z-[51]"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-1 overflow-hidden" data-gallery-modal>
              {/* ── Filter sidebar ── shown on both tabs; clicking a filter
                  jumps back to the library, clicking a folder into the browser */}
              {!hideFilter && (
                <div className="w-52 min-w-[13rem] border-r border-ui-panel-border bg-ui-panel flex flex-col overflow-hidden">
                  {/* Filter items — pinned; they never scroll out of view */}
                  <div className="flex flex-col px-1.5 pt-2 pb-1 flex-shrink-0">
                    {SIDEBAR_FILTERS.map((f) => {
                      const FilterIcon = f.icon;
                      const isActive =
                        galleryTab === "unsorted" && activeFilter === f.id;
                      return (
                        <button
                          key={f.id}
                          type="button"
                          onClick={() => {
                            if (!forceFilter) {
                              setActiveFilter(f.id);
                              switchGalleryTab("unsorted");
                            }
                          }}
                          className={twMerge(
                            "flex items-center justify-between gap-2 rounded-md px-2.5 py-1.5 text-sm transition-colors",
                            isActive &&
                              !activeFolderId &&
                              !activeTagToken &&
                              !tagBrowserOpen
                              ? "bg-ui-controls/60 text-base-fg font-medium"
                              : "text-base-fg/70 hover:bg-ui-controls/30 hover:text-base-fg",
                            forceFilter &&
                              f.id !== activeFilter &&
                              "opacity-50 pointer-events-none",
                          )}
                        >
                          <div className="flex items-center gap-2.5">
                            <FilterIcon size="1em" className="text-xs w-4" />
                            <span>{f.label}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  {/* Folders header — pinned alongside the filters */}
                  <div className="flex items-center justify-between px-3 pt-2 pb-1 flex-shrink-0">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-base-fg/40">
                      Folders
                    </span>
                    {mode === "view" && (
                      <button
                        type="button"
                        onClick={() => handleOpenNewFolderModal(null)}
                        aria-label="New folder"
                        className="flex h-5 w-5 items-center justify-center rounded text-base-fg/50 hover:bg-ui-controls/60 hover:text-base-fg transition-colors"
                      >
                        <Plus size="1em" className="text-[10px]" />
                      </button>
                    )}
                  </div>
                  {/* Folder list — the only scrolling region; fills the rest of the column */}
                  <div className="flex flex-1 min-h-0 flex-col overflow-y-auto px-1.5 pb-2">
                    {rootFolders.length === 0 ? (
                      <div className="px-2.5 py-1.5 text-xs text-base-fg/30 italic">
                        No folders yet
                      </div>
                    ) : (
                      rootFolders.map((folder) => (
                        <button
                          key={folder.id}
                          type="button"
                          data-folder-id={folder.id}
                          onClick={() => handleOpenFolderFromSidebar(folder.id)}
                          onContextMenu={
                            // Folder management is view-mode only; the select picker just browses.
                            mode === "view"
                              ? (e) => {
                                  e.preventDefault();
                                  setContextMenu({
                                    folderId: folder.id,
                                    x: e.clientX,
                                    y: e.clientY,
                                  });
                                }
                              : undefined
                          }
                          className={twMerge(
                            "flex w-full flex-shrink-0 items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm transition-colors [&.folder-drag-over]:bg-primary/20 [&.folder-drag-over]:text-base-fg",
                            activeRootFolderId === folder.id
                              ? "bg-ui-controls/60 text-base-fg font-medium"
                              : "text-base-fg/70 hover:bg-ui-controls/30 hover:text-base-fg",
                          )}
                        >
                          <Folder
                            size="1em"
                            className={twMerge(
                              "text-xs w-4",
                              !folder.colorCode && "text-primary",
                            )}
                            style={
                              folder.colorCode
                                ? { color: folder.colorCode }
                                : undefined
                            }
                          />
                          <span className="truncate">{folder.name}</span>
                          {folder.hasStar && (
                            <Star
                              size="1em"
                              className="ml-auto text-[10px] text-amber-400"
                            />
                          )}
                        </button>
                      ))
                    )}

                    {/* Tags — most-used first, capped until "Show all". Hidden
                        entirely until the user has tags (they're created from
                        the item view's Tags section). */}
                    {userTags.length > 0 && (
                      <>
                        <div className="flex items-center justify-between px-1.5 pt-3 pb-1 flex-shrink-0">
                          <span className="text-[11px] font-semibold uppercase tracking-wider text-base-fg/40">
                            Tags
                          </span>
                        </div>
                        {sidebarTags.map((tag) => (
                          <button
                            key={tag.tag_token}
                            type="button"
                            onClick={() =>
                              handleOpenTagFromSidebar(tag.tag_token)
                            }
                            className={twMerge(
                              "flex w-full flex-shrink-0 items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm transition-colors",
                              activeTagToken === tag.tag_token
                                ? "bg-ui-controls/60 text-base-fg font-medium"
                                : "text-base-fg/70 hover:bg-ui-controls/30 hover:text-base-fg",
                            )}
                          >
                            <Tag
                              size="1em"
                              className="text-xs w-4 text-violet-400"
                            />
                            <span className="truncate">{tag.tag_value}</span>
                            <span className="ml-auto text-[10px] text-base-fg/40">
                              {tag.use_count}
                            </span>
                          </button>
                        ))}
                        <button
                          type="button"
                          onClick={handleOpenTagBrowser}
                          className={twMerge(
                            "flex w-full flex-shrink-0 items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm transition-colors",
                            tagBrowserOpen && !activeTagToken
                              ? "bg-ui-controls/60 text-base-fg font-medium"
                              : "text-base-fg/50 hover:bg-ui-controls/30 hover:text-base-fg",
                          )}
                        >
                          <Ellipsis size="1em" className="text-xs w-4" />
                          <span>All tags</span>
                          <span className="ml-auto text-[10px] text-base-fg/40">
                            {sortedTags.length}
                          </span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* ── Main content ── */}
              <div
                ref={scrollContainerRef}
                className="flex-1 overflow-y-auto bg-ui-panel"
                onScroll={handleScroll}
                onPointerDown={
                  mode === "view" ? handleMarqueePointerDown : undefined
                }
              >
                {/* Subfolder tiles for the current location (root or open folder) */}
                {folderChipsSection}
                {activeTagToken ? (
                  /* ── Tag view ── */
                  tagContentLoading && activeTagItems.length === 0 ? (
                    <div className="flex h-full items-center justify-center">
                      <LoadingSpinner className="h-8 w-8" />
                    </div>
                  ) : activeTagItems.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center gap-3">
                      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-400/10">
                        <Tag size="1em" className="text-violet-400 text-2xl" />
                      </div>
                      <div className="text-base-fg font-semibold">
                        No files carry this tag
                      </div>
                      <div className="text-base-fg/40 text-sm text-center max-w-[16rem]">
                        Add tags to media from the item view's Tags section.
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6 p-4">
                      {Object.entries(tagGroupedItems).map(
                        ([date, dateItems], groupIndex) => {
                          const filteredItems = dateItems.filter(filterItem);
                          if (filteredItems.length === 0) return null;
                          return (
                            <LazyDateGroup
                              key={date}
                              eager={groupIndex < 2}
                              itemCount={filteredItems.length}
                              gridColumns={gridColumns}
                              scrollRoot={scrollContainerRef.current}
                            >
                              <h3 className="text-md mb-2 font-medium text-base-fg/60">
                                {date}
                              </h3>
                              <div
                                className={twMerge("grid", gapClass)}
                                style={{
                                  gridTemplateColumns: `repeat(${gridColumns}, minmax(0, 1fr))`,
                                }}
                              >
                                {filteredItems.map((item) => (
                                  <GalleryDraggableItem
                                    key={item.id}
                                    item={item}
                                    mode={mode}
                                    activeFilter={activeFilter}
                                    audioPromptText={audioPromptTextFor(item)}
                                    selected={selectedItemIds.includes(item.id)}
                                    onClick={() => handleItemClick(item)}
                                    onImageError={(e) => {
                                      e.currentTarget.src =
                                        PLACEHOLDER_IMAGES.DEFAULT;
                                      e.currentTarget.style.opacity = "0.3";
                                      (
                                        e.currentTarget as HTMLImageElement
                                      ).dataset.brokenurl =
                                        item.thumbnail || "";
                                      handleImageError(item.thumbnail!);
                                    }}
                                    disableTooltipAndBadge={mode === "select"}
                                    imageFit={imageFit}
                                    onDeleted={handleItemDeleted}
                                    onDelete={onDeleteMedia}
                                    onEditClicked={onEditClicked}
                                    maxSelections={maxSelections}
                                    bulkSelected={bulkSelectedIds.has(item.id)}
                                    onBulkSelectToggle={() =>
                                      toggleBulkSelect(item.id)
                                    }
                                    bulkSelectionMode={bulkSelectionMode}
                                    getBulkDragItems={getBulkDragItems}
                                    folders={folders}
                                    onAddToFolder={requestFolderDrop}
                                    onCreateFolderFromMenu={
                                      handleOpenNewFolderModal
                                    }
                                  />
                                ))}
                              </div>
                            </LazyDateGroup>
                          );
                        },
                      )}
                      {tagLoadingMore && (
                        <div className="flex justify-center py-4">
                          <LoadingSpinner className="h-8 w-8" />
                        </div>
                      )}
                    </div>
                  )
                ) : tagBrowserOpen ? (
                  /* ── All-tags word cloud ── */
                  userTags.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center gap-3">
                      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-400/10">
                        <Tag size="1em" className="text-violet-400 text-2xl" />
                      </div>
                      <div className="text-base-fg font-semibold">
                        No tags yet
                      </div>
                      <div className="text-base-fg/40 text-sm text-center max-w-[16rem]">
                        Open any item and add tags in its details panel —
                        they'll show up here.
                      </div>
                    </div>
                  ) : (
                    <TagCloudView
                      tags={sortedTags}
                      onOpen={handleOpenTagFromSidebar}
                    />
                  )
                ) : galleryTab === "folders" && !activeFolderId ? (
                  /* ── Folders tab, root: folder cards only (above) ── */
                  currentSubfolders.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center gap-3">
                      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                        <Folder
                          size="1em"
                          className="text-primary text-2xl"
                        />
                      </div>
                      <div className="text-base-fg font-semibold">
                        No folders yet
                      </div>
                      <div className="text-base-fg/40 text-sm text-center max-w-[16rem]">
                        Create a folder to organize your media.
                      </div>
                      {mode === "view" && (
                        <Button
                          variant="action"
                          icon={FolderPlus}
                          onClick={() => handleOpenNewFolderModal(null)}
                          className="mt-1 px-3 py-1.5 text-sm"
                        >
                          New folder
                        </Button>
                      )}
                    </div>
                  ) : null
                ) : activeFolderId ? (
                  /* ── Folder view ── */
                  folderContentLoading && activeFolderItems.length === 0 ? (
                    currentSubfolders.length > 0 ? null : (
                      <div className="flex h-full items-center justify-center">
                        <LoadingSpinner className="h-8 w-8" />
                      </div>
                    )
                  ) : activeFolderItems.length === 0 ? (
                    currentSubfolders.length > 0 ? null : (
                      <div className="flex h-full flex-col items-center justify-center gap-3">
                        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                          <Folder
                            size="1em"
                            className="text-primary text-2xl"
                          />
                        </div>
                        <div className="text-base-fg font-semibold">
                          This folder is empty
                        </div>
                        <div className="text-base-fg/40 text-sm text-center max-w-[16rem]">
                          {mode === "view"
                            ? "Drag images here, generate new ones, or create a subfolder."
                            : "There's nothing in this folder yet."}
                        </div>
                        {mode === "view" && (
                          <Button
                            variant="action"
                            icon={FolderPlus}
                            onClick={() =>
                              handleOpenNewFolderModal(activeFolderId)
                            }
                            className="mt-1 px-3 py-1.5 text-sm"
                          >
                            New folder
                          </Button>
                        )}
                      </div>
                    )
                  ) : (
                    <div className="space-y-6 p-4">
                      {Object.entries(folderGroupedItems).map(
                        ([date, dateItems], groupIndex) => {
                          const filteredItems = dateItems.filter(filterItem);
                          if (filteredItems.length === 0) return null;
                          return (
                            <LazyDateGroup
                              key={date}
                              eager={groupIndex < 2}
                              itemCount={filteredItems.length}
                              gridColumns={gridColumns}
                              scrollRoot={scrollContainerRef.current}
                            >
                              <h3 className="text-md mb-2 font-medium text-base-fg/60">
                                {date}
                              </h3>
                              <div
                                className={twMerge("grid", gapClass)}
                                style={{
                                  gridTemplateColumns: `repeat(${gridColumns}, minmax(0, 1fr))`,
                                }}
                              >
                                {filteredItems.map((item) => (
                                  <GalleryDraggableItem
                                    key={item.id}
                                    item={item}
                                    mode={mode}
                                    activeFilter={activeFilter}
                                    audioPromptText={audioPromptTextFor(item)}
                                    selected={selectedItemIds.includes(item.id)}
                                    onClick={() => handleItemClick(item)}
                                    onImageError={(e) => {
                                      e.currentTarget.src =
                                        PLACEHOLDER_IMAGES.DEFAULT;
                                      e.currentTarget.style.opacity = "0.3";
                                      (
                                        e.currentTarget as HTMLImageElement
                                      ).dataset.brokenurl =
                                        item.thumbnail || "";
                                      handleImageError(item.thumbnail!);
                                    }}
                                    disableTooltipAndBadge={mode === "select"}
                                    imageFit={imageFit}
                                    onDeleted={handleItemDeleted}
                                    onDelete={onDeleteMedia}
                                    onEditClicked={onEditClicked}
                                    maxSelections={maxSelections}
                                    bulkSelected={bulkSelectedIds.has(item.id)}
                                    onBulkSelectToggle={() =>
                                      toggleBulkSelect(item.id)
                                    }
                                    bulkSelectionMode={bulkSelectionMode}
                                    getBulkDragItems={getBulkDragItems}
                                    folders={folders}
                                    onAddToFolder={requestFolderDrop}
                                    onCreateFolderFromMenu={
                                      handleOpenNewFolderModal
                                    }
                                    onRemoveFromFolder={
                                      activeFolderId
                                        ? handleRemoveFromFolder
                                        : undefined
                                    }
                                  />
                                ))}
                              </div>
                            </LazyDateGroup>
                          );
                        },
                      )}
                      {folderLoadingMore && (
                        <div className="flex justify-center py-4">
                          <LoadingSpinner className="h-8 w-8" />
                        </div>
                      )}
                    </div>
                  )
                ) : (
                  /* ── Library view ── */
                  <>
                    {usernameError && allItems.length === 0 ? (
                      <div className="flex h-full items-center justify-center">
                        <div className="flex max-w-xs flex-col items-center gap-4 text-center text-sm">
                          <div className="text-base-fg/60">
                            Log in to browse and use your library.
                          </div>
                          {onLoginClick ? (
                            <button
                              className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-primary/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
                              onClick={() => onLoginClick()}
                            >
                              Log in
                            </button>
                          ) : (
                            <button
                              className="text-xs text-blue-400 underline hover:text-blue-300"
                              onClick={() => {
                                setUsernameError(false);
                                setUsernameRetryCount((c) => c + 1);
                              }}
                            >
                              Retry
                            </button>
                          )}
                        </div>
                      </div>
                    ) : itemsLoadError && allItems.length === 0 ? (
                      <div className="flex h-full items-center justify-center">
                        <div className="flex flex-col items-center gap-3 text-sm max-w-xs text-center">
                          <div className="text-base-fg/60">
                            Failed to load gallery.
                          </div>
                          <div className="text-xs text-base-fg/40 font-mono break-all">
                            {itemsLoadError}
                          </div>
                          <div className="flex gap-3">
                            <button
                              className="text-xs text-blue-400 hover:text-blue-300 underline"
                              onClick={() =>
                                navigator.clipboard?.writeText(itemsLoadError!)
                              }
                            >
                              Copy error
                            </button>
                            <button
                              className="text-xs text-blue-400 hover:text-blue-300 underline"
                              onClick={() => refreshGallery()}
                            >
                              Retry
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (initialLoading || !username) &&
                      allItems.length === 0 ? (
                      <SkeletonGrid columns={gridColumns} />
                    ) : allItems.length === 0 &&
                      !loading &&
                      currentSubfolders.length === 0 ? (
                      <div className="flex h-full items-center justify-center">
                        <div className="text-base-fg/40 text-sm">
                          No items yet
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-6 p-4">
                        {Object.entries(groupedItems).map(
                          ([date, dateItems], groupIndex) => {
                            const filteredItems = dateItems.filter(filterItem);
                            if (filteredItems.length === 0) return null;
                            return (
                              <LazyDateGroup
                                key={date}
                                eager={groupIndex < 2}
                                itemCount={filteredItems.length}
                                gridColumns={gridColumns}
                                scrollRoot={scrollContainerRef.current}
                              >
                                <h3 className="text-md mb-2 font-medium text-base-fg/60">
                                  {date}
                                </h3>
                                <div
                                  className={twMerge("grid", gapClass)}
                                  style={{
                                    gridTemplateColumns: `repeat(${gridColumns}, minmax(0, 1fr))`,
                                  }}
                                >
                                  {filteredItems.map((item) => (
                                    <GalleryDraggableItem
                                      key={item.id}
                                      item={item}
                                      mode={mode}
                                      activeFilter={activeFilter}
                                      audioPromptText={audioPromptTextFor(
                                        item,
                                      )}
                                      selected={selectedItemIds.includes(
                                        item.id,
                                      )}
                                      onClick={() => handleItemClick(item)}
                                      onImageError={(e) => {
                                        e.currentTarget.src =
                                          PLACEHOLDER_IMAGES.DEFAULT;
                                        e.currentTarget.style.opacity = "0.3";
                                        (
                                          e.currentTarget as HTMLImageElement
                                        ).dataset.brokenurl =
                                          item.thumbnail || "";
                                        handleImageError(item.thumbnail!);
                                      }}
                                      disableTooltipAndBadge={mode === "select"}
                                      imageFit={imageFit}
                                      onDeleted={handleItemDeleted}
                                      onDelete={onDeleteMedia}
                                      onEditClicked={onEditClicked}
                                      maxSelections={maxSelections}
                                      bulkSelected={bulkSelectedIds.has(
                                        item.id,
                                      )}
                                      onBulkSelectToggle={() =>
                                        toggleBulkSelect(item.id)
                                      }
                                      bulkSelectionMode={bulkSelectionMode}
                                      getBulkDragItems={getBulkDragItems}
                                      folders={folders}
                                      onAddToFolder={handleAddToFolder}
                                      onCreateFolderFromMenu={
                                        handleOpenNewFolderModal
                                      }
                                    />
                                  ))}
                                </div>
                              </LazyDateGroup>
                            );
                          },
                        )}
                        {paginationLoading && allItems.length > 0 && (
                          <div className="flex justify-center py-4">
                            <LoadingSpinner className="h-8 w-8" />
                          </div>
                        )}
                        {!hasMore && allItems.length > 0 && (
                          <div className="flex justify-center py-4 text-base-fg/40 text-xs">
                            No more items
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>

            {/* ── New Folder dialog ── */}
            <FolderNameDialog
              isOpen={newFolderModalOpen}
              title="New folder"
              subtitle={`in ${
                newFolderParentId
                  ? (folders.find((f) => f.id === newFolderParentId)?.name ??
                    "My Library")
                  : "My Library"
              }`}
              initialValue="New Folder"
              confirmLabel="Create"
              onConfirm={handleCreateFolder}
              onClose={() => {
                setNewFolderModalOpen(false);
                setNewFolderItemIds([]);
              }}
            />

            {/* ── Rename Folder dialog (sidebar context menu) ── */}
            <FolderNameDialog
              isOpen={!!(renameViaModal && renamingFolderId)}
              title="Rename folder"
              initialValue={
                folders.find((f) => f.id === renamingFolderId)?.name ?? ""
              }
              confirmLabel="Rename"
              onConfirm={handleConfirmRename}
              onClose={() => {
                setRenamingFolderId(null);
                setRenameViaModal(false);
              }}
            />

            {mode === "view" && bulkSelectionMode && (
              <div className="flex items-center justify-between border-t border-ui-panel-border bg-ui-background p-3 py-2 rounded-b-xl">
                <div className="flex items-center">
                  {/* Thumbnail previews of selected items */}
                  <div className="flex">
                    {bulkSelectedItems.slice(0, 4).map((si) => {
                      const placeholderIcon =
                        si.mediaClass === "video"
                          ? Video
                          : si.mediaClass === "audio"
                            ? Music
                            : si.mediaClass === "dimensional" ||
                                si.mediaClass === "mesh" ||
                                si.mediaClass === "splat"
                              ? Box
                              : Image;
                      return (
                        <BulkThumb
                          key={si.id}
                          thumbnail={si.thumbnail}
                          placeholderIcon={placeholderIcon}
                        />
                      );
                    })}
                  </div>
                  {bulkSelectedItems.length > 4 && (
                    <div className="h-8 w-8 rounded overflow-hidden border-2 border-ui-panel bg-black/20 flex-shrink-0 flex items-center justify-center">
                      <span className="text-[11px] font-normal text-white/70">
                        +{bulkSelectedItems.length - 4}
                      </span>
                    </div>
                  )}
                  <span className="ms-2.5 text-sm font-medium text-base-fg/80">
                    {bulkSelectedIds.size} selected
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {/* Add to folder */}
                  <div className="relative">
                    <Button
                      variant="action"
                      onClick={() => setBulkFolderPopoverOpen((v) => !v)}
                      className="px-3 bg-ui-controls/60 hover:bg-ui-controls/90"
                      icon={FolderPlus}
                    >
                      Add to folder
                    </Button>
                    {bulkFolderPopoverOpen && (
                      <>
                        {/* Backdrop to close */}
                        <div
                          className="fixed inset-0 z-[59]"
                          onClick={() => setBulkFolderPopoverOpen(false)}
                        />
                        <div className="absolute bottom-full mb-2 right-0 w-56 rounded-lg border border-ui-panel-border bg-ui-panel p-2 shadow-xl z-[60]">
                          {/* Folders */}
                          <div className="text-[11px] font-semibold uppercase tracking-wider text-base-fg/40 px-2 py-1">
                            Folders
                          </div>
                          {folders.length === 0 ? (
                            <div className="px-2 py-1.5 text-xs text-base-fg/30 italic">
                              No folders yet
                            </div>
                          ) : (
                            // Same ordering as the folder chips: starred
                            // first, then alphabetical.
                            [...folders].sort(compareFolders).map((folder) => (
                              <button
                                key={folder.id}
                                type="button"
                                className="flex w-full items-center gap-2.5 px-2 py-1.5 rounded-md hover:bg-ui-controls/50 text-sm text-base-fg transition-colors"
                                onClick={() => {
                                  const ids = Array.from(bulkSelectedIds);
                                  requestFolderDrop(ids, folder.id);
                                  setBulkFolderPopoverOpen(false);
                                }}
                              >
                                <Folder
                                  size="1em"
                                  className="text-primary text-xs"
                                />
                                <span className="truncate">{folder.name}</span>
                              </button>
                            ))
                          )}
                          <div className="mx-1.5 my-1 border-t border-ui-panel-border" />
                          <button
                            type="button"
                            className="flex w-full items-center gap-2.5 px-2 py-1.5 rounded-md hover:bg-ui-controls/50 text-sm text-base-fg/70 transition-colors"
                            onClick={() => {
                              const ids = Array.from(bulkSelectedIds);
                              setBulkFolderPopoverOpen(false);
                              handleOpenNewFolderModal(undefined, ids);
                            }}
                          >
                            <Plus size="1em" className="text-xs w-4" />
                            <span>Create new folder</span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                  {onDeleteMedia && (
                    <Button
                      variant="destructive"
                      onClick={handleBulkDelete}
                      className="px-3"
                      icon={Trash2}
                    >
                      Delete
                    </Button>
                  )}
                  <button
                    onClick={clearBulkSelection}
                    className="flex h-8 w-8 items-center justify-center rounded-md bg-ui-controls/60 hover:bg-ui-controls/90 text-base-fg transition-colors"
                    aria-label="Clear selection"
                  >
                    <X size="1em" className="text-base" />
                  </button>
                </div>
              </div>
            )}

            {mode === "select" && (
              <div className="flex items-center justify-between border-t border-ui-panel-border bg-ui-panel p-4 rounded-b-xl">
                <div className="flex items-center gap-3">
                  <div className="text-sm font-semibold text-base-fg/80">
                    {selectedItemIds.length}/{maxSelections} selected
                  </div>
                  {selectedItemIds.length > 0 && (
                    <span className="text-base-fg/10">|</span>
                  )}
                  {selectedItemIds.length > 0 && (
                    <button
                      onClick={handleDeselectAll}
                      className="text-sm text-base-fg/60 hover:text-base-fg"
                    >
                      Deselect All
                    </button>
                  )}
                </div>
                <Button
                  onClick={handleUseSelected}
                  disabled={selectedItemIds.length === 0 || useSelectedLoading}
                  loading={useSelectedLoading}
                >
                  Use selected
                </Button>
              </div>
            )}
          </div>
        </Modal>

        {mode === "view" && (
          <LightboxModal
            isOpen={lightboxVisibleSignal.value}
            onClose={handleCloseLightbox}
            onCloseGallery={handleCloseGallery}
            imageUrl={imageUrl}
            // pass multiple images if present
            imageUrls={imageUrls}
            actionUrls={actionUrls}
            mediaTokens={(lightboxImageSignal.value as any)?.mediaTokens}
            initialIndex={(lightboxImageSignal.value as any)?.initialIndex}
            batchImageToken={
              (lightboxImageSignal.value as any)?.batchImageToken
            }
            imageAlt={lightboxImageSignal.value?.label || ""}
            onImageError={() => imageUrl && handleImageError(imageUrl)}
            title={lightboxImageSignal.value?.label}
            createdAt={lightboxImageSignal.value?.createdAt}
            downloadUrl={imageUrl}
            mediaId={lightboxImageSignal.value?.id}
            onDownloadClicked={onDownloadClicked}
            onAddToSceneClicked={onAddToSceneClicked}
            mediaClass={lightboxImageSignal.value?.mediaClass}
            onEditClicked={onEditClicked}
            onTurnIntoVideoClicked={onTurnIntoVideoClicked}
            onRemoveBackgroundClicked={onRemoveBackgroundClicked}
            onMake3DObjectClicked={onMake3DObjectClicked}
            onMake3DWorldClicked={onMake3DWorldClicked}
            onRecreateClicked={onRecreateClicked}
            onNavigatePrev={
              galleryModalLightboxNavPrev.value ?? handleNavigatePrev
            }
            onNavigateNext={
              galleryModalLightboxNavNext.value ?? handleNavigateNext
            }
            onNavigateToMedia={handleNavigateToMedia}
          />
        )}

        {/* Right-click context menu for sidebar folders — portaled to body to avoid transform issues */}
        {contextMenu &&
          createPortal(
            <>
              <div
                className="fixed inset-0 z-[9998]"
                onClick={() => setContextMenu(null)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  setContextMenu(null);
                }}
              />
              <FolderContextMenuItems
                className="fixed z-[9999]"
                style={{ left: contextMenu.x, top: contextMenu.y }}
                folderId={contextMenu.folderId}
                hasStar={
                  folders.find((f) => f.id === contextMenu.folderId)?.hasStar
                }
                colorCode={
                  folders.find((f) => f.id === contextMenu.folderId)?.colorCode
                }
                onRename={(id) => handleStartRename(id, true)}
                onDelete={handleDeleteFolder}
                onNewSubfolder={(id) => {
                  setContextMenu(null);
                  handleOpenNewFolderModal(id);
                }}
                onToggleStar={handleSetFolderStar}
                onSetColor={handleSetFolderColor}
              />
            </>,
            document.body,
          )}

        {/* Marquee selection rectangle — fixed-positioned, painted imperatively
            by handleMarqueePointerDown. View mode only. Portaled to <body> so
            its `position: fixed` resolves against the viewport (the draggable
            modal applies a transform, which would otherwise make a fixed child
            position relative to the modal — and the rectangle, set with
            viewport clientX/Y, would render off-screen). */}
        {mode === "view" &&
          createPortal(
            <div
              ref={marqueeRef}
              className="pointer-events-none fixed z-[9999] rounded-sm border border-primary/60 bg-primary/10"
              style={{ display: "none" }}
            />,
            document.body,
          )}
      </>
    );
  },
);

GalleryModal.displayName = "GalleryModal";

export default GalleryModal;
