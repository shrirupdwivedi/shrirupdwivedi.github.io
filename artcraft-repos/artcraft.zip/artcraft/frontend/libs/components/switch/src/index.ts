
export * from './lib/switch';
