import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { JobsApi, JobStatus, MediaFilesApi } from "@storyteller/api";
import type { Job, Prompts } from "@storyteller/api";
import {
  getMediaStillThumbnail,
  getMediaThumbnail,
  THUMBNAIL_SIZES,
} from "@storyteller/common";
import {
  getModelDisplayName,
  getProviderDisplayName,
  ALL_MODELS_LIST,
} from "@storyteller/model-list";
import { getCachedPrompt, usePrompts } from "./prompts-cache";
import type {
  FailedJob,
  GalleryItem,
  GenerationMediaClass,
  InProgressJob,
} from "./types";
import { is3DMediaClass } from "./types";

// Maps JobsApi's recent-jobs stream into the canonical feed shapes
// (InProgressJob / FailedJob / newly-completed GalleryItem). HTTP-based, so
// both the webapp and the desktop app can use it (the desktop image/video
// pages use the Tauri task queue instead; audio enqueues over HTTP).

// ── Constants ──────────────────────────────────────────────────────────────

const IN_PROGRESS_STATUSES = new Set([JobStatus.PENDING, JobStatus.STARTED]);
const COMPLETED_STATUSES = new Set([JobStatus.COMPLETE_SUCCESS]);
const FAILED_STATUSES = new Set([
  JobStatus.ATTEMPT_FAILED,
  JobStatus.COMPLETE_FAILURE,
  JobStatus.DEAD,
  JobStatus.CANCELLED_BY_USER,
  JobStatus.CANCELLED_BY_SYSTEM,
]);

const FAILURE_REASON_LABEL: Record<string, string> = {
  rule_bans_user_image: "Image violates content policy",
  rule_bans_user_image_with_faces: "Images with faces are not allowed",
  rule_bans_user_text_prompt: "Text prompt violates content policy",
  rule_bans_user_content: "Content violates content policy",
  rule_bans_generated_video: "Generated video flagged by content policy",
  rule_bans_generated_audio: "Generated audio flagged by content policy",
  rule_bans_generated_content: "Generated content flagged by content policy",
  generation_failed: "Generation failed",
  unknown: "An unknown error occurred",
};

// Progress-bar defaults when the model doesn't declare a progressBarTime.
// Mirrors the backend's estimate baselines (audio 120s, video 300s+).
const DEFAULT_DURATION_MS: Record<GenerationMediaClass, number> = {
  image: 30000,
  video: 900000,
  audio: 120000,
  dimensional: 120000,
  mesh: 120000,
  splat: 120000,
};

// Cache per-task durations
const taskDurationCache = new Map<string, number>();

// ── Helpers ────────────────────────────────────────────────────────────────

// The backend `inference_category` strings for 3D are "object_generation"
// (mesh) and "splat_generation" (gaussian splats). Both render as the
// "dimensional" media class, but stay distinct here so the two 3D create pages
// can each filter to only their own generations.
export type JobMediaFilter =
  | "image"
  | "video"
  | "audio"
  | "object"
  | "splat";

function getJobMediaType(
  job: Job,
): JobMediaFilter | "other" {
  const cat = job.request.inference_category?.toLowerCase() ?? "";
  if (cat.includes("video")) return "video";
  if (cat.includes("object")) return "object";
  if (cat.includes("splat") || cat.includes("gaussian")) return "splat";
  if (cat.includes("image")) return "image";
  if (cat.includes("audio")) return "audio";
  return "other";
}

function getJobMediaClass(job: Job): GenerationMediaClass {
  const inferred = getJobMediaType(job);
  if (inferred === "object" || inferred === "splat") return "dimensional";
  return inferred === "other" ? "image" : inferred;
}

// Pull a cover image / screenshot URL off a 3D result (job result or a batch
// media file). The raw cdn_url is the .glb/.spz asset itself, so 3D cards use
// the separate cover image the backend attaches; falls back to null (the card
// then shows its 3D placeholder).
function get3DCoverThumbnail(source: any): string | null {
  const cover = source?.cover_image;
  if (!cover) return null;
  return (
    cover.maybe_links?.maybe_thumbnail_template?.replace("{WIDTH}", "512") ??
    cover.maybe_links?.cdn_url ??
    cover.maybe_cover_image_public_bucket_url ??
    null
  );
}

function getModelLabel(job: Job, promptsMap?: Map<string, Prompts>): string {
  const promptToken = job.request.maybe_prompt_token;
  const cachedPrompt = promptToken
    ? (promptsMap?.get(promptToken) ?? getCachedPrompt(promptToken))
    : undefined;

  const modelType =
    cachedPrompt?.maybe_model_type ?? job.request.maybe_model_type ?? "";
  const providerKey = cachedPrompt?.maybe_generation_provider ?? modelType;

  const modelDisplay = modelType ? getModelDisplayName(modelType) : undefined;
  const provider = providerKey
    ? getProviderDisplayName(providerKey.toLowerCase())
    : undefined;

  if (modelDisplay && provider) return `${modelDisplay} · ${provider}`;
  return modelDisplay || provider || "Unknown model";
}

function getPrompt(job: Job, promptsMap?: Map<string, Prompts>): string {
  const promptToken = job.request.maybe_prompt_token;
  const cached = promptToken
    ? (promptsMap?.get(promptToken) ?? getCachedPrompt(promptToken))
    : undefined;
  return (
    cached?.maybe_positive_prompt || job.request.maybe_raw_inference_text || ""
  );
}

function getModelId(job: Job, promptsMap?: Map<string, Prompts>): string {
  const promptToken = job.request.maybe_prompt_token;
  const cachedPrompt = promptToken
    ? (promptsMap?.get(promptToken) ?? getCachedPrompt(promptToken))
    : undefined;
  return cachedPrompt?.maybe_model_type ?? job.request.maybe_model_type ?? "";
}

function jobToInProgress(
  job: Job,
  promptsMap: Map<string, Prompts>,
): InProgressJob {
  const now = Date.now();
  const createdMs = new Date(job.created_at).getTime();
  const modelType = job.request.maybe_model_type;
  const mediaClass = getJobMediaClass(job);

  let duration = taskDurationCache.get(job.job_token);
  if (!duration) {
    const model = modelType
      ? ALL_MODELS_LIST.find(
          (m) => m.tauriId === modelType || m.id === modelType,
        )
      : undefined;
    duration = model?.progressBarTime ?? DEFAULT_DURATION_MS[mediaClass];
    taskDurationCache.set(job.job_token, duration);
  }

  const elapsed = now - createdMs;
  const progress = Math.min(95, (elapsed / duration) * 100);
  const estimatedTimeLeftMs = Math.max(0, duration - elapsed);

  return {
    id: job.job_token,
    prompt: getPrompt(job, promptsMap),
    modelId: getModelId(job, promptsMap),
    modelLabel: getModelLabel(job, promptsMap),
    progress,
    estimatedTimeLeftMs,
    createdAt: job.created_at,
    promptToken: job.request.maybe_prompt_token ?? undefined,
    mediaClass,
  };
}

function jobToFailed(job: Job, promptsMap: Map<string, Prompts>): FailedJob {
  const failureCategory =
    job.status.maybe_failure_category_updated ||
    job.status.maybe_failure_category;
  const rawMessage =
    job.status.maybe_failure_message ||
    job.status.maybe_extra_status_description;
  const failureReason = failureCategory
    ? FAILURE_REASON_LABEL[failureCategory] || rawMessage || undefined
    : rawMessage || undefined;
  const failureMessage =
    rawMessage && failureCategory !== "unknown" ? rawMessage : undefined;

  const promptToken = job.request.maybe_prompt_token ?? undefined;
  const promptData = promptToken ? promptsMap.get(promptToken) : undefined;
  const refImageUrl = pickFirstRefImageUrl(promptData);

  return {
    id: job.job_token,
    prompt: getPrompt(job, promptsMap),
    modelId: getModelId(job, promptsMap),
    modelLabel: getModelLabel(job, promptsMap),
    failureReason,
    failureMessage,
    status: job.status.status,
    createdAt: job.created_at,
    promptToken,
    refImageUrl,
    mediaClass: getJobMediaClass(job),
  };
}

// Semantics that aren't still images — videos and audio clips can't be rendered
// as the faded backdrop behind the error state, so skip them when picking the
// reference to display.
const NON_IMAGE_REF_SEMANTICS = new Set(["vid_ref", "audioref"]);

function pickFirstRefImageUrl(
  promptData: Prompts | undefined,
): string | undefined {
  const refs = promptData?.maybe_context_images;
  if (!refs?.length) return undefined;
  for (const ref of refs) {
    if (NON_IMAGE_REF_SEMANTICS.has(ref.semantic)) continue;
    const url = ref.media_links?.cdn_url;
    if (url) return url;
  }
  return undefined;
}

function jobToGalleryItem(
  job: Job,
  promptsMap?: Map<string, Prompts>,
): GalleryItem | null {
  const result = job.maybe_result;
  if (!result?.entity_token) return null;

  const mediaClass = getJobMediaClass(job);
  // Audio has no image thumbnail — its card renders a waveform player. 3D uses
  // the result's cover image / screenshot (the cdn_url is the mesh/splat file).
  const thumbnail =
    mediaClass === "audio"
      ? null
      : is3DMediaClass(mediaClass)
        ? get3DCoverThumbnail(result)
        : getMediaThumbnail(result.media_links, mediaClass, {
            size: THUMBNAIL_SIZES.LARGE,
          });

  return {
    id: result.entity_token,
    label: getPrompt(job, promptsMap) || "Generation",
    thumbnail,
    stillThumbnail:
      mediaClass === "video"
        ? getMediaStillThumbnail(result.media_links, {
            size: THUMBNAIL_SIZES.LARGE,
          })
        : null,
    fullImage: result.media_links?.cdn_url || null,
    // Sort by job creation time (not completion time) so the completed card
    // occupies the same Masonry slot the pending card held — no layout shift.
    createdAt: job.created_at,
    mediaClass,
    modelId: job.request.maybe_model_type ?? undefined,
  };
}

/** Expand a single GalleryItem into its batch siblings (if any). */
async function expandBatchItems(
  item: GalleryItem,
  mediaFilesApi: MediaFilesApi,
): Promise<GalleryItem[]> {
  try {
    const mediaResponse = await mediaFilesApi.GetMediaFileByToken({
      mediaFileToken: item.id,
    });
    const batchToken = (mediaResponse.data as any)?.maybe_batch_token;
    if (!batchToken) return [item];

    const batchResponse = await mediaFilesApi.GetMediaFilesByBatchToken({
      batchToken,
    });
    if (!batchResponse.success || !batchResponse.data?.length) return [item];

    return batchResponse.data
      .map((file: any): GalleryItem | null => {
        const cdnUrl = file.media_links?.cdn_url;
        if (!cdnUrl) return null;
        const thumbnail =
          item.mediaClass === "audio"
            ? null
            : is3DMediaClass(item.mediaClass)
              ? get3DCoverThumbnail(file)
              : getMediaThumbnail(file.media_links, item.mediaClass, {
                  size: THUMBNAIL_SIZES.LARGE,
                }) || cdnUrl;
        return {
          id: file.token,
          label: item.label,
          thumbnail,
          stillThumbnail:
            item.mediaClass === "video"
              ? getMediaStillThumbnail(file.media_links, {
                  size: THUMBNAIL_SIZES.LARGE,
                })
              : null,
          fullImage: cdnUrl,
          createdAt: item.createdAt,
          mediaClass: item.mediaClass,
          modelId: item.modelId,
          batchImageToken: batchToken,
          durationMillis: file.maybe_duration_millis ?? undefined,
        };
      })
      .filter((i): i is GalleryItem => i !== null);
  } catch {
    return [item];
  }
}

// ── Hook ───────────────────────────────────────────────────────────────────

export function useGenerationJobs(options: {
  mediaType: JobMediaFilter;
  enabled?: boolean;
}) {
  const { mediaType, enabled = true } = options;
  const apiRef = useRef(new JobsApi());
  const mediaApiRef = useRef(new MediaFilesApi());

  const [inProgressJobs, setInProgressJobs] = useState<Job[]>([]);
  const [failedJobsRaw, setFailedJobsRaw] = useState<Job[]>([]);
  const [newlyCompleted, setNewlyCompleted] = useState<GalleryItem[]>([]);

  const prevCompletedIdsRef = useRef<Set<string>>(new Set());
  const prevFailedIdsRef = useRef<Set<string>>(new Set());
  const initialLoadDoneRef = useRef(false);

  const promptTokens = useMemo(() => {
    const tokens: string[] = [];
    for (const j of inProgressJobs) {
      if (j.request.maybe_prompt_token)
        tokens.push(j.request.maybe_prompt_token);
    }
    for (const j of failedJobsRaw) {
      if (j.request.maybe_prompt_token)
        tokens.push(j.request.maybe_prompt_token);
    }
    return tokens;
  }, [inProgressJobs, failedJobsRaw]);
  const promptsMap = usePrompts(promptTokens);

  const inProgress = useMemo(
    () =>
      inProgressJobs
        .slice()
        .sort(
          (a, b) =>
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
        )
        .map((j) => jobToInProgress(j, promptsMap)),
    [inProgressJobs, promptsMap],
  );

  const failed = useMemo(
    () =>
      failedJobsRaw
        .slice()
        .sort(
          (a, b) =>
            new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
        )
        .map((j) => jobToFailed(j, promptsMap)),
    [failedJobsRaw, promptsMap],
  );

  const load = useCallback(async () => {
    try {
      const response = await apiRef.current.ListRecentJobs();
      if (!response.success || !response.data) return;

      const jobs: Job[] = response.data;

      // Filter by media type
      const filtered = jobs.filter((j) => getJobMediaType(j) === mediaType);

      const newInProgress = filtered.filter((j) =>
        IN_PROGRESS_STATUSES.has(j.status.status),
      );
      const newFailed = filtered.filter((j) =>
        FAILED_STATUSES.has(j.status.status),
      );

      // A newly-observed failure may have triggered a server-side refund, so
      // nudge the credits display — once now, and again after the refund has
      // had a moment to settle in the database. (Skip on first load: those
      // failures happened in a previous session.)
      const failedIdSet = new Set(newFailed.map((j) => j.job_token));
      if (
        initialLoadDoneRef.current &&
        newFailed.some((j) => !prevFailedIdsRef.current.has(j.job_token))
      ) {
        window.dispatchEvent(new Event("credits-change"));
        setTimeout(() => {
          window.dispatchEvent(new Event("credits-change"));
        }, 2500);
      }
      prevFailedIdsRef.current = failedIdSet;

      // Completed
      const completedJobs = filtered.filter((j) =>
        COMPLETED_STATUSES.has(j.status.status),
      );
      const completedIdSet = new Set(completedJobs.map((j) => j.job_token));

      // Detect newly completed (skip on first load to avoid flooding)
      let expandedNewItems: GalleryItem[] = [];
      if (initialLoadDoneRef.current) {
        const newOnes = completedJobs.filter(
          (j) => !prevCompletedIdsRef.current.has(j.job_token),
        );
        if (newOnes.length > 0) {
          const items = newOnes
            .map((j) => jobToGalleryItem(j))
            .filter((item): item is GalleryItem => item !== null);
          if (items.length > 0) {
            // Await expansion so the pending card and its completed replacement
            // commit in the same React render — no "remove then add" gap.
            const expanded = await Promise.all(
              items.map((item) => expandBatchItems(item, mediaApiRef.current)),
            );
            expandedNewItems = expanded.flat();
          }
        }
      }
      initialLoadDoneRef.current = true;
      prevCompletedIdsRef.current = completedIdSet;

      // Prune duration cache
      const activeIds = new Set(newInProgress.map((j) => j.job_token));
      for (const id of taskDurationCache.keys()) {
        if (!activeIds.has(id)) taskDurationCache.delete(id);
      }

      if (expandedNewItems.length > 0) {
        setNewlyCompleted((prev) => {
          const existingIds = new Set(prev.map((i) => i.id));
          const fresh = expandedNewItems.filter((i) => !existingIds.has(i.id));
          return [...fresh, ...prev];
        });
      }
      setInProgressJobs(newInProgress);
      setFailedJobsRaw(newFailed);
    } catch {
      // ignore
    }
  }, [mediaType]);

  // Poll every 5 seconds + listen for task-queue-update events.
  // Skip entirely when disabled (e.g. user is logged out) — otherwise we'd
  // hit an authenticated endpoint every 5s for nothing, which on mobile
  // Safari shows up as periodic main-thread jank during the menu animation.
  useEffect(() => {
    if (!enabled) return;
    load();
    const intervalId = setInterval(load, 5000);

    const handleTaskUpdate = () => load();
    window.addEventListener("task-queue-update", handleTaskUpdate);

    return () => {
      clearInterval(intervalId);
      window.removeEventListener("task-queue-update", handleTaskUpdate);
    };
  }, [load, enabled]);

  const dismissFailed = useCallback(async (jobToken: string) => {
    try {
      await apiRef.current.DeleteJobByToken(jobToken);
      setFailedJobsRaw((prev) => prev.filter((f) => f.job_token !== jobToken));
    } catch {
      // ignore
    }
  }, []);

  return {
    inProgress,
    failed,
    newlyCompleted,
    dismissFailed,
    refresh: load,
  };
}
