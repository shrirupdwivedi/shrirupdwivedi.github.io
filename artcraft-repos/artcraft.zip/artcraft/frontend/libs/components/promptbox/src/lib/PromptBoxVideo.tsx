import { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { useSignals } from "@preact/signals-react/runtime";
import { JobContextType } from "@storyteller/common";
import { PopoverMenu, PopoverItem } from "@storyteller/ui-popover";
import { SliderV2 } from "@storyteller/ui-sliderv2";
import { Tooltip } from "@storyteller/ui-tooltip";
import {
  ToggleButton,
  GenerateIconButton,
  NEUTRAL_BUTTON_HOVER_CLASSES,
} from "@storyteller/ui-button";
import { GenerateVideo, GenerateVideoRequest, commandErrorMessage } from "@storyteller/tauri-api";
import { AudioLinesIcon, ChevronDownIcon, ChevronUpIcon, ClockIcon, InfoIcon } from "lucide-react";
import { DynamicIcon } from "@storyteller/icons";
import { arrayMove } from "@dnd-kit/sortable";
import {
  resolveVideoDuration,
  resolveVideoGenerationCount,
  resolveVideoOutputFormat,
  videoGenerationCounts,
  videoDurationRange,
  videoResolutionValue,
  effectivePromptMaxLength,
  SizeIconOption,
  SizeOption,
  VideoModel,
} from "@storyteller/model-list";
import {
  usePromptVideoStore,
  RefImage,
  VideoInputMode,
  useCharactersStore,
  StoredCharacter,
  useEnterToGenerateStore,
} from "./promptStore";
import { gtagEvent } from "@storyteller/google-analytics";
import type { UploadImageFn } from "./ImagePromptRow";
import { ReferenceDeck } from "./deck/ReferenceDeck";
import { KeyframeCards } from "./deck/KeyframeCards";
import { useDeckMedia } from "./deck/useDeckMedia";
import {
  PromptBoxDropOverlay,
  usePromptBoxDrop,
  type DroppedFiles,
} from "./deck/usePromptBoxDrop";
import { DeckAddAction, DeckItem } from "./deck/deckTypes";
import { AspectRatioIcon } from "./common/AspectRatioIcon";
import { VideoGenerationCountPicker } from "./common/VideoGenerationCountPicker";
import { twMerge } from "tailwind-merge";
import { toast } from "@storyteller/ui-toaster";
import { GenerationProvider } from "@storyteller/api-enums";
import { CharactersModal } from "./CharactersModal";
import { CharactersApi } from "@storyteller/api";
import { MentionTextarea } from "./MentionTextarea";
import type { MentionItem } from "./MentionTextarea";
import {
  PromptFullscreenModal,
  useFullscreenPrompt,
} from "./PromptFullscreenModal";
import { PromptFullscreenButton } from "./PromptFullscreenButton";
import { PromptClearAllButton } from "./PromptClearAllButton";

declare global {
  interface Window {
    __storeTaskEnqueueMeta?: (meta: {
      prompt?: string;
      refImageUrls?: string[];
      modelType?: string;
      timestamp: number;
      batchCount?: number;
    }) => void;
  }
}

type GROK_ASPECT_RATIO = "landscape" | "portrait" | "square";

const EMPTY_CHARACTERS: StoredCharacter[] = [];

const DEFAULT_RESOLUTIONS: SizeOption[] = [
  {
    tauriValue: "720p",
    textLabel: "720p",
    icon: SizeIconOption.Landscape,
  },
  {
    tauriValue: "480p",
    textLabel: "480p",
    icon: SizeIconOption.Landscape,
  },
];

interface PromptBoxVideoProps {
  useJobContext: () => JobContextType;
  onEnqueuePressed?: (
    prompt: string,
    subscriberIds: string[],
  ) => void | Promise<void>;
  selectedModel?: VideoModel;
  selectedProvider?: GenerationProvider;
  imageMediaId?: string;
  url?: string;
  onImageRowVisibilityChange?: (visible: boolean) => void;
  uploadImage?: UploadImageFn;
  uploadVideo?: UploadImageFn;
  uploadAudio?: UploadImageFn;
  credits?: number | null;
  /** Optional model-picker slot rendered at the start of the toolbar
   *  (left of the aspect-ratio picker). */
  modelSelector?: React.ReactNode;
}

export const PromptBoxVideo = ({
  useJobContext,
  onEnqueuePressed,
  selectedModel,
  selectedProvider,
  imageMediaId,
  url,
  uploadImage,
  uploadVideo,
  uploadAudio,
  credits,
  modelSelector,
}: PromptBoxVideoProps) => {
  useSignals();

  // for the image media id and url, we need to set the reference image gallery panel.
  useEffect(() => {
    if (imageMediaId && url) {
      const referenceImage: RefImage = {
        id: Math.random().toString(36).substring(7),
        url: url,
        file: new File([], "library-image"),
        mediaToken: imageMediaId,
      };
      setReferenceImages([referenceImage]);
    }
  }, [imageMediaId, url]);

  const prompt = usePromptVideoStore((s) => s.prompt);
  const setPrompt = usePromptVideoStore((s) => s.setPrompt);
  const generateWithSound = usePromptVideoStore((s) => s.generateWithSound);
  const setGenerateWithSound = usePromptVideoStore(
    (s) => s.setGenerateWithSound,
  );
  const resolution = usePromptVideoStore((s) => s.resolution);
  const setResolution = usePromptVideoStore((s) => s.setResolution);
  const aspectRatio = usePromptVideoStore((s) => s.aspectRatio);
  const setAspectRatio = usePromptVideoStore((s) => s.setAspectRatio);
  const duration = usePromptVideoStore((s) => s.duration);
  const bitrate = usePromptVideoStore((s) => s.bitrate);
  const setBitrate = usePromptVideoStore((s) => s.setBitrate);
  const outputFormat = usePromptVideoStore((s) => s.outputFormat);
  const setOutputFormat = usePromptVideoStore((s) => s.setOutputFormat);
  const setDuration = usePromptVideoStore((s) => s.setDuration);
  const inputMode = usePromptVideoStore((s) => s.inputMode);
  const setInputMode = usePromptVideoStore((s) => s.setInputMode);
  const generationCount = usePromptVideoStore((s) => s.generationCount);
  const setGenerationCount = usePromptVideoStore((s) => s.setGenerationCount);
  const enterToGenerate = useEnterToGenerateStore((s) => s.enabled);
  const [isEnqueueing, setIsEnqueueing] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const { isFullscreen, openFullscreen, closeFullscreen } =
    useFullscreenPrompt();
  const [isCharactersModalOpen, setIsCharactersModalOpen] = useState(false);

  // Mentions are plain text: with several characters sharing a name,
  // "@Robot" alone can't identify one. Records which token the user actually
  // picked (dropdown, modal, or chip-menu replace), keyed by name.
  const [mentionSelections, setMentionSelections] = useState<
    Record<string, string>
  >({});

  // Characters store for @-mentions
  const storedCharacters = useCharactersStore((s) => s.characters);
  const charactersLoaded = useCharactersStore((s) => s.loaded);
  const storeSetCharacters = useCharactersStore((s) => s.setCharacters);
  const storeSetLoaded = useCharactersStore((s) => s.setLoaded);

  // Load characters on mount if not already loaded
  useEffect(() => {
    if (charactersLoaded) return;
    const api = new CharactersApi();
    api
      .ListAllCharacters()
      .then((res) => {
        if (res.success && res.data) {
          storeSetCharacters(
            res.data.map((c) => ({
              character_token: c.token,
              name: c.name,
              avatar_image_url: c.maybe_avatar?.cdn_url,
              full_image_url: c.maybe_full_image?.cdn_url,
            })),
          );
        }
      })
      .catch(() => {})
      .finally(() => storeSetLoaded(true));
  }, [charactersLoaded, storeSetCharacters, storeSetLoaded]);

  // Reserves room for the textarea's inline action-buttons row plus the fixed
  // Model / Costs / Help row at the bottom of the page.
  const BOTTOM_SAFE_AREA_PX = 160;

  // Viewport-relative expansion ceiling — mirrors PromptBoxImage's
  // `clamp(120px, calc(100vh - 700px), 500px)` so the editor can stretch the
  // same amount no matter where the (now bottom-fixed) prompt box sits on
  // screen. Using the element's live top position made the box shrink as it
  // moved down the page; this keeps a generous, position-independent ceiling.
  const EXPANDED_HEIGHT = "clamp(120px, calc(100vh - 700px), 500px)";

  const computeExpandedEditorHeight = (): number => {
    return Math.max(120, Math.min(window.innerHeight - 700, 500));
  };

  // Collapsed cap stays element-relative so a long unexpanded prompt never
  // pushes the box under the fixed bottom action row.
  const computeAvailableEditorHeight = (el: HTMLElement): number => {
    const topFromViewport = el.getBoundingClientRect().top;
    return Math.max(
      88,
      Math.floor(window.innerHeight - topFromViewport - BOTTOM_SAFE_AREA_PX),
    );
  };

  const toggleExpand = () => {
    setIsExpanded((prev) => {
      const next = !prev;
      const el = (mentionEditorRef.current ??
        textareaRef.current) as HTMLElement | null;
      if (el) {
        el.style.height = next ? EXPANDED_HEIGHT : "auto";
      }
      return next;
    });
  };

  const referenceImages = usePromptVideoStore((s) => s.referenceImages);
  const setReferenceImages = usePromptVideoStore((s) => s.setReferenceImages);
  const endFrameImage = usePromptVideoStore((s) => s.endFrameImage);
  const setEndFrameImage = usePromptVideoStore((s) => s.setEndFrameImage);
  const referenceVideos = usePromptVideoStore((s) => s.referenceVideos);
  const setReferenceVideos = usePromptVideoStore((s) => s.setReferenceVideos);
  const referenceAudios = usePromptVideoStore((s) => s.referenceAudios);
  const setReferenceAudios = usePromptVideoStore((s) => s.setReferenceAudios);

  // TODO: Get rid of default resolutions. Just disable it if not present.
  let aspectRatioOptions: PopoverItem[];

  const buildAspectRatioOptions = (options: SizeOption[]): PopoverItem[] => {
    const currentExists = options.some(
      (option) => option.textLabel === aspectRatio,
    );
    const useFirstOption = !currentExists;

    return options.map((option, index) => ({
      label: option.textLabel,
      selected:
        option.textLabel === aspectRatio || (useFirstOption && index === 0),
      icon: <AspectRatioIcon sizeIcon={option.icon} />,
    }));
  };

  if (!!selectedModel?.sizeOptions && selectedModel.sizeOptions.length > 0) {
    aspectRatioOptions = buildAspectRatioOptions(selectedModel.sizeOptions);
  } else {
    aspectRatioOptions = buildAspectRatioOptions(DEFAULT_RESOLUTIONS);
  }

  const [, setAspectRatioList] = useState<PopoverItem[]>(aspectRatioOptions);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const mentionEditorRef = useRef<HTMLDivElement>(null);

  // Held in a ref so the window.resize listener (installed once) always
  // invokes the latest closure — picks up current `isExpanded`, refs, etc.
  const applyHeightsRef = useRef<() => void>(() => {});
  applyHeightsRef.current = () => {
    const el = (mentionEditorRef.current ??
      textareaRef.current) as HTMLElement | null;
    if (!el) return;
    const maxH = isExpanded
      ? computeExpandedEditorHeight()
      : Math.min(computeAvailableEditorHeight(el), 500);
    el.style.maxHeight = `${maxH}px`;
    el.style.minHeight = "0";
    if (!isExpanded) {
      const capped = Math.min(el.scrollHeight, 88);
      el.style.minHeight = `${capped}px`;
    }
  };

  // Re-apply on viewport changes (window resize, windowed↔fullscreen,
  // monitor moves). Fires immediately + after the parent's react-spring
  // `top: vh/2` tween settles so getBoundingClientRect reads the final
  // position, not a mid-animation one.
  useEffect(() => {
    let settledId: number | undefined;
    const onResize = () => {
      applyHeightsRef.current();
      if (settledId !== undefined) window.clearTimeout(settledId);
      settledId = window.setTimeout(() => applyHeightsRef.current(), 100);
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (settledId !== undefined) window.clearTimeout(settledId);
    };
  }, []);

  // Apply height constraints to whichever editor element is active. Max
  // height is derived from the editor's actual position so long prompts
  // never push the box past the bottom action row — regardless of viewport
  // size (4K was previously capped at 500px while the viewport had room).
  useEffect(() => {
    const el = (mentionEditorRef.current ??
      textareaRef.current) as HTMLElement | null;
    if (el) {
      const maxH = isExpanded
        ? computeExpandedEditorHeight()
        : Math.min(computeAvailableEditorHeight(el), 500);
      el.style.maxHeight = `${maxH}px`;
      el.style.minHeight = "0";
      if (!isExpanded) {
        const capped = Math.min(el.scrollHeight, 88);
        el.style.minHeight = `${capped}px`;
      }
    }
  });

  useEffect(() => {
    if (imageMediaId && url) {
      const referenceImage: RefImage = {
        id: Math.random().toString(36).substring(7),
        url: url,
        file: new File([], "library-image"),
        mediaToken: imageMediaId,
      };
      setReferenceImages([referenceImage]);
    }
  }, [imageMediaId, url]);

  const handleAspectRatioSelect = (selectedItem: PopoverItem) => {
    setAspectRatio(selectedItem.label);
    setAspectRatioList((prev) =>
      aspectRatioOptions.map((item) => ({
        ...item,
        selected: item.label === selectedItem.label,
      })),
    );
  };

  // Follow the web app's range and sparse-option behavior, including the
  // lower duration cap some models apply in image-reference mode.
  useEffect(() => {
    const current = usePromptVideoStore.getState().duration;
    const next = selectedModel
      ? resolveVideoDuration(selectedModel, current, inputMode === "reference")
      : null;
    if (next !== current) setDuration(next);
  }, [selectedModel, inputMode, setDuration]);

  useEffect(() => {
    const current = usePromptVideoStore.getState().bitrate;
    const options = selectedModel?.bitrateOptions;
    if (!current || !options?.includes(current)) {
      setBitrate(selectedModel?.defaultBitrate ?? options?.[0] ?? null);
    }
  }, [selectedModel, setBitrate]);

  useEffect(() => {
    const current = usePromptVideoStore.getState().outputFormat;
    const options = selectedModel?.outputFormatOptions;
    if (!current || !options?.includes(current)) {
      setOutputFormat(selectedModel?.defaultOutputFormat ?? options?.[0] ?? null);
    }
  }, [selectedModel, setOutputFormat]);

  useEffect(() => {
    const current = usePromptVideoStore.getState().aspectRatio;
    if (selectedModel?.sizeOptions.some((option) => option.textLabel === current)) return;
    const option = selectedModel?.sizeOptions.find((option) => option.tauriValue === selectedModel.defaultAspectRatio)
      ?? selectedModel?.sizeOptions[0];
    if (option) setAspectRatio(option.textLabel);
  }, [selectedModel, setAspectRatio]);

  // Sync resolution with model default when switching models.
  // Read from store directly to avoid stale closure (same as duration above).
  useEffect(() => {
    const currentResolution = usePromptVideoStore.getState().resolution;
    if (selectedModel?.resolutionOptions && selectedModel.defaultResolution) {
      if (
        !selectedModel.resolutionOptions.includes(currentResolution as string)
      ) {
        setResolution(selectedModel.defaultResolution);
      }
    }
  }, [selectedModel]);

  // Reset input mode when switching to a model that doesn't support reference.
  // Read from store directly to avoid stale closure (same as duration above).
  useEffect(() => {
    const currentInputMode = usePromptVideoStore.getState().inputMode;
    if (
      !selectedModel?.supportsReferenceMode &&
      currentInputMode === "reference"
    ) {
      setInputMode("keyframe");
      setReferenceVideos([]);
      setReferenceAudios([]);
    }
  }, [selectedModel]);

  // Keep the selected count within the API's options when switching models.
  useEffect(() => {
    const current = usePromptVideoStore.getState().generationCount;
    const next = selectedModel ? resolveVideoGenerationCount(selectedModel, current) : 1;
    if (next !== current) setGenerationCount(next);
  }, [selectedModel, setGenerationCount]);

  const generationCounts = selectedModel ? videoGenerationCounts(selectedModel) : [1];
  const effectiveGenerationCount = selectedModel
    ? resolveVideoGenerationCount(selectedModel, generationCount) : 1;

  const durationRange = selectedModel
    ? videoDurationRange(selectedModel, inputMode === "reference")
    : null;
  const effectiveDuration = selectedModel
    ? resolveVideoDuration(selectedModel, duration, inputMode === "reference") ?? selectedModel.defaultDuration ?? 5
    : 5;
  const handleDurationSlide = (value: number) => {
    if (selectedModel) setDuration(resolveVideoDuration(selectedModel, value, inputMode === "reference"));
  };

  const resolutionPickerOptions: PopoverItem[] | null =
    selectedModel?.resolutionOptions
      ? selectedModel.resolutionOptions.map((r) => ({
          label: r,
          selected: r === resolution,
        }))
      : null;

  const handleResolutionSelect = (selectedItem: PopoverItem) => {
    setResolution(selectedItem.label);
  };

  const inputModeOptions: PopoverItem[] | null =
    selectedModel?.supportsReferenceMode
      ? [
          {
            label: "Keyframe",
            description: "First/Last frame",
            selected: inputMode === "keyframe",
          },
          {
            label: "Omni Reference",
            description: "Multi-media ref",
            selected: inputMode === "reference",
          },
        ]
      : null;

  const handleInputModeSelect = (selectedItem: PopoverItem) => {
    const mode: VideoInputMode =
      selectedItem.label === "Omni Reference" ? "reference" : "keyframe";
    setInputMode(mode);
    // Clear images/videos when switching modes to avoid stale state
    if (mode === "reference") {
      setEndFrameImage(undefined);
    } else {
      setReferenceVideos([]);
      setReferenceAudios([]);
    }
  };

  const isReferenceMode =
    inputMode === "reference" && !!selectedModel?.supportsReferenceMode;
  const maxImageCount = isReferenceMode
    ? (selectedModel?.maxReferenceImages ?? 3)
    : 1;

  const maxVideoCount = selectedModel?.maxReferenceVideos ?? 3;
  const maxAudioCount = selectedModel?.maxReferenceAudios ?? 2;

  const deck = useDeckMedia({
    referenceImages,
    setReferenceImages,
    maxImages: maxImageCount,
    endFrameImage,
    setEndFrameImage,
    referenceVideos,
    setReferenceVideos,
    maxVideos: maxVideoCount,
    maxVideoTotalSec: selectedModel?.maxVideoRefDuration ?? 15,
    referenceAudios,
    setReferenceAudios,
    maxAudios: maxAudioCount,
    maxAudioTotalSec: selectedModel?.maxAudioRefDuration ?? 15,
    uploadImage,
    uploadVideo,
    uploadAudio,
    ownGalleryModal: true,
  });

  // Drag & drop / paste onto the box bounds: files route to the reference
  // kind their MIME matches, gated on what the model supports. Keyframe mode
  // renders no video/audio deck, so those kinds only land in reference mode
  // where the user can see (and remove) them.
  const dropAcceptsVideos = isReferenceMode && maxVideoCount > 0;
  const dropAcceptsAudio = isReferenceMode && maxAudioCount > 0;

  const handleDroppedFiles = ({ images, videos, audios }: DroppedFiles) => {
    if (images.length > 0) {
      if (!isReferenceMode) {
        // Fill the empty keyframe slots in order: first frame, then last.
        const queue = [...images];
        const firstOpen =
          referenceImages.length === 0 && deck.uploadingImages.length === 0;
        const lastOpen =
          !!selectedModel?.endFrame && !endFrameImage && !deck.uploadingEnd;
        if (firstOpen) deck.processImageFiles([queue.shift()!], "start");
        if (lastOpen && queue.length > 0) {
          deck.processImageFiles([queue.shift()!], "end");
        }
        if (!firstOpen && !lastOpen) {
          toast.error(
            selectedModel?.endFrame
              ? "First and last frames are already set"
              : "The first frame is already set",
          );
        }
      } else if (deck.availableImageSlots <= 0) {
        toast.error(
          `Max ${maxImageCount} image reference${maxImageCount === 1 ? "" : "s"}`,
        );
      } else {
        deck.processImageFiles(images, "start");
      }
    }
    if (videos.length > 0) void deck.processVideoFiles(videos);
    if (audios.length > 0) void deck.processAudioFiles(audios);
  };

  const drop = usePromptBoxDrop({
    acceptsImages: maxImageCount > 0,
    acceptsVideos: dropAcceptsVideos,
    acceptsAudio: dropAcceptsAudio,
    onDropFiles: handleDroppedFiles,
  });

  // One overlay element serves both drop zones (inline box + focus mode).
  const dropOverlay = (
    <PromptBoxDropOverlay
      dragState={drop.dragState}
      acceptsImages={maxImageCount > 0}
      acceptsVideos={dropAcceptsVideos}
      acceptsAudio={dropAcceptsAudio}
      keyframeMode={!isReferenceMode}
    />
  );

  // Mixed deck items ordered images → videos → audios: the @ImageN/@VideoN/
  // @AudioN mention labels are index-derived per type, so this ordering (and
  // image-only reordering) is load-bearing.
  const deckItems: DeckItem[] = useMemo(
    () => [
      ...referenceImages.map((img, i) => ({
        id: img.id,
        kind: "image" as const,
        url: img.url,
        previewUrl: img.fullUrl ?? img.url,
        name: `Image ${i + 1}`,
      })),
      ...deck.uploadingImages.map((entry, i) => ({
        id: entry.id,
        kind: "image" as const,
        url: entry.previewUrl,
        name: `Image ${referenceImages.length + i + 1}`,
        uploading: true,
      })),
      ...referenceVideos.map((video, i) => ({
        id: video.id,
        kind: "video" as const,
        url: video.url,
        name: `Video ${i + 1}`,
        duration: video.duration,
      })),
      ...(deck.uploadingVideo
        ? [
            {
              id: deck.uploadingVideo.id,
              kind: "video" as const,
              url: deck.uploadingVideo.previewUrl,
              name: `Video ${referenceVideos.length + 1}`,
              uploading: true,
            },
          ]
        : []),
      ...referenceAudios.map((audio, i) => ({
        id: audio.id,
        kind: "audio" as const,
        url: audio.url,
        name: `Audio ${i + 1}`,
        duration: audio.duration,
      })),
      ...(deck.uploadingAudio
        ? [
            {
              id: deck.uploadingAudio.id,
              kind: "audio" as const,
              name: `Audio ${referenceAudios.length + 1}`,
              uploading: true,
            },
          ]
        : []),
    ],
    [
      referenceImages,
      referenceVideos,
      referenceAudios,
      deck.uploadingImages,
      deck.uploadingVideo,
      deck.uploadingAudio,
    ],
  );

  const refDeckAddActions: DeckAddAction[] = [];
  if (referenceImages.length + deck.uploadingImages.length < maxImageCount) {
    refDeckAddActions.push(
      {
        key: "upload-image",
        label: "Upload",
        group: "image",
        onSelect: deck.openImageUpload,
      },
      {
        key: "library-image",
        label: "From library",
        group: "image",
        onSelect: () => deck.openGallery("start"),
      },
    );
  }
  if (referenceVideos.length < maxVideoCount && !deck.uploadingVideo) {
    refDeckAddActions.push(
      {
        key: "upload-video",
        label: "Upload",
        group: "video",
        onSelect: deck.openVideoUpload,
      },
      {
        key: "library-video",
        label: "From library",
        group: "video",
        onSelect: () => deck.openGallery("video"),
      },
    );
  }
  if (referenceAudios.length < maxAudioCount && !deck.uploadingAudio) {
    refDeckAddActions.push(
      {
        key: "upload-audio",
        label: "Upload",
        group: "audio",
        onSelect: deck.openAudioUpload,
      },
      {
        key: "library-audio",
        label: "From library",
        group: "audio",
        onSelect: () => deck.openGallery("audio"),
      },
    );
  }

  const handleRemoveDeckItem = (id: string) => {
    if (referenceImages.some((img) => img.id === id)) {
      setReferenceImages(referenceImages.filter((img) => img.id !== id));
    } else if (referenceVideos.some((video) => video.id === id)) {
      setReferenceVideos(referenceVideos.filter((video) => video.id !== id));
    } else if (referenceAudios.some((audio) => audio.id === id)) {
      setReferenceAudios(referenceAudios.filter((audio) => audio.id !== id));
    }
  };

  const maxVideoTotalSec = selectedModel?.maxVideoRefDuration ?? 15;
  const maxAudioTotalSec = selectedModel?.maxAudioRefDuration ?? 15;
  const totalVideoRefSeconds = referenceVideos.reduce(
    (sum, video) => sum + video.duration,
    0,
  );
  const totalAudioRefSeconds = referenceAudios.reduce(
    (sum, audio) => sum + audio.duration,
    0,
  );

  const refDeckGroupHints = {
    image: `${referenceImages.length}/${maxImageCount}`,
    video: `${referenceVideos.length}/${maxVideoCount} · ${totalVideoRefSeconds}/${maxVideoTotalSec}s`,
    audio: `${referenceAudios.length}/${maxAudioCount} · ${totalAudioRefSeconds}/${maxAudioTotalSec}s`,
  };

  const renderReferenceDeck = (alwaysExpanded?: boolean) => (
    <ReferenceDeck
      items={deckItems}
      canAdd={refDeckAddActions.length > 0}
      addActions={refDeckAddActions}
      addMenuGroupHints={refDeckGroupHints}
      onAddClick={deck.openAnyUpload}
      onRemove={handleRemoveDeckItem}
      onReorderImages={(from, to) =>
        setReferenceImages(arrayMove(referenceImages, from, to))
      }
      onClearAll={() => {
        setReferenceImages([]);
        setReferenceVideos([]);
        setReferenceAudios([]);
      }}
      alwaysExpanded={alwaysExpanded}
    />
  );

  const firstFrameItem: DeckItem | undefined = referenceImages[0]
    ? {
        id: referenceImages[0].id,
        kind: "image",
        url: referenceImages[0].url,
        previewUrl: referenceImages[0].fullUrl ?? referenceImages[0].url,
        name: "First frame",
      }
    : deck.uploadingImages[0]
      ? {
          id: deck.uploadingImages[0].id,
          kind: "image",
          url: deck.uploadingImages[0].previewUrl,
          name: "First frame",
          uploading: true,
        }
      : undefined;

  const lastFrameItem: DeckItem | undefined = endFrameImage
    ? {
        id: endFrameImage.id,
        kind: "image",
        url: endFrameImage.url,
        previewUrl: endFrameImage.fullUrl ?? endFrameImage.url,
        name: "Last frame",
      }
    : deck.uploadingEnd
      ? {
          id: deck.uploadingEnd.id,
          kind: "image",
          url: deck.uploadingEnd.previewUrl,
          name: "Last frame",
          uploading: true,
        }
      : undefined;

  const handleSwapFrames = () => {
    const first = referenceImages[0];
    if (!first || !endFrameImage) return;
    setReferenceImages([endFrameImage]);
    setEndFrameImage(first);
  };

  const renderKeyframeCards = () => (
    <KeyframeCards
      firstFrame={firstFrameItem}
      lastFrame={lastFrameItem}
      showLastFrame={!!selectedModel?.endFrame}
      onFirstAddActions={[
        {
          key: "upload-first",
          label: "Upload",
          onSelect: deck.openImageUpload,
        },
        {
          key: "library-first",
          label: "Pick from library",
          onSelect: () => deck.openGallery("start"),
        },
      ]}
      onLastAddActions={[
        {
          key: "upload-last",
          label: "Upload",
          onSelect: deck.openEndUpload,
        },
        {
          key: "library-last",
          label: "Pick from library",
          onSelect: () => deck.openGallery("end"),
        },
      ]}
      onRemoveFirst={() => setReferenceImages([])}
      onRemoveLast={() => setEndFrameImage(undefined)}
      onSwap={handleSwapFrames}
    />
  );

  // Color palettes for @-mention highlights
  const IMAGE_COLORS = [
    "rgb(96, 165, 250)", // blue
    "rgb(251, 146, 60)", // orange
    "rgb(167, 139, 250)", // purple
    "rgb(52, 211, 153)", // green
    "rgb(251, 113, 133)", // pink
  ];
  const VIDEO_COLORS = [
    "rgb(250, 204, 21)", // yellow
    "rgb(245, 158, 11)", // amber
  ];
  const AUDIO_COLORS = [
    "rgb(192, 132, 252)", // violet
    "rgb(232, 121, 249)", // fuchsia
  ];
  const CHARACTER_COLORS = [
    "rgb(45, 212, 191)", // teal
    "rgb(34, 197, 94)", // emerald
    "rgb(14, 165, 233)", // sky
  ];

  const hasAnyRefs =
    referenceImages.length > 0 ||
    referenceVideos.length > 0 ||
    referenceAudios.length > 0;

  // Characters are only supported for seedance_2p0
  const isSeedance2p0 = selectedModel?.id === "seedance_2p0";
  const activeCharacters = isSeedance2p0 ? storedCharacters : EMPTY_CHARACTERS;

  // Build a set of character names for highlight matching
  const characterNames = useMemo(
    () => activeCharacters.map((c) => c.name),
    [activeCharacters],
  );

  const hasAnyMentionables = hasAnyRefs || activeCharacters.length > 0;

  // @-mention autocomplete state (for fallback textarea path)
  const [mentionOpen, setMentionOpen] = useState(false);
  const [mentionFilter, setMentionFilter] = useState("");
  const [mentionIndex, setMentionIndex] = useState(0);
  const mentionAnchorRef = useRef<number | null>(null);

  const mentionItems = [
    ...(isReferenceMode
      ? [
          ...referenceImages.map((img, i) => ({
            label: `@Image${i + 1}`,
            type: "image" as const,
            preview: img.url,
          })),
          ...referenceVideos.map((vid, i) => ({
            label: `@Video${i + 1}`,
            type: "video" as const,
            preview: vid.url,
          })),
          ...referenceAudios.map((_aud, i) => ({
            label: `@Audio${i + 1}`,
            type: "audio" as const,
            preview: undefined as string | undefined,
          })),
        ]
      : []),
    ...activeCharacters.map((char) => ({
      label: `@${char.name}`,
      type: "character" as const,
      preview: char.avatar_image_url,
    })),
  ].filter((item) =>
    mentionFilter
      ? item.label.toLowerCase().includes(mentionFilter.toLowerCase())
      : true,
  );

  // All mention items (unfiltered) for the contentEditable MentionTextarea
  const allMentionItems: MentionItem[] = useMemo(
    () => [
      ...(isReferenceMode
        ? [
            ...referenceImages.map((img, i) => ({
              label: `@Image${i + 1}`,
              type: "image" as const,
              preview: img.url,
            })),
            ...referenceVideos.map((vid, i) => ({
              label: `@Video${i + 1}`,
              type: "video" as const,
              preview: vid.url,
            })),
            ...referenceAudios.map((_aud, i) => ({
              label: `@Audio${i + 1}`,
              type: "audio" as const,
              preview: undefined as string | undefined,
            })),
          ]
        : []),
      ...activeCharacters.map((char) => ({
        label: `@${char.name}`,
        type: "character" as const,
        preview: char.avatar_image_url,
        token: char.character_token,
        fullPreview: char.full_image_url ?? char.avatar_image_url,
      })),
    ],
    [
      isReferenceMode,
      referenceImages,
      referenceVideos,
      referenceAudios,
      activeCharacters,
    ],
  );

  // Record which token a mention name refers to when the user picks a
  // character explicitly (dropdown pick or chip-menu replace).
  const handleMentionSelect = useCallback((item: MentionItem) => {
    if (item.type !== "character" || !item.token) return;
    const name = item.label.replace(/^@/, "");
    setMentionSelections((prev) => ({ ...prev, [name]: item.token! }));
  }, []);

  // Build label → color map for inline mention highlighting
  const mentionColorMap = useMemo(() => {
    const map: Record<string, string> = {};
    for (const item of allMentionItems) {
      const imgMatch = item.label.match(/^@Image(\d+)$/);
      if (imgMatch) {
        const idx = parseInt(imgMatch[1]) - 1;
        map[item.label] = IMAGE_COLORS[idx % IMAGE_COLORS.length];
        continue;
      }
      const vidMatch = item.label.match(/^@Video(\d+)$/);
      if (vidMatch) {
        const idx = parseInt(vidMatch[1]) - 1;
        map[item.label] = VIDEO_COLORS[idx % VIDEO_COLORS.length];
        continue;
      }
      const audMatch = item.label.match(/^@Audio(\d+)$/);
      if (audMatch) {
        const idx = parseInt(audMatch[1]) - 1;
        map[item.label] = AUDIO_COLORS[idx % AUDIO_COLORS.length];
        continue;
      }
      if (item.type === "character") {
        const charName = item.label.slice(1);
        const charIdx = characterNames.indexOf(charName);
        if (charIdx !== -1) {
          map[item.label] = CHARACTER_COLORS[charIdx % CHARACTER_COLORS.length];
        }
      }
    }
    return map;
  }, [allMentionItems, characterNames]);

  const insertMention = (label: string) => {
    const textarea = textareaRef.current;
    if (!textarea || mentionAnchorRef.current === null) return;
    const before = prompt.slice(0, mentionAnchorRef.current);
    const after = prompt.slice(textarea.selectionStart);
    const next = before + label + " " + after;
    setPrompt(next);
    setMentionOpen(false);
    setMentionFilter("");
    mentionAnchorRef.current = null;
    requestAnimationFrame(() => {
      const pos = before.length + label.length + 1;
      textarea.setSelectionRange(pos, pos);
      textarea.focus();
    });
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData("text");
    const target = e.currentTarget;
    const { selectionStart, selectionEnd, value } = target;
    const next =
      value.slice(0, selectionStart) + pastedText + value.slice(selectionEnd);
    setPrompt(next);
    requestAnimationFrame(() => {
      const pos = Math.min(selectionStart + pastedText.length, next.length);
      textareaRef.current?.setSelectionRange(pos, pos);
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    const cursorPos = e.target.selectionStart;
    setPrompt(value);

    // Trigger @-mention for reference files (in reference mode) or characters (always)
    if ((isReferenceMode && hasAnyRefs) || activeCharacters.length > 0) {
      const textBeforeCursor = value.slice(0, cursorPos);
      const lastAtIndex = textBeforeCursor.lastIndexOf("@");

      if (lastAtIndex !== -1) {
        const textAfterAt = textBeforeCursor.slice(lastAtIndex + 1);
        // Only trigger if no space after @ (still typing the mention)
        if (!textAfterAt.includes(" ")) {
          mentionAnchorRef.current = lastAtIndex;
          setMentionFilter("@" + textAfterAt);
          setMentionOpen(true);
          setMentionIndex(0);
          return;
        }
      }
    }

    setMentionOpen(false);
    setMentionFilter("");
    mentionAnchorRef.current = null;
  };

  const hasAttachedRefs =
    referenceImages.length > 0 ||
    !!endFrameImage ||
    referenceVideos.length > 0 ||
    referenceAudios.length > 0;
  const hasClearableContent = prompt.length > 0 || hasAttachedRefs;

  const handleClearAll = () => {
    setPrompt("");
    setReferenceImages([]);
    setEndFrameImage(undefined);
    setReferenceVideos([]);
    setReferenceAudios([]);
  };

  const maxLen =
    effectivePromptMaxLength(
      selectedModel?.tauriId ?? "",
      selectedModel?.maxPromptLength,
      prompt,
    ) ?? 1000;

  const handleEnqueue = async () => {
    if (!prompt.trim()) {
      console.warn("Cannot generate video: prompt is empty");
      toast.error("Please enter a prompt to generate video");
      return;
    }
    if (isFinite(maxLen) && prompt.length > maxLen) {
      toast.error(
        `Prompt exceeds the ${maxLen} character limit for this model`,
      );
      return;
    }

    if (!selectedModel) {
      console.warn("Cannot generate video: no model selected");
      toast.error("Please select a model to generate video");
      return;
    }

    if (selectedModel?.requiresImage && referenceImages.length === 0) {
      console.warn("Cannot generate video: no reference image provided");
      toast.error("Please add a starting frame image to generate video");
      return;
    }

    setIsEnqueueing(true);

    gtagEvent("enqueue_video");

    const count = effectiveGenerationCount;

    const isRefMode =
      inputMode === "reference" && !!selectedModel.supportsReferenceMode;

    let imageMediaToken = undefined;

    if (!isRefMode && referenceImages.length > 0) {
      imageMediaToken = referenceImages[0].mediaToken;
    }

    setTimeout(() => {
      // TODO(bt,2025-05-08): This is a hack so we don't accidentally wind up with a permanently disabled prompt box if
      // the backend hangs on a given request.
      console.debug("Turn off blocking of prompt box...");
      setIsEnqueueing(false);
    }, 10000);

    const buildRequest = (subscriberId: string): GenerateVideoRequest => {
      let request: GenerateVideoRequest = {
        model: selectedModel,
        start_frame_image_media_token: imageMediaToken,
        prompt: prompt,
        end_frame_image_media_token: isRefMode
          ? undefined
          : endFrameImage?.mediaToken,
        frontend_caller: "image_to_video",
        frontend_subscriber_id: subscriberId,
      };

      if (!!selectedProvider) {
        request.provider = selectedProvider;
      }

      if (selectedModel.generateWithSound) {
        request.generate_audio = !!generateWithSound;
      }

      // Pass reference image tokens in reference mode
      if (isRefMode && referenceImages.length > 0) {
        request.reference_image_media_tokens = referenceImages.map(
          (img) => img.mediaToken,
        );
      }

      // Pass reference video tokens in reference mode
      if (isRefMode && referenceVideos.length > 0) {
        request.reference_video_media_tokens = referenceVideos.map(
          (v) => v.mediaToken,
        );
      }

      // Pass reference audio tokens in reference mode
      if (isRefMode && referenceAudios.length > 0) {
        request.reference_audio_media_tokens = referenceAudios.map(
          (a) => a.mediaToken,
        );
      }

      // Extract character tokens from @-mentions in prompt, resolving to
      // exactly one token per mentioned name. Several characters can share a
      // name; prefer the user's explicit pick (mentionSelections), else the
      // newest (store is newest-first).
      // Use a word-boundary regex so `@Bob` doesn't match inside `@Bob2`.
      const mentionedTokens = (() => {
        if (activeCharacters.length === 0) return [];
        const byName = new Map<string, StoredCharacter[]>();
        for (const c of activeCharacters) {
          byName.set(c.name, [...(byName.get(c.name) ?? []), c]);
        }
        const names = [...byName.keys()].sort((a, b) => b.length - a.length);
        const tokens: string[] = [];
        for (const name of names) {
          const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          if (!new RegExp(`@${escaped}(?!\\w)`).test(prompt)) continue;
          const candidates = byName.get(name)!;
          const chosen =
            candidates.find(
              (c) => c.character_token === mentionSelections[name],
            ) ?? candidates[0];
          tokens.push(chosen.character_token);
        }
        return tokens;
      })();
      if (mentionedTokens.length > 0) {
        request.reference_character_tokens = mentionedTokens;
      }

      // Pass duration if model supports it
      if (durationRange || selectedModel.defaultDuration != null) {
        request.duration_seconds = effectiveDuration;
      }
      if (selectedModel.bitrateOptions?.length) {
        request.bitrate = bitrate ?? selectedModel.defaultBitrate ?? selectedModel.bitrateOptions[0];
      }
      if (selectedModel.outputFormatOptions?.length) {
        request.output_format = resolveVideoOutputFormat(selectedModel, outputFormat);
      }

      // Pass the chosen resolution when the model exposes a resolution picker.
      // Guarded on `resolutionOptions` so a stale store value (left over from a
      // model that did support resolution) isn't sent for one that doesn't.
      if (selectedModel.resolutionOptions?.length) {
        request.resolution = videoResolutionValue(resolution);
      }

      switch (selectedModel?.tauriId) {
        case "grok_video": // Legacy id
        case "grok_imagine_video":
          request.grok_aspect_ratio = getGrokAspectRatio();
          break;

        case "sora_2":
          request.sora_orientation =
            resolution === "720p" ? "landscape" : "portrait";
          break;
      }

      if (selectedModel.supportsCommonAspectRatio) {
        const selectedOption = selectedModel.sizeOptions?.find(
          (option) => option.textLabel === aspectRatio,
        );

        if (selectedOption) {
          request.aspect_ratio =
            selectedOption.tauriValue as typeof request.aspect_ratio;
        } else {
          const maybeDefault = selectedModel.sizeOptions.find((option) => option.tauriValue === selectedModel.defaultAspectRatio)
            ?? selectedModel.sizeOptions[0];
          if (!!maybeDefault) {
            request.aspect_ratio =
              maybeDefault.tauriValue as typeof request.aspect_ratio;
          }
        }
      }

      return request;
    };

    window.__storeTaskEnqueueMeta?.({
      prompt,
      refImageUrls: referenceImages?.map((img) => img.url).filter(Boolean),
      modelType: (selectedModel as any)?.tauriId || String(selectedModel),
      timestamp: Date.now(),
    });

    const subscriberIds: string[] = [];
    const enqueuePromises: Promise<unknown>[] = [];

    for (let i = 0; i < count; i++) {
      const subscriberId = crypto.randomUUID
        ? crypto.randomUUID()
        : Math.random().toString(36).slice(2);
      subscriberIds.push(subscriberId);
      enqueuePromises.push(GenerateVideo(buildRequest(subscriberId)));
    }

    const outcomes = await Promise.allSettled(enqueuePromises);
    const acceptedIds = subscriberIds.filter((_, index) => outcomes[index].status === "fulfilled");
    const failure = outcomes.find((outcome) => outcome.status === "rejected");
    if (failure?.status === "rejected") {
      console.error("PromptBoxVideo - enqueue failed", failure.reason);
      toast.error(commandErrorMessage(failure.reason, "Failed to start video generation. Please try again."));
    }
    if (acceptedIds.length) onEnqueuePressed?.(prompt, acceptedIds);

    setIsEnqueueing(false);
  };

  const getCurrentAspectRatioIcon = (): SizeIconOption => {
    const allOptions = selectedModel?.sizeOptions ?? DEFAULT_RESOLUTIONS;
    const match = allOptions.find((o) => o.textLabel === aspectRatio);
    return match?.icon ?? SizeIconOption.Landscape;
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Handle mention dropdown navigation
    if (mentionOpen && mentionItems.length > 0) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setMentionIndex((prev) => (prev + 1) % mentionItems.length);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setMentionIndex((prev) =>
          prev <= 0 ? mentionItems.length - 1 : prev - 1,
        );
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        insertMention(mentionItems[mentionIndex].label);
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setMentionOpen(false);
        return;
      }
    }

    if (e.key !== "Enter") return;
    const isSubmitCombo = enterToGenerate && !e.shiftKey;
    if (isSubmitCombo) {
      e.preventDefault();

      if (selectedModel?.requiresImage && referenceImages.length === 0) {
        return;
      }

      if (!prompt.trim()) {
        return;
      }

      handleEnqueue();
    }
  };

  const getGrokAspectRatio = (): GROK_ASPECT_RATIO => {
    // NB: This function was just written to give us better type safety.
    // There has to be a cleaner appraoach.
    const maybeAspectRatio = selectedModel?.sizeOptions?.find(
      (option) => option.textLabel === aspectRatio,
    )?.tauriValue;

    switch (maybeAspectRatio) {
      case "landscape":
        return "landscape";
      case "portrait":
        return "portrait";
      case "square":
        return "square";
      default:
        return "landscape";
    }
  };

  const modelNeedsAnImageButNoneAreSelected =
    selectedModel?.requiresImage && referenceImages.length === 0;

  // Hide/clear ending frame if model doesn't support it
  useEffect(() => {
    if (selectedModel && !selectedModel.endFrame && endFrameImage) {
      setEndFrameImage(undefined);
    }
  }, [selectedModel, endFrameImage, setEndFrameImage]);

  // Character button (seedance_2p0 only), reused in the fullscreen footer.
  const characterButtonEl =
    selectedModel?.id === "seedance_2p0" ? (
      <button
        type="button"
        onClick={() => setIsCharactersModalOpen(true)}
        className={`flex h-[34px] items-center justify-center gap-2 rounded-[3px] border border-ui-controls-border bg-ui-controls px-3 text-sm font-medium text-base-fg transition-colors duration-150 ${NEUTRAL_BUTTON_HOVER_CLASSES}`}
      >
        @Characters
      </button>
    ) : null;

  // Input-mode (keyframe/reference) picker, reused in the fullscreen footer.
  const inputModeEl = inputModeOptions ? (
    <Tooltip content="Input Mode" position="top" className="z-50" closeOnClick>
      <PopoverMenu
        items={inputModeOptions}
        onSelect={handleInputModeSelect}
        mode="toggle"
        panelTitle="Input Mode"
      />
    </Tooltip>
  ) : null;

  return (
    <>
      {deck.fileInputs}
      {deck.galleryModal}
      <div className="relative z-20 flex flex-col gap-3">
        <div
          className={twMerge(
            "glass relative w-full p-4 !transition-all duration-200",
            isFocused && "border-primary",
          )}
          {...drop.dropZoneProps}
        >
          {dropOverlay}
          {selectedModel?.textToVideoSupported === false && (
            <div className="mb-2 flex items-center gap-1.5 bg-ui-controls/60 px-2.5 py-1.5 text-xs text-base-fg/70">
              <InfoIcon
                
                className="h-3 w-3 shrink-0" />
              <span>
                This model can&apos;t generate from text alone - add a starting
                frame to animate your prompt.
              </span>
            </div>
          )}
          <div className="relative flex gap-3">
            {isReferenceMode ? renderReferenceDeck() : renderKeyframeCards()}
            <div className="promptbox-resize-wrap relative flex-1 min-w-0">
              {hasAnyMentionables ? (
                <MentionTextarea
                  ref={mentionEditorRef}
                  value={prompt}
                  onChange={setPrompt}
                  mentionItems={allMentionItems}
                  colorMap={mentionColorMap}
                  onMentionSelect={handleMentionSelect}
                  selectedTokens={mentionSelections}
                  placeholder={
                    isReferenceMode
                      ? "Use @Image1, @Video1, @Audio1... to reference uploads in prompt..."
                      : "Describe what you want to happen in the video..."
                  }
                  className="promptbox-scrollbar text-md relative min-h-[2.5em] w-full resize-y overflow-y-auto bg-transparent pr-8 text-base-fg"
                  onKeyDown={(e) => {
                    if (e.key !== "Enter") return;
                    const isSubmitCombo = enterToGenerate && !e.shiftKey;
                    if (isSubmitCombo) {
                      e.preventDefault();
                      if (
                        selectedModel?.requiresImage &&
                        referenceImages.length === 0
                      )
                        return;
                      if (!prompt.trim()) return;
                      handleEnqueue();
                    }
                  }}
                  onFocus={() => setIsFocused(true)}
                  onBlur={() => setIsFocused(false)}
                />
              ) : (
                <textarea
                  ref={textareaRef}
                  rows={1}
                  placeholder="Describe what you want to happen in the video..."
                  className="promptbox-scrollbar text-md relative min-h-[2.5em] w-full resize-y overflow-y-auto bg-transparent pr-8 text-base-fg placeholder-base-fg/60 focus:outline-none"
                  value={prompt}
                  onChange={handleChange}
                  onPaste={handlePaste}
                  onKeyDown={handleKeyDown}
                  onFocus={() => setIsFocused(true)}
                  onBlur={() => setIsFocused(false)}
                />
              )}
              <PromptFullscreenButton onClick={openFullscreen} />
              <span
                className={`pointer-events-none absolute -bottom-1 right-4 text-[10px] tabular-nums ${isFinite(maxLen) && prompt.length > maxLen ? "text-red-500" : "text-base-fg/40"}`}
              >
                {prompt.length} / {isFinite(maxLen) ? maxLen : "∞"}
              </span>
            </div>
          </div>
          <div className="mt-3.5 flex items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              {modelSelector}
              <Tooltip
                content="Aspect Ratio"
                position="top"
                className="z-50"
                closeOnClick={true}
              >
                <PopoverMenu
                  items={aspectRatioOptions}
                  onSelect={handleAspectRatioSelect}
                  mode="toggle"
                  panelTitle="Aspect Ratio"
                  showIconsInList
                  triggerIcon={
                    <AspectRatioIcon sizeIcon={getCurrentAspectRatioIcon()} />
                  }
                />
              </Tooltip>

              {resolutionPickerOptions && (
                <Tooltip
                  content="Resolution"
                  position="top"
                  className="z-50"
                  closeOnClick={true}
                >
                  <PopoverMenu
                    items={resolutionPickerOptions}
                    onSelect={handleResolutionSelect}
                    mode="toggle"
                    panelTitle="Resolution"
                  />
                </Tooltip>
              )}

              {!!selectedModel?.bitrateOptions?.length && (
                <Tooltip content="Bitrate" position="top" className="z-50">
                  <PopoverMenu
                    panelTitle="Bitrate"
                    mode="toggle"
                    items={selectedModel.bitrateOptions.map((value) => ({
                      label: value === "normal" ? "Normal" : value === "high" ? "High" : value,
                      action: value,
                      selected: value === bitrate,
                    }))}
                    onSelect={(item) => setBitrate(item.action ?? item.label)}
                  />
                </Tooltip>
              )}

              {!!selectedModel?.outputFormatOptions?.length && (
                <Tooltip content="Output format" position="top" className="z-50">
                  <PopoverMenu
                    panelTitle="Output format"
                    mode="toggle"
                    items={selectedModel.outputFormatOptions.map((value) => ({
                      label: value.toUpperCase(),
                      action: value,
                      selected: value === outputFormat,
                    }))}
                    onSelect={(item) => setOutputFormat(item.action ?? item.label)}
                  />
                </Tooltip>
              )}

              {durationRange && durationRange.max > durationRange.min && (
                <Tooltip content="Duration" position="top" className="z-50">
                  <PopoverMenu
                    mode="default"
                    panelTitle="Duration"
                    triggerIcon={
                      <ClockIcon  className="h-3.5 w-3.5" />
                    }
                    triggerLabel={`${effectiveDuration}s`}
                  >
                    <div className="w-[min(16rem,calc(100vw-2rem))] pb-0.5">
                      <div className="flex items-center gap-2.5">
                        <div className="flex-1">
                          <SliderV2
                            min={durationRange.min}
                            max={durationRange.max}
                            value={effectiveDuration}
                            onChange={handleDurationSlide}
                            step={1}
                            suffix="s"
                            variant="filled"
                          />
                        </div>
                        <span className="min-w-6 shrink-0 text-sm font-medium tabular-nums text-base-fg">
                          {effectiveDuration}s
                        </span>
                      </div>
                      <div className="mt-1.5 flex justify-between px-0.5 text-[11px] tabular-nums text-base-fg/40">
                        <span>{durationRange.min}s</span>
                        <span>{durationRange.max}s</span>
                      </div>
                    </div>
                  </PopoverMenu>
                </Tooltip>
              )}

              {selectedModel?.generateWithSound && (
                <Tooltip
                  content={generateWithSound ? "Sound: ON" : "Sound: OFF"}
                  position="top"
                  className="z-50"
                  delay={200}
                >
                  <ToggleButton
                    isActive={generateWithSound}
                    icon={AudioLinesIcon}
                    activeIcon={AudioLinesIcon}
                    onClick={() => setGenerateWithSound(!generateWithSound)}
                  />
                </Tooltip>
              )}

              {inputModeEl}

              {characterButtonEl}
            </div>
            <div className="flex items-center gap-1.5">
              {modelNeedsAnImageButNoneAreSelected && (
                <span className="flex items-center gap-1.5 text-xs text-red-500 font-medium animate-pulse">
                  <InfoIcon />
                  Starting frame required
                </span>
              )}
              {generationCounts.length > 1 && (
                <VideoGenerationCountPicker
                  counts={generationCounts}
                  currentCount={effectiveGenerationCount}
                  handleCountChange={setGenerationCount}
                />
              )}
              <PromptClearAllButton
                onClick={handleClearAll}
                disabled={!hasClearableContent}
                confirmClear={hasAttachedRefs}
              />
              <Tooltip
                content="Add a starting image before generating"
                position="top"
                className="z-50"
                delay={0}
                disabled={!modelNeedsAnImageButNoneAreSelected}
              >
                <div>
                  <GenerateIconButton
                    onClick={handleEnqueue}
                    disabled={!prompt.trim()}
                    loading={isEnqueueing}
                    credits={credits}
                  />
                </div>
              </Tooltip>
            </div>
          </div>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2">
            <Tooltip
              content={isExpanded ? "Collapse" : "Expand"}
              position="top"
              className="-mb-2"
            >
              <button
                type="button"
                onClick={toggleExpand}
                className="text-base-fg/30 hover:text-base-fg/90 transition-colors px-3 py-0.5"
              >
                <DynamicIcon
                  icon={isExpanded ? ChevronUpIcon : ChevronDownIcon}
                  className="text-xs"
                />
              </button>
            </Tooltip>
          </div>
        </div>
        {/* {selectedModel?.id === "seedance_2p0" && (
          <div className="flex items-start gap-2.5 rounded-lg border border-yellow-500/40 bg-yellow-500/10 px-3.5 py-2.5 text-xs text-yellow-200">
            <TriangleAlertIcon className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-yellow-400" />
            <span>
              Seedance 2.0 is in Early Alpha. Generations may be slow, and may
              experience outages. Seedance may reject safe inputs unexpectedly.
              Try several short generations before longer ones.
            </span>
          </div>
        )} */}
      </div>
      <CharactersModal
        isOpen={isCharactersModalOpen}
        onClose={() => setIsCharactersModalOpen(false)}
        onSelectCharacter={(character) => {
          const mention = `@${character.name}`;
          const spaceBefore =
            prompt.length > 0 && !prompt.endsWith(" ") ? " " : "";
          setPrompt(prompt + spaceBefore + mention + " ");
          setMentionSelections((prev) => ({
            ...prev,
            [character.name]: character.token,
          }));
          setIsCharactersModalOpen(false);
          requestAnimationFrame(() => {
            const el = mentionEditorRef.current;
            if (el) {
              el.focus();
              const sel = window.getSelection();
              if (sel) {
                sel.selectAllChildren(el);
                sel.collapseToEnd();
              }
            }
          });
        }}
      />
      <PromptFullscreenModal
        isOpen={isFullscreen}
        onClose={closeFullscreen}
        promptLength={prompt.length}
        maxLength={maxLen}
        dropZoneProps={drop.fullscreenDropZoneProps}
        dropOverlay={dropOverlay}
        clearAllButton={
          <PromptClearAllButton
            onClick={handleClearAll}
            disabled={!hasClearableContent}
            confirmClear={hasAttachedRefs}
          />
        }
        footerControls={
          <>
            {modelSelector}
            {inputModeEl}
            {characterButtonEl}
          </>
        }
        imagePromptRow={
          isReferenceMode ? renderReferenceDeck(true) : renderKeyframeCards()
        }
      >
        {hasAnyMentionables ? (
          <MentionTextarea
            value={prompt}
            onChange={setPrompt}
            mentionItems={allMentionItems}
            colorMap={mentionColorMap}
            onMentionSelect={handleMentionSelect}
            selectedTokens={mentionSelections}
            placeholder={
              isReferenceMode
                ? "Use @Image1, @Video1, @Audio1... to reference uploads in prompt..."
                : "Describe what you want to happen in the video..."
            }
            className="promptbox-scrollbar text-md h-full min-h-0 w-full resize-none overflow-y-auto rounded-[3px] bg-transparent text-base-fg"
            style={{ resize: "none" }}
          />
        ) : (
          <textarea
            placeholder="Describe what you want to happen in the video..."
            className="promptbox-scrollbar text-md h-full min-h-0 w-full resize-none overflow-y-auto rounded-[3px] bg-transparent text-base-fg placeholder-base-fg/60 focus:outline-none"
            value={prompt}
            onChange={handleChange}
            onPaste={handlePaste}
            onKeyDown={handleKeyDown}
          />
        )}
      </PromptFullscreenModal>
    </>
  );
};
