import {
  PopoverMenu,
  type PopoverItem,
  groupModelItems,
  useModelPickerStyleStore,
} from "@storyteller/ui-popover";
import {
  useClassyModelSelectorStore,
  useSelectedProviderForModel,
} from "./classy-model-selector-store";
import { useEffect, useMemo } from "react";
import { ModelPage } from "./model-pages";
import { Provider } from "@storyteller/tauri-api";
import { getProviderDisplayName, getProviderIcon } from "./provider-icons";
import {
  Model,
  getCreatorIcon,
  getModelFamilyName,
} from "@storyteller/model-list";
import { ChevronUpIcon, CheckIcon } from "lucide-react";
import { GenerationProvider } from "@storyteller/api-enums";
import { Tooltip } from "@storyteller/ui-tooltip";
import { defaultModelForPage } from "./defaultModelForPage";

interface ClassyModelSelectorProps {
  items: Omit<PopoverItem, "selected">[];
  page: ModelPage;
  mode?: "hoverSelect" | "default" | "toggle" | "button";
  panelTitle?: string;
  buttonClassName?: string;
  panelClassName?: string;
  showIconsInList?: boolean;
  triggerLabel?: string;
  providersByModel?: Partial<Record<string, Provider[]>>;
  providerTooltipDelayMs?: number;
  maxListHeight?: number | string;
  /**
   * "floating": the original standalone selector (large two-line trigger with
   * model name + provider, hover-to-open list). "embedded": a compact pill
   * (creator icon + model name) for use inside a promptbox option row; opens
   * a webapp-style rich list on click. Both share the same store wiring and
   * provider-selection rows.
   */
  variant?: "floating" | "embedded";
  /**
   * Whether models that support multiple providers expose the provider-picker
   * submenu (hover panel) and the per-row provider icon chips. Defaults to
   * true. Pages locked to a single provider (e.g. PageDraw) pass false to show
   * only the model name — the default provider is still resolved into the
   * store so downstream generation calls keep working.
   */
  showProviderSelection?: boolean;
}

// Model instances are rebuilt when the backend listing hydrates, so compare by
// tauriId rather than object identity.
const isSameModel = (a: Model | undefined, b: Model | undefined): boolean =>
  a !== undefined && b !== undefined && a.tauriId === b.tauriId;

const DEFAULT_PROVIDER_OPTIONS: GenerationProvider[] = [
  GenerationProvider.Artcraft,
];

function ProviderTooltipContent({
  page,
  modelId,
  model,
  modelLabel,
  allowedProviders,
  onFinished,
}: {
  page: ModelPage;
  modelId?: string;
  model?: Model;
  modelLabel?: string;
  allowedProviders: GenerationProvider[];
  onFinished?: () => void;
}) {
  const { setSelectedModel, setSelectedProvider } =
    useClassyModelSelectorStore();
  const selectedProvider = useSelectedProviderForModel(page, modelId);

  // Reset selections that are no longer offered for this model.
  useEffect(() => {
    if (!modelId) return;
    if ((!selectedProvider || !allowedProviders.includes(selectedProvider)) && allowedProviders.length > 0) {
      setSelectedProvider(page, modelId, allowedProviders[0]);
    }
  }, [page, modelId, selectedProvider, allowedProviders, setSelectedProvider]);

  if (!modelId) return null as any;

  return (
    <div className="flex flex-col gap-1">
      <div className="mb-1 mt-0.5 px-1.5 text-sm font-normal text-base-fg opacity-70">
        Select Provider
      </div>
      <div className="flex flex-col gap-0">
        {allowedProviders.map((p) => (
          <button
            key={p}
            onClick={() => {
              if (model) {
                setSelectedModel(page, model);
              }
              setSelectedProvider(page, modelId, p);
              onFinished?.();
            }}
            type="button"
            className={`group flex cursor-pointer items-center justify-between rounded-[3px] px-2 py-2 transition-all ${
              selectedProvider === p
                ? "bg-ui-controls/70 border-l-4 border-primary"
                : "hover:bg-ui-controls/50"
            }`}
          >
            <span className="flex items-center gap-2 text-sm text-base-fg">
              <span className="text-lg">{getProviderIcon(p)}</span>
              {getProviderDisplayName(p)}
            </span>
            {selectedProvider === p && (
              <span className="ml-2 flex h-5 w-5 shrink-0 items-center justify-center text-white">
                <CheckIcon aria-hidden="true" className="h-4 w-4" strokeWidth={2.5} />
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

export function ClassyModelSelector({
  items,
  page,
  providersByModel,
  providerTooltipDelayMs = 300,
  maxListHeight = "60vh",
  variant = "floating",
  showProviderSelection = true,
  ...popoverProps
}: ClassyModelSelectorProps) {
  const { selectedModels, setSelectedModel, setSelectedProvider } =
    useClassyModelSelectorStore();
  const itemModels: Model[] = items
    .map((item) => item.model)
    .filter((model) => model !== undefined);
  const selectedModel =
    selectedModels[page] || defaultModelForPage(itemModels, page);
  const selectedProvider = useSelectedProviderForModel(page, selectedModel?.id);
  const selectedProvidersByModel = useClassyModelSelectorStore(
    (s) => s.selectedProviders[page] ?? {},
  );

  // For the first mount, make sure the selected model is set for other components to listen
  useEffect(() => {
    // Initialize selected model if not set
    if (!selectedModels[page] && items[0]) {
      setSelectedModel(page, defaultModelForPage(itemModels, page));
    }
  }, []);

  // The backend listing hydrates asynchronously and rebuilds the model
  // instances with API capabilities. Swap a stale selected instance for the
  // fresh one so capability-driven UI (keyframes, references, pickers)
  // reflects the API data without needing a manual re-select.
  useEffect(() => {
    const selected = selectedModels[page];
    if (!selected) return;
    const fresh = itemModels.find((m) => m.tauriId === selected.tauriId);
    if (fresh !== undefined && fresh !== selected) {
      setSelectedModel(page, fresh);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, selectedModels, page]);

  // Initialize defaults and replace providers removed from the catalog.
  useEffect(() => {
    for (const item of items) {
      const modelId = item.model?.id;
      if (!modelId) continue;
      const allowed = item.model?.getProviders() || DEFAULT_PROVIDER_OPTIONS;
      if (allowed.includes(selectedProvidersByModel[modelId])) continue;
      if (allowed.length > 0) {
        setSelectedProvider(page, modelId, allowed[0]);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, providersByModel, page, selectedProvidersByModel]);

  const handleModelSelect = (item: PopoverItem) => {
    console.log(`Model selector changed on page "${page}": `, item.model);
    setSelectedModel(page, item.model!);
  };

  const modelList = useMemo(
    () =>
      items.map((item) => {
        const modelId = item.model?.id;
        const allowedProviders =
          item.model?.getProviders() || DEFAULT_PROVIDER_OPTIONS;

        // When provider selection is hidden, treat every model as
        // single-provider so the submenu and provider chips never render.
        const hasMultipleProviders =
          showProviderSelection && allowedProviders.length >= 2;

        return {
          ...item,
          selected: isSameModel(item.model as Model | undefined, selectedModel),
          hoverTooltip: hasMultipleProviders
            ? (close: () => void) => (
                <ProviderTooltipContent
                  page={page}
                  modelId={modelId}
                  model={item.model as Model | undefined}
                  modelLabel={item.label}
                  allowedProviders={allowedProviders}
                  onFinished={close}
                />
              )
            : undefined,
          tooltipDelayMs: providerTooltipDelayMs,
          trailing:
            !isSameModel(item.model as Model | undefined, selectedModel) &&
            hasMultipleProviders
              ? (() => {
                  const prov = modelId
                    ? selectedProvidersByModel[modelId]
                    : undefined;
                  const iconProvider = prov ?? allowedProviders[0];
                  return iconProvider ? (
                    <div className="mr-1 p-1.5 bg-ui-controls/60 group-hover:bg-ui-controls/80 transition-colors">
                      <span className="text-base-fg/70 group-hover:text-base-fg/90 text-lg">
                        {getProviderIcon(iconProvider)}
                      </span>
                    </div>
                  ) : undefined;
                })()
              : undefined,
          selectedRight:
            isSameModel(item.model as Model | undefined, selectedModel) &&
            selectedProvider &&
            hasMultipleProviders ? (
              <div className="mr-1 p-1.5 bg-primary/60 group-hover:bg-primary/80 transition-colors">
                <span className="text-base-fg/70 group-hover:text-base-fg/90 text-lg">
                  {getProviderIcon(selectedProvider)}
                </span>
              </div>
            ) : undefined,
        } as PopoverItem;
      }),
    [
      items,
      selectedModel,
      selectedProvider,
      selectedProvidersByModel,
      page,
      providersByModel,
      providerTooltipDelayMs,
      showProviderSelection,
    ],
  );

  // Fold the (decorated) flat list into family submenus when the user prefers
  // the grouped picker. Only the embedded richList variant renders groups; the
  // floating hoverSelect list stays flat.
  const pickerStyle = useModelPickerStyleStore((s) => s.style);
  const embeddedList = useMemo(
    () =>
      pickerStyle === "grouped"
        ? groupModelItems(modelList, (i) =>
            getModelFamilyName(i.model?.id, i.model?.creator),
          )
        : modelList,
    [modelList, pickerStyle],
  );

  if (variant === "embedded") {
    // The trigger pill keeps the mono icon; the color variants are only for
    // list rows.
    const selectedIcon = selectedModel
      ? getCreatorIcon(selectedModel.creator)
      : modelList.find((i) => i.selected)?.icon;
    return (
      <Tooltip content="Model" position="top" className="z-50" closeOnClick>
        <PopoverMenu
          items={embeddedList}
          onSelect={handleModelSelect}
          mode="toggle"
          richList
          panelTitle="Select Model"
          panelClassName="w-[280px]"
          maxListHeight={maxListHeight}
          buttonClassName="max-w-48"
          triggerIcon={
            selectedIcon ? (
              <span className="flex h-4 w-4 shrink-0 items-center justify-center">
                {selectedIcon}
              </span>
            ) : undefined
          }
        />
      </Tooltip>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <span className="text-base-fg/90 text-base font-semibold">Model</span>
      <PopoverMenu
        items={modelList}
        onSelect={handleModelSelect}
        mode="hoverSelect"
        maxListHeight={maxListHeight}
        {...popoverProps}
        buttonClassName="rounded-[3px] bg-ui-controls text-left shadow-sm px-3 py-1 gap-3 border border-ui-controls-border"
        renderTrigger={(selectedItem) => {
          const modelTitle =
            selectedItem?.label ?? selectedModel?.selectorName ?? "";
          const providerIcon = selectedProvider
            ? getProviderIcon(selectedProvider)
            : null;
          return (
            <div className="flex items-center justify-between w-full gap-3">
              <div className="flex min-w-0 flex-col">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="truncate text-base font-semibold text-base-fg">
                    {modelTitle}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-base-fg/60 text-[13px] -mt-[1px]">
                  <span>via</span>
                  {providerIcon && (
                    <span className="opacity-70">{providerIcon}</span>
                  )}
                  <span className="truncate">
                    {selectedProvider
                      ? getProviderDisplayName(selectedProvider)
                      : ""}
                  </span>
                </div>
              </div>
              <ChevronUpIcon className="text-base text-base-fg/70 self-center" />
            </div>
          );
        }}
      />
    </div>
  );
}

export default ClassyModelSelector;
