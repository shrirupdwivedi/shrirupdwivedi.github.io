import { ButtonHTMLAttributes, Fragment, useState } from "react";
import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { DynamicIcon } from "@storyteller/icons";
import { Modal } from "@storyteller/ui-modal";
import { Button, ButtonProps } from "@storyteller/ui-button";
import { twMerge } from "tailwind-merge";

type UnionedButtonProps = { label?: string } & ButtonProps;

interface ButtonDropdownProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  icon?: LucideIcon;
  align?: "left" | "right";
  showSelected?: boolean;
  options: Array<{
    label: string;
    className?: string;
    icon?: LucideIcon;
    selected?: boolean;
    description?: string;
    onClick?: () => void;
    disabled?: boolean;
    divider?: boolean;
    onDialogOpen?: () => void;
    dialogProps?: {
      title: string;
      content: React.ReactNode;
      className?: string;
      confirmButtonProps?: UnionedButtonProps;
      closeButtonProps?: UnionedButtonProps;
      showClose?: boolean;
      onClose?: () => void;
    };
  }>;
}

export const ButtonDropdown = ({
  className,
  label,
  options,
  icon,
  align = "left",
  showSelected,
}: ButtonDropdownProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(
    null,
  );

  const closeModal = () => {
    setIsOpen(false);
    if (selectedOptionIndex !== null) {
      options[selectedOptionIndex]?.dialogProps?.onClose?.();
    }
  };

  const handleOptionClick = (index: number) => {
    const option = options[index];
    if (option.onClick) {
      option.onClick();
    }
    if (option.onDialogOpen) {
      option.onDialogOpen();
    }
    if (option.dialogProps) {
      setSelectedOptionIndex(index);
      setIsOpen(true);
    }
  };

  const currentDialogProps =
    selectedOptionIndex !== null
      ? options[selectedOptionIndex]?.dialogProps
      : null;

  return (
    <div className="relative">
      <Menu as="div" className="inline-block text-left">
        <Menu.Button as="div">
          <Button
            className={className}
            icon={ChevronDownIcon}
            iconFlip={true}
            variant="secondary"
          >
            {icon ? <DynamicIcon icon={icon} /> : null}
            {label}
          </Button>
        </Menu.Button>
        <Transition
          as={Fragment}
          enter="transition ease-out duration-100"
          enterFrom="transform opacity-0 scale-95"
          enterTo="transform opacity-100 scale-100"
          leave="transition ease-in duration-75"
          leaveFrom="transform opacity-100 scale-100"
          leaveTo="transform opacity-0 scale-95"
        >
          <Menu.Items
            static
            className={twMerge(
              "absolute z-20 mt-2 w-max min-w-48 overflow-hidden rounded-[3px] border border-ui-panel-border bg-ui-controls p-1.5 text-base-fg focus:outline-none",
              align === "left" ? "left-0" : "right-0",
            )}
          >
            <div>
              {options.map((option, index) => (
                <Fragment key={index}>
                  {option.divider && (
                    <div className="my-1.5 border-t border-white/15" />
                  )}
                  <Menu.Item>
                    {({ active }) => (
                      <button
                        disabled={option.disabled}
                        className={twMerge(
                          "rounded-[3px] bg-transparent font-medium text-base-fg transition-colors duration-150",
                          active ? "bg-white/10" : "",
                          option.disabled
                            ? "pointer-events-none opacity-40"
                            : "",
                          "group flex w-full items-center gap-2 px-2.5 py-2 text-sm",
                          option.className,
                        )}
                        onClick={() => handleOptionClick(index)}
                      >
                        <div className="flex w-full items-center">
                          {option.icon && (
                            <DynamicIcon
                              icon={option.icon}
                              className="mr-2 h-4 w-4 shrink-0"
                            />
                          )}
                          <div className="grow text-start">{option.label}</div>
                          <div className="ml-6 font-mono text-[11px] font-normal text-white/45">
                            {option.description && option.description}
                          </div>
                          {showSelected && (
                            <>
                              {option.selected ? (
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  viewBox="0 0 512 512"
                                  className="ml-3 flex h-5"
                                >
                                  <path
                                    opacity="1"
                                    d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c-9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z"
                                    fill="#FC6B68"
                                  />
                                  <path
                                    d="M369 175c-9.4 9.4-9.4 24.6 0 33.9L241 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L335 175c-9.4-9.4 24.6-9.4 33.9 0z"
                                    fill="#FFFFFF"
                                  />
                                </svg>
                              ) : (
                                <div className="w-8" />
                              )}
                            </>
                          )}
                        </div>
                      </button>
                    )}
                  </Menu.Item>
                </Fragment>
              ))}
            </div>
          </Menu.Items>
        </Transition>
      </Menu>

      {currentDialogProps && (
        <Modal
          title={currentDialogProps.title}
          isOpen={isOpen}
          onClose={closeModal}
          className={currentDialogProps.className}
        >
          {currentDialogProps.content}

          <div className="mt-6 flex justify-end gap-2">
            {currentDialogProps.showClose !== false &&
              currentDialogProps.closeButtonProps && (
                <Button
                  variant="secondary"
                  {...currentDialogProps.closeButtonProps}
                  onClick={closeModal}
                >
                  {currentDialogProps.closeButtonProps.label}
                </Button>
              )}

            {currentDialogProps.confirmButtonProps && (
              <Button
                {...currentDialogProps.confirmButtonProps}
                onClick={(e) => {
                  if (currentDialogProps.confirmButtonProps?.onClick) {
                    currentDialogProps.confirmButtonProps?.onClick(e);
                  }
                  closeModal();
                }}
              >
                {currentDialogProps.confirmButtonProps.label || "Confirm"}
              </Button>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
